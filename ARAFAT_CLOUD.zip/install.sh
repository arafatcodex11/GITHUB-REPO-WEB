#!/bin/bash
# ╔══════════════════════════════════════════════════════════╗
# ║     ☁️  ARAFAT HOSTING CLOUD v2.0 — Auto Installer        ║
# ╚══════════════════════════════════════════════════════════╝

DIR="$(cd "$(dirname "$0")" && pwd)"
echo "📁 Installing in: $DIR"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 1: System Update"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
apt update -y && apt install -y curl tmux unzip python3 python3-pip

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 2: Python Dependencies"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
pip3 install -r "$DIR/requirements.txt"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 3: Permissions & Directories"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
chmod +x "$DIR/start.sh" "$DIR/stop.sh" "$DIR/restart.sh"
mkdir -p "$DIR/uploads" "$DIR/logs"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Installation Complete!"
echo ""
echo "Now run:"
echo "  tmux new -s ahc"
echo "  bash $DIR/start.sh"
echo ""
echo "Detach: Ctrl+B then D"
echo "Reattach: tmux attach -t ahc"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
