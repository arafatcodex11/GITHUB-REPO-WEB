#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "🔄 Restarting..."
pkill -f "python.*main.py" 2>/dev/null || true
tmux kill-session -t ahc 2>/dev/null || true
sleep 2
tmux new -d -s ahc "bash $DIR/start.sh"
echo "✅ Restarted! View: tmux attach -t ahc"
