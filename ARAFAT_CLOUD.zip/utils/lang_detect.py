"""
☁️ ARAFAT HOSTING CLOUD — Auto Language Detector v1.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

User এর message দেখে automatically বাংলা বা ইংলিশ detect করে।

HOW IT WORKS:
  - বাংলা unicode character (U+0980–U+09FF) থাকলে → 'bn'
  - না থাকলে → 'en'
  - DB-তে user এর ভাষা save করে রাখে
  - পরবর্তী message এও same ভাষায় reply য