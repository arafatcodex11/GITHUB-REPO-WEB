"""
☁️ ARAFAT HOSTING CLOUD — Helpers v2.0
"""

import os, sys, time, logging, threading, psutil
from datetime import datetime
from config import UPLOAD_DIR, LOGS_DIR
from core.state import bot_scripts, state

logger = logging.getLogger('AHC.helpers')

_cpu_cache = {'val': 0.0}
_cpu_lock  = threading.Lock()

def _cpu_monitor():
    while True:
        try:
            v = psutil.cpu_percent(interval=1)
            with _cpu_lock:
                _cpu_cache['val'] = v
        except: pass
        time.sleep(5)

threading.Thread(target=_cpu_monitor, daemon=True, name='cpu_mon').start()


def get_uptime():
    d = datetime.now() - state.bot_start_time
    h, r = divmod(d.seconds, 3600)
    m, s = divmod(r, 60)
    parts = []
    if d.days: parts.append(f"{d.days}d")
    if h: parts.append(f"{h}h")
    parts.append(f"{m}m {s}s")
    return " ".join(parts)


def fmt_size(b):
    for u in ['B','KB','MB','GB']:
        if b < 1024: return f"{b:.1f}{u}"
        b /= 1024
    return f"{b:.1f}TB"


def time_left(end_str):
    if not end_str: return "♾️ Lifetime"
    try:
        end = datetime.fromisoformat(end_str)
        if end <= datetime.now(): return "❌ Expired"
        d = end - datetime.now()
        if d.days > 0: return f"{d.days}d {d.seconds//3600}h"
        return f"{d.seconds//3600}h {(d.seconds%3600)//60}m"
    except: return "?"


def gen_ref_code(uid):
    import hashlib, string
    chars = string.digits + string.ascii_uppercase
    enc = ''
    t = int(uid)
    while t > 0:
        enc = chars[t % 36] + enc
        t //= 36
    salt = hashlib.md5(f"{uid}_ahc".encode()).hexdigest()[:2].upper()
    return f"AHC{enc}{salt}"


def user_folder(uid):
    f = os.path.join(UPLOAD_DIR, str(uid))
    os.makedirs(f, exist_ok=True)
    return f


def is_running(sk):
    i = bot_scripts.get(sk)
    if not i: return False
    proc = i.get('process')
    if not proc or proc.poll() is not None: return False
    try:
        p = psutil.Process(proc.pid)
        return p.status() != psutil.STATUS_ZOMBIE
    except: return False


def cleanup_script(sk):
    i = bot_scripts.pop(sk, None)
    if not i: return
    # log_file fd is now closed immediately after Popen — nothing to close here


def kill_tree(pi):
    if not pi: return
    # log_file fd is now closed immediately after Popen — no fd to close here
    p = pi.get('process')
    if not p: return
    try:
        parent = psutil.Process(p.pid)
        children = parent.children(recursive=True)
        for c in children:
            try: c.terminate()
            except: pass
        psutil.wait_procs(children, timeout=3)
        try:
            parent.terminate()
            parent.wait(timeout=3)
        except:
            try: parent.kill()
            except: pass
    except: pass


def bot_res(sk):
    i = bot_scripts.get(sk)
    if not i or not i.get('process'): return 0, 0
    try:
        p = psutil.Process(i['process'].pid)
        mem = p.memory_info().rss / (1024*1024)
        cpu = p.cpu_percent(interval=None)
        for c in p.children(recursive=True):
            try:
                mem += c.memory_info().rss / (1024*1024)
                cpu += c.cpu_percent(interval=None)
            except: pass
        return round(mem, 1), round(cpu, 1)
    except: return 0, 0


def sys_stats():
    try:
        m = psutil.virtual_memory()
        d = psutil.disk_usage('/')
        with _cpu_lock:
            cpu = _cpu_cache['val']
        return {
            'cpu': cpu, 'mem': m.percent,
            'disk': round(d.used/d.total*100, 1),
            'up': get_uptime(),
            'mem_used': fmt_size(m.used),
            'mem_total': fmt_size(m.total),
            'disk_used': fmt_size(d.used),
            'disk_total': fmt_size(d.total),
        }
    except:
        return {'cpu':0,'mem':0,'disk':0,'up':get_uptime(),
                'mem_used':'?','mem_total':'?','disk_used':'?','disk_total':'?'}


def recommend_plan(mem_mb):
    """Recommend plan based on RAM usage."""
    from config import PLAN_LIMITS
    for key in ['starter','basic','standard','advanced','pro','ultra','premium','elite','master','unlimited']:
        p = PLAN_LIMITS[key]
        if p['ram'] >= mem_mb * 1.3:
            return key, p['name']
    return 'unlimited', PLAN_LIMITS['unlimited']['name']
