"""
☁️ ARAFAT HOSTING CLOUD — Ad Verification Server
Simple Flask app: user আসে → ad দেখে → code পায়
"""

import os, hmac, hashlib, time
from flask import Flask, request, render_template_string, abort

app = Flask(__name__)

# ── Secret key (.env থেকে নাও, bot-এর সাথে same হতে হবে) ──
SECRET = os.environ.get('AD_SECRET', 'change_this_secret_key_in_env')

# ── Ad দেখার পর কত সেকেন্ড অপেক্ষা করতে হবে ──
AD_WAIT_SECONDS = 15  # 15 সেকেন্ড countdown

# ── Adsterra Smartlink ──
AD_SMARTLINK = os.environ.get('AD_SMARTLINK', 'https://www.profitablecpmratenetwork.com/y6thz0j18?key=3f148edb2591a02bc4c71b4e13d55663')


def verify_token(token: str) -> dict | None:
    """
    Token format: uid_timestamp_hmac
    Return: {'uid': ..., 'ts': ...} or None
    """
    try:
        parts = token.split('_')
        if len(parts) != 3:
            return None
        uid, ts, sig = parts
        # 30 মিনিটের মধ্যে হতে হবে
        if time.time() - int(ts) > 1800:
            return None
        # HMAC verify
        expected = hmac.new(
            SECRET.encode(),
            f"{uid}_{ts}".encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        if not hmac.compare_digest(sig, expected):
            return None
        return {'uid': uid, 'ts': ts}
    except Exception:
        return None


def make_code(uid: str, ts: str) -> str:
    """Token থেকে 6-digit code বানাও।"""
    raw = hmac.new(
        SECRET.encode(),
        f"code_{uid}_{ts}".encode(),
        hashlib.sha256
    ).hexdigest()
    # hex digest থেকে 6 digit বের করো
    num = int(raw[:8], 16) % 900000 + 100000
    return str(num)


# ── HTML Template ──────────────────────────────────────────────────────────
PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>☁️ Arafat Hosting Cloud — Watch Ad</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: #0f0f13;
    color: #e8e8e8;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
  }
  .card {
    background: #1a1a22;
    border: 1px solid #2a2a38;
    border-radius: 16px;
    padding: 2rem 1.5rem;
    max-width: 400px;
    width: 100%;
    text-align: center;
  }
  .logo { font-size: 2.5rem; margin-bottom: 0.5rem; }
  .brand { font-size: 1.1rem; font-weight: 600; color: #a78bfa; margin-bottom: 0.25rem; }
  .sub { font-size: 0.85rem; color: #888; margin-bottom: 1.5rem; }
  .divider { border: none; border-top: 1px solid #2a2a38; margin: 1.25rem 0; }

  /* Step boxes */
  .step-box {
    background: #12121a;
    border: 1px solid #2a2a38;
    border-radius: 10px;
    padding: 1rem;
    margin-bottom: 1rem;
  }
  .step-title { font-size: 0.8rem; color: #666; margin-bottom: 0.4rem; }
  .step-text { font-size: 0.95rem; color: #ccc; }

  /* Ad button */
  .ad-btn {
    display: block;
    width: 100%;
    padding: 0.85rem;
    background: #7c3aed;
    color: #fff;
    border: none;
    border-radius: 10px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    margin-bottom: 1rem;
    transition: background 0.2s;
  }
  .ad-btn:hover { background: #6d28d9; }
  .ad-btn.disabled {
    background: #2a2a38;
    color: #555;
    cursor: not-allowed;
    pointer-events: none;
  }

  /* Countdown */
  .countdown-wrap { display: none; margin-bottom: 1rem; }
  .countdown-wrap.active { display: block; }
  .countdown-bar-bg {
    background: #2a2a38;
    border-radius: 6px;
    height: 6px;
    margin-bottom: 0.5rem;
    overflow: hidden;
  }
  .countdown-bar {
    height: 100%;
    background: #7c3aed;
    border-radius: 6px;
    width: 100%;
    transition: width 1s linear;
  }
  .countdown-text { font-size: 0.82rem; color: #888; }

  /* Code box */
  .code-wrap { display: none; }
  .code-wrap.active { display: block; }
  .code-label { font-size: 0.8rem; color: #888; margin-bottom: 0.5rem; }
  .code-box {
    font-size: 2.2rem;
    font-weight: 700;
    letter-spacing: 0.25em;
    color: #a78bfa;
    background: #12121a;
    border: 2px solid #7c3aed;
    border-radius: 10px;
    padding: 0.75rem 1rem;
    margin-bottom: 0.75rem;
    cursor: pointer;
    transition: border-color 0.2s;
  }
  .code-box:hover { border-color: #a78bfa; }
  .copy-hint { font-size: 0.78rem; color: #666; margin-bottom: 0.5rem; }
  .copy-toast {
    font-size: 0.82rem;
    color: #34d399;
    opacity: 0;
    transition: opacity 0.3s;
    height: 1.2rem;
  }
  .copy-toast.show { opacity: 1; }

  .footer-note { font-size: 0.75rem; color: #555; margin-top: 1rem; }
  .error-box {
    background: #2a1a1a;
    border: 1px solid #7f1d1d;
    border-radius: 10px;
    padding: 1rem;
    color: #fca5a5;
    font-size: 0.9rem;
  }
</style>
</head>
<body>
<div class="card">
  <div class="logo">☁️</div>
  <div class="brand">Arafat Hosting Cloud</div>
  <div class="sub">Ad Reward System</div>

  {% if error %}
    <div class="error-box">{{ error }}</div>
    <p class="footer-note">লিংক মেয়াদ উত্তীর্ণ হয়েছে বা অবৈধ।<br>Bot থেকে নতুন লিংক নিন।</p>

  {% else %}
    <div class="step-box">
      <div class="step-title">STEP 1</div>
      <div class="step-text">নিচের বাটনে ক্লিক করুন এবং ad দেখুন</div>
    </div>

    <a id="adBtn" class="ad-btn" href="{{ ad_url }}" target="_blank"
       onclick="startCountdown()">
      📺 Ad দেখুন
    </a>

    <div class="countdown-wrap" id="countdownWrap">
      <div class="countdown-bar-bg">
        <div class="countdown-bar" id="bar"></div>
      </div>
      <div class="countdown-text" id="cdText">Ad দেখছেন... <span id="cdNum">{{ wait }}</span> সেকেন্ড অপেক্ষা করুন</div>
    </div>

    <div class="code-wrap" id="codeWrap">
      <div class="step-box" style="margin-bottom:1rem">
        <div class="step-title">STEP 2</div>
        <div class="step-text">এই কোডটি Bot-এ পাঠান</div>
      </div>
      <div class="code-label">আপনার কোড</div>
      <div class="code-box" id="codeBox" onclick="copyCode()">{{ code }}</div>
      <div class="copy-hint">👆 ট্যাপ করে কপি করুন</div>
      <div class="copy-toast" id="toast">✅ কপি হয়েছে!</div>
    </div>

    <p class="footer-note">কোডটি ৩০ মিনিটের মধ্যে ব্যবহার করুন</p>
  {% endif %}
</div>

<script>
const WAIT = {{ wait }};
let started = false;

function startCountdown() {
  if (started) return;
  started = true;

  const btn = document.getElementById('adBtn');
  const wrap = document.getElementById('countdownWrap');
  const bar = document.getElementById('bar');
  const cdNum = document.getElementById('cdNum');
  const codeWrap = document.getElementById('codeWrap');

  btn.classList.add('disabled');
  wrap.classList.add('active');

  let remaining = WAIT;
  bar.style.width = '100%';

  const interval = setInterval(() => {
    remaining--;
    cdNum.textContent = remaining;
    bar.style.width = (remaining / WAIT * 100) + '%';

    if (remaining <= 0) {
      clearInterval(interval);
      // Server থেকে code verify করো
      const token = new URLSearchParams(window.location.search).get('t');
      fetch('/ad/code?t=' + token)
        .then(r => r.json())
        .then(data => {
          if (data.ok) {
            document.getElementById('codeBox').textContent = data.code;
            wrap.classList.remove('active');
            codeWrap.classList.add('active');
            codeWrap.scrollIntoView({ behavior: 'smooth' });
          } else {
            const wait = data.wait || 5;
            cdNum.textContent = wait;
            remaining = wait;
            wrap.classList.add('active');
          }
        })
        .catch(() => {
          wrap.classList.remove('active');
          codeWrap.classList.add('active');
        });
    }
  }, 1000);
}

function copyCode() {
  const code = document.getElementById('codeBox').textContent.trim();
  navigator.clipboard.writeText(code).then(() => {
    const toast = document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  });
}
</script>
</body>
</html>
"""


# Server-side: কোন token কখন ad page open করেছে track করো
_ad_open_times: dict = {}

def _cleanup_ad_times():
    """2 ঘণ্টার পুরনো entries মুছো।"""
    now = time.time()
    expired = [k for k, v in list(_ad_open_times.items()) if now - v > 7200]
    for k in expired:
        _ad_open_times.pop(k, None)

@app.route('/ad')
def ad_page():
    token = request.args.get('t', '')
    if not token:
        abort(400)

    data = verify_token(token)
    if not data:
        return render_template_string(PAGE,
                                      error="লিংক মেয়াদ উত্তীর্ণ বা অবৈধ।",
                                      code='', ad_url='', wait=AD_WAIT_SECONDS)

    # FIX: প্রথমবার open হওয়ার সময় record করো
    key = f"{data['uid']}_{data['ts']}"
    if key not in _ad_open_times:
        _ad_open_times[key] = time.time()

    code = make_code(data['uid'], data['ts'])

    return render_template_string(PAGE,
                                  error=None,
                                  code=code,
                                  ad_url=AD_SMARTLINK,
                                  wait=AD_WAIT_SECONDS)


@app.route('/ad/code')
def get_code():
    """Server-side verify: AD_WAIT_SECONDS পার হলেই code দাও।"""
    token = request.args.get('t', '')
    data = verify_token(token)
    if not data:
        return {'ok': False, 'error': 'invalid'}, 403

    key = f"{data['uid']}_{data['ts']}"
    opened_at = _ad_open_times.get(key, 0)
    elapsed = time.time() - opened_at

    if elapsed < AD_WAIT_SECONDS:
        return {'ok': False, 'wait': int(AD_WAIT_SECONDS - elapsed)}, 403

    code = make_code(data['uid'], data['ts'])
    return {'ok': True, 'code': code}


@app.route('/health')
def health():
    return {'status': 'ok'}, 200


if __name__ == '__main__':
    port = int(os.environ.get('AD_PORT', 5055))
    app.run(host='0.0.0.0', port=port, debug=False)
