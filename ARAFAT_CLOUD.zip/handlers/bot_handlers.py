"""
☁️ ARAFAT HOSTING CLOUD — Handlers v2.1 (Fixed + Optimized)
"""

import os, io, zipfile, shutil, logging, threading, time, html as html_lib, hmac, hashlib
from datetime import datetime
from telebot import types

from config import (BRAND, PLAN_LIMITS, PAYMENT_METHODS, OWNER_ID,
                    DEV_USERNAME, REF_BONUS_DAYS, REF_COMMISSION,
                    MIN_WITHDRAW, UPLOAD_DIR, LOGS_DIR, AD_WATCH_URL,
                    AD_SECRET, AD_SERVER_URL)
from core.state import state, bot_scripts
from core.runner import run_bot
from core.detector import detect_entry
from utils.helpers import (user_folder, cleanup_script, kill_tree,
                           is_running, bot_res, sys_stats, time_left, gen_ref_code)
from handlers.keyboards import (
    main_menu_kb, back_home, back2, lang_kb, bot_list_kb,
    bot_action_kb, bot_del_confirm_kb, plan_list_kb, plan_detail_kb,
    pay_method_kb, pay_approve_kb, wd_approve_kb, wd_method_kb,
    admin_kb, settings_kb, help_kb, channel_fsub_kb
)
from lang import t
from security.scanner   import scan_directory, ScanResult, check_zip_bomb
from security.file_lock import create_lock, verify_lock, remove_lock, LockViolation
from security.vps_guard import VPSGuard
from security.alerter import (init_alerts, alert_security, alert_bot_error,
                               alert_ram_critical, alert_new_user,
                               alert_payment_received, alert_suspicious_activity,
                               start_daily_report_scheduler)

logger = logging.getLogger('AHC.handlers')

_bot = None
_db  = None
_broadcast_lock = threading.Lock()  # prevents concurrent broadcasts

# ── Security modules (initialized in init_handlers) ──────────
_ids: 'IntrusionDetector | None' = None
_session_guard: 'SessionGuard | None' = None


def init_handlers(bot_inst, db_inst):
    global _bot, _db, _ids, _session_guard
    _bot = bot_inst
    _db  = db_inst
    from config import OWNER_ID
    from security.ids import IntrusionDetector
    from security.session_guard import SessionGuard
    _ids           = IntrusionDetector(_bot, OWNER_ID, _db)
    _session_guard = SessionGuard(_bot, OWNER_ID)
    logger.info("✅ IDS + SessionGuard initialized")


def safe_send(cid, text, **kwargs):
    try:
        if len(text) > 4096:
            text = text[:4090] + "..."
        return _bot.send_message(cid, text, parse_mode='HTML', **kwargs)
    except Exception as e:
        logger.error(f"safe_send({cid}): {e}")


def safe_edit(call, text, **kwargs):
    try:
        if len(text) > 4096:
            text = text[:4090] + "..."
        _bot.edit_message_text(text, call.message.chat.id,
                               call.message.message_id, parse_mode='HTML', **kwargs)
    except Exception as e:
        if "message is not modified" not in str(e).lower():
            logger.debug(f"safe_edit fallback: {e}")
            safe_send(call.message.chat.id, text, **kwargs)


def _lang(uid):
    return _db.get_lang(uid) if _db else 'en'


def _get_or_create(uid, username='', full_name=''):
    """Get or create user — always returns valid user dict."""
    u = _db.get_user(uid)
    if not u:
        _db.create_user(uid, username, full_name)
        _db.update_user(uid, last_active=datetime.now().isoformat())
        u = _db.get_user(uid)
        # Edge case: create_user may silently no-op on DuplicateKey suppression;
        # retry get_user once more before giving up.
        if not u:
            import time; time.sleep(0.1)
            u = _db.get_user(uid)
    else:
        _db.update_user(uid,
                        last_active=datetime.now().isoformat(),
                        username=username,
                        full_name=full_name)
    return u


def _check_banned(uid):
    u = _db.get_user(uid)
    return bool(u and u.get('is_banned'))


def _check_force_sub(uid):
    if not state.force_sub_enabled:
        return []
    channels   = _db.get_active_channels()
    not_joined = []
    for ch in channels:
        un = ch.get('username', '').strip()
        if not un:
            continue
        try:
            mb = _bot.get_chat_member(f"@{un}", uid)
            if mb.status in ('left', 'kicked'):
                not_joined.append(ch)
        except Exception as e:
            logger.debug(f"force_sub @{un}: {e}")
            not_joined.append(ch)
    return not_joined


def _give_pending_referral(uid):
    """force_sub disabled হলেও ref_pending bonus দাও।"""
    try:
        u_data = _db.get_user(uid)
        if u_data and u_data.get('ref_pending'):
            ref_uid = int(u_data['ref_pending'])
            _rc  = _db.get_ref_commission()
            _rbd = _db.get_ref_bonus_days()
            _db.add_referral(ref_uid, uid, _rc, _rbd)
            _db.update_user(uid, ref_pending=None)
            fn2 = _db.get_user(uid)
            name2 = fn2.get('name', '') if fn2 else ''
            safe_send(ref_uid,
                      f"🎉 <b>New Referral!</b>\n\n"
                      f"👤 {name2} joined!\n"
                      f"💰 +{_rc} BDT | 📅 +{_rbd} days")
    except Exception as e:
        logger.warning(f"pending referral: {e}")

def _show_home(uid, name=''):
    _give_pending_referral(uid)
    lang  = _lang(uid)
    u     = _db.get_user(uid)
    if not u:
        return
    plan_name = _db.get_active_plan_display(uid)
    total    = _db.get_total_bots(uid)
    used     = _db.bot_count(uid)
    max_str  = '♾️' if total == -1 else str(total)
    se       = u.get('sub_end')
    expires  = '♾️ Lifetime' if u.get('is_lifetime') else time_left(se) if se else '7 days (Free)'
    safe_send(uid, t('welcome', lang,
                     name=name or u.get('full_name', ''),
                     uid=uid, plan=plan_name,
                     bots=used, max_bots=max_str, expires=expires),
              reply_markup=main_menu_kb(uid, lang))


def _show_home_edit(call, uid):
    lang    = _lang(uid)
    u       = _db.get_user(uid)
    if not u:
        return
    plan_name = _db.get_active_plan_display(uid)
    total   = _db.get_total_bots(uid)
    max_str = '♾️' if total == -1 else str(total)
    se      = u.get('sub_end')
    expires = '♾️ Lifetime' if u.get('is_lifetime') else time_left(se) if se else '7 days (Free)'
    safe_edit(call, t('welcome', lang,
                      name=call.from_user.full_name or u.get('full_name', ''),
                      uid=uid, plan=plan_name,
                      bots=_db.bot_count(uid), max_bots=max_str, expires=expires),
              reply_markup=main_menu_kb(uid, lang))


# ─── Ad Token Helpers ──────────────────────────────────────────────────────

def _make_ad_token(uid: int) -> str:
    """Generate a signed token: uid_timestamp_hmac"""
    ts  = str(int(time.time()))
    sig = hmac.new(
        AD_SECRET.encode(),
        f"{uid}_{ts}".encode(),
        hashlib.sha256
    ).hexdigest()[:16]
    return f"{uid}_{ts}_{sig}"


def _verify_ad_code(uid: int, code: str) -> bool:
    """Verify the 6-digit code against the user's saved token."""
    u = _db.get_user(uid)
    if not u:
        return False
    token = u.get('ad_pending_token', '')
    if not token:
        return False
    try:
        parts = token.split('_')
        if len(parts) != 3:
            return False
        t_uid, ts, sig = parts
        # Token must belong to this user
        if int(t_uid) != uid:
            return False
        # Token must be within 30 minutes
        if time.time() - int(ts) > 1800:
            return False
        # Verify HMAC signature
        expected_sig = hmac.new(
            AD_SECRET.encode(),
            f"{uid}_{ts}".encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        if not hmac.compare_digest(sig, expected_sig):
            return False
        # Generate the expected 6-digit code
        raw = hmac.new(
            AD_SECRET.encode(),
            f"code_{uid}_{ts}".encode(),
            hashlib.sha256
        ).hexdigest()
        expected_code = str(int(raw[:8], 16) % 900000 + 100000)
        return hmac.compare_digest(code, expected_code)
    except Exception:
        return False


def register_handlers(bot):

    # ─── /start ───────────────────────────────────────────────────
    @bot.message_handler(commands=['start'])
    def cmd_start(msg):
        uid = msg.from_user.id
        un  = msg.from_user.username or ''
        fn  = msg.from_user.full_name or ''

        if not state.rate_ok(uid):
            return

        # FIX: Check new BEFORE creating user
        existing = _db.get_user(uid)
        is_new   = not existing

        # FIX: Always create user FIRST before any other DB call
        u = _get_or_create(uid, un, fn)

        if not state.is_admin(uid) and _check_banned(uid):
            safe_send(uid, t('banned', _lang(uid)))
            return

        # Referral — only for brand new users
        args = msg.text.split()
        if len(args) > 1 and args[1].startswith('ref_') and is_new:
            rc = args[1][4:]
            # FIX: O(1) indexed lookup — no full user scan
            referrer = _db.get_user_by_ref_code(rc)
            if referrer and referrer['uid'] != uid and not u.get('referred_by'):
                # FIX: এখন শুধু referrer uid save করো।
                # channel join (fsub_verify) হলে তারপর bonus দেওয়া হবে।
                _db.update_user(uid, referred_by=referrer['uid'], ref_pending=str(referrer['uid']))

        # New user → pick language first
        if is_new:
            safe_send(uid, t('choose_language'), reply_markup=lang_kb())
            return

        not_joined = _check_force_sub(uid)
        if not_joined:
            lang = _lang(uid)
            chs  = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
            safe_send(uid, t('force_sub', lang, channels=chs),
                      reply_markup=channel_fsub_kb(not_joined, lang))
            return

        _show_home(uid, fn)


    @bot.message_handler(commands=['help'])
    def cmd_help(msg):
        uid  = msg.from_user.id
        lang = _lang(uid)
        safe_send(uid, t('help_main', lang), reply_markup=help_kb(lang))

    @bot.message_handler(commands=['id'])
    def cmd_id(msg):
        safe_send(msg.from_user.id, f"🆔 Your ID: <code>{msg.from_user.id}</code>")

    @bot.message_handler(commands=['ping'])
    def cmd_ping(msg):
        uid = msg.from_user.id
        t0  = time.time()
        m   = safe_send(uid, "🏓 Pinging...")
        if not m:
            return
        lat = round((time.time() - t0) * 1000)
        ss  = sys_stats()
        try:
            _bot.edit_message_text(
                f"🏓 <b>Pong!</b>\n\n"
                f"⚡ Latency: <code>{lat}ms</code>\n"
                f"⏱️ Uptime: {ss['up']}\n"
                f"🖥️ CPU: {ss['cpu']}%\n💾 RAM: {ss['mem']}%",
                uid, m.message_id, parse_mode='HTML')
        except: pass

    @bot.message_handler(commands=['status'])
    def cmd_status(msg):
        uid  = msg.from_user.id
        bots = _db.get_bots(uid)
        if not bots:
            safe_send(uid, "🤖 No bots deployed yet.")
            return
        text = "📊 <b>Your Bots</b>\n━━━━━━━━━━━━━━━━\n\n"
        for b in bots:
            s    = b.get('status','stopped')
            icon = '🟢' if s=='running' else '🔴' if s=='crashed' else '⚫'
            text += f"{icon} <code>{b['name']}</code> — {s}\n"
        safe_send(uid, text)

    @bot.message_handler(commands=['admin'])
    def cmd_admin(msg):
        uid = msg.from_user.id
        if not state.is_admin(uid):
            return
        safe_send(uid, f"👑 <b>Admin Panel</b>\n{BRAND}",
                  reply_markup=admin_kb(_lang(uid)))


    # ─── FILE UPLOAD ───────────────────────────────────────────────
    @bot.message_handler(content_types=['document'])
    def handle_file(msg):
        uid   = msg.from_user.id
        lang  = _lang(uid)
        uname = msg.from_user.username or ''

        if not state.rate_ok(uid):
            return
        if not state.is_admin(uid) and _check_banned(uid):
            return

        # ── IDS: rapid upload detect ──────────────────────────────
        if _ids and not state.is_admin(uid):
            if _ids.record_upload(uid, uname):
                safe_send(uid, "⚠️ অনেক দ্রুত file upload করছেন। কিছুক্ষণ অপেক্ষা করুন।")
                return

        if not state.rate_ok(uid):
            return
        if not state.is_admin(uid) and _check_banned(uid):
            return

        not_joined = _check_force_sub(uid)
        if not_joined:
            chs = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
            safe_send(uid, t('force_sub', lang, channels=chs),
                      reply_markup=channel_fsub_kb(not_joined, lang))
            return

        if state.bot_locked and not state.is_admin(uid):
            safe_send(uid, "🔒 Bot is temporarily locked. Please try later.")
            return

        if _db.is_free_expired(uid):
            mk = types.InlineKeyboardMarkup(row_width=2)
            mk.add(
                types.InlineKeyboardButton("💎 Upgrade", callback_data="menu_sub"),
                types.InlineKeyboardButton("📺 Watch Ad", callback_data="menu_watchad")
            )
            safe_send(uid, t('free_limit', lang, name=''), reply_markup=mk)
            return

        total = _db.get_total_bots(uid)
        used  = _db.bot_count(uid)
        if total != -1 and used >= total:
            mk = types.InlineKeyboardMarkup()
            mk.add(types.InlineKeyboardButton("💎 Upgrade Plan", callback_data="menu_sub"))
            safe_send(uid,
                      f"❌ <b>Bot Limit Reached!</b>\n\nPlan allows {total} bot(s).",
                      reply_markup=mk)
            return

        doc   = msg.document
        # FIX: sanitize filename — prevent path traversal via crafted filename
        raw_fname = doc.file_name or 'upload.py'
        # FIX: normalize Windows backslash paths before basename, then strip
        _norm     = raw_fname.replace('\\', '/').replace('\\\\', '/')
        fname     = os.path.basename(_norm).strip() or 'upload.py'
        # Edge: fname like '.zip' has no real name — use fallback
        _name_part = fname.rsplit('.', 1)[0] if '.' in fname else fname
        if not _name_part:
            fname = f'bot_{uid}.{fname.lstrip(".")}'  # e.g. '.zip' → 'bot_123.zip'
        ext       = fname.rsplit('.', 1)[-1].lower() if '.' in fname else ''

        if ext not in ('py', 'js', 'zip'):
            safe_send(uid, "❌ Only .py, .js, or .zip files allowed!")
            return

        # 50MB size guard
        if doc.file_size and doc.file_size > 50 * 1024 * 1024:
            safe_send(uid, "❌ File too large! Max 50MB.")
            return

        safe_send(uid, f"📥 Downloading <code>{fname}</code>...")
        try:
            fi   = _bot.get_file(doc.file_id)
            data = _bot.download_file(fi.file_path)
        except Exception as e:
            safe_send(uid, f"❌ Download failed: {e}")
            return

        uf = user_folder(uid)
        fp = os.path.join(uf, fname)
        with open(fp, 'wb') as f:
            f.write(data)

        if ext == 'zip':
            # ── ZIP Bomb Check ────────────────────────────────
            _zb_safe, _zb_reason = check_zip_bomb(fp)
            if not _zb_safe:
                os.remove(fp)
                safe_send(uid, f"❌ <b>ZIP Bomb Detected!</b>\n{_zb_reason}")
                return
            # ─────────────────────────────────────────────────
            safe_send(uid, "📦 Extracting ZIP...")
            try:
                bot_name    = fname[:-4].strip() or f"bot_{uid}"  # strip .zip; fallback if fname was ".zip"
                extract_dir = os.path.join(uf, bot_name)
                # FIX: wipe old extract_dir so stale files from previous upload don't linger
                if os.path.isdir(extract_dir):
                    # Warn if an existing bot with this name is running
                    _sk_existing = f"{uid}_{bot_name}"
                    if is_running(_sk_existing):
                        safe_send(uid, f"⚠️ <b>{bot_name}</b> is currently running and will be stopped before update.")
                        _bi_existing = _db.get_bots(uid)
                        _bi_existing = next((b for b in _bi_existing if b['name'] == bot_name), None)
                        if _bi_existing:
                            kill_tree(bot_scripts.get(_sk_existing))
                            cleanup_script(_sk_existing)
                            _db.update_bot(_bi_existing['bid'], status='stopped')
                    shutil.rmtree(extract_dir)
                os.makedirs(extract_dir, exist_ok=True)
                with zipfile.ZipFile(fp, 'r') as zf:
                    # FIX: full path traversal check — '..' any OS, absolute paths,
                    #      Windows backslash variants, and symlinks
                    for member in zf.infolist():
                        mname = member.filename.replace('\\', '/').replace('\\\\', '/')
                        if ('..' in mname.split('/')
                                or mname.startswith('/')
                                or os.path.isabs(mname)):
                            safe_send(uid, "❌ Unsafe ZIP content detected!")
                            os.remove(fp)
                            return
                        # block symlinks
                        if (member.external_attr >> 16) & 0o170000 == 0o120000:
                            safe_send(uid, "❌ ZIP contains symlinks — not allowed!")
                            os.remove(fp)
                            return
                    zf.extractall(extract_dir)
                    items = os.listdir(extract_dir)
                    if len(items) == 1 and os.path.isdir(os.path.join(extract_dir, items[0])):
                        inner = os.path.join(extract_dir, items[0])
                        for f2 in os.listdir(inner):
                            os.rename(os.path.join(inner, f2), os.path.join(extract_dir, f2))
                        os.rmdir(inner)
                os.remove(fp)
                fp = extract_dir

                # ── Security Scan ──────────────────────────────────────
                safe_send(uid, "🔍 Security scan চলছে...")
                scan = scan_directory(fp)
                uname = getattr(msg.from_user, 'username', '') or ''

                if scan.blocked:
                    # Critical — quarantine এ রাখো, admin approve/reject করবে
                    issues_text = '\n'.join(scan.critical_issues[:5])
                    fname = os.path.basename(fp) if os.path.isfile(fp) else os.path.basename(fp.rstrip('/'))
                    qid = _db.quarantine_file(uid, uname, fp, fname, issues_text)
                    # Admin কে alert + approve/reject button
                    report = scan.admin_report(uid, uname)
                    mk_adm = types.InlineKeyboardMarkup()
                    mk_adm.add(
                        types.InlineKeyboardButton("✅ Approve (চালু করো)", callback_data=f"adm_qapprove:{qid}:{uid}"),
                        types.InlineKeyboardButton("🗑️ Reject (Delete)", callback_data=f"adm_qreject:{qid}:{uid}")
                    )
                    try:
                        _bot.send_message(OWNER_ID,
                                          f"🚨 <b>Quarantine File</b>\n━━━━━━━━━━━━━━━━\n"
                                          f"{report}\n\n"
                                          f"🔢 Quarantine ID: <code>{qid}</code>\n"
                                          f"👇 Approve বা Reject করুন:",
                                          parse_mode='HTML',
                                          reply_markup=mk_adm)
                    except Exception:
                        pass
                    alert_security(uid, uname, report)
                    safe_send(uid,
                              "🚫 <b>File Block করা হয়েছে!</b>\n\n"
                              "আপনার file-এ সন্দেহজনক/ক্ষতিকর code পাওয়া গেছে।\n"
                              "Admin review করবে। Approve হলে আপনাকে জানানো হবে।\n\n"
                              f"<b>কারণ:</b>\n"
                              + '\n'.join(f'• {i}' for i in scan.critical_issues[:3]))
                    return
                elif not scan.safe:
                    # Warning — admin কে alert দাও কিন্তু চলতে দাও
                    alert_security(uid, uname, scan.admin_report(uid, uname))
                    safe_send(uid,
                              "⚠️ <b>Warning:</b> File-এ কিছু সন্দেহজনক code আছে।\n"
                              "Admin কে notify করা হয়েছে। Bot চালু থাকবে।")
                else:
                    safe_send(uid, "✅ Security scan সম্পন্ন — কোনো সমস্যা নেই।")

                # ── Token Encryption (scan pass হলে) ──────────────────
                if not scan.blocked:
                    try:
                        from security.token_encryptor import encrypt_env_file
                        env_path = os.path.join(fp, '.env') if os.path.isdir(fp) else None
                        if env_path and os.path.exists(env_path):
                            if encrypt_env_file(env_path, uid):
                                safe_send(uid, "🔐 Bot token encrypted ও সুরক্ষিত করা হয়েছে।")
                    except Exception as _ee:
                        logger.warning(f"Token encrypt error: {_ee}")
                # ── End Token Encryption ───────────────────────────────

                # ── File Lock (anti-theft) ────────────────────────────
                if not scan.blocked and os.path.isdir(fp):
                    try:
                        from security.file_lock import create_lock
                        create_lock(uid, fp, bot_name)
                    except Exception as _le:
                        logger.warning(f"Lock create error: {_le}")
                # ── End File Lock ──────────────────────────────────────

                # ── End Security Scan ──────────────────────────────────

            except zipfile.BadZipFile:
                safe_send(uid, "❌ Invalid ZIP file!")
                return
            except Exception as e:
                safe_send(uid, f"❌ ZIP extract failed: {e}")
                return
        else:
            bot_name = fname

        ef, ft, conf = (detect_entry(fp) if os.path.isdir(fp)
                        else (fname, ext, 'exact'))
        if not ef:
            safe_send(uid, "❌ Could not detect entry file.")
            return

        backup_msg_id = 0
        try:
            ch  = _db.get_backup_channel()
            cap = (f"☁️ <b>AHC Backup</b>\n\n"
                   f"👤 {msg.from_user.full_name} (<code>{uid}</code>)\n"
                   f"📄 <code>{fname}</code>\n"
                   f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M')}")
            bk = _bot.send_document(ch, doc.file_id, caption=cap, parse_mode='HTML')
            backup_msg_id = bk.message_id
        except Exception as e:
            logger.warning(f"Backup failed: {e}")

        # ── Plan Selection (if user has multiple plans) ──────────────
        u_data    = _db.get_user(uid)
        base_plan = u_data.get('plan', 'free') if u_data else 'free'
        stack     = u_data.get('plan_stack', []) if u_data else []
        if isinstance(stack, str):
            try:
                import json as _json
                stack = _json.loads(stack)
            except:
                stack = []

        # Collect all non-free plans
        all_plans = []
        if base_plan != 'free':
            all_plans.append(base_plan)
        all_plans += [p for p in stack if p != 'free']

        if len(all_plans) > 1:
            # Multiple plans — ask user which slot to use
            mk = types.InlineKeyboardMarkup(row_width=1)
            for p in all_plans:
                p_info = PLAN_LIMITS.get(p, {})
                p_name = p_info.get('name', p)
                p_ram  = p_info.get('ram', 0)
                mk.add(types.InlineKeyboardButton(
                    f"{p_name} — {p_ram}MB RAM",
                    callback_data=f"deploy_plan:{p}:{bot_name}"
                ))
            mk.add(types.InlineKeyboardButton("❌ Cancel", callback_data="go_home"))
            # Save pending deploy info in state
            state.set(uid, {
                'action': 'pending_deploy',
                'fp': fp, 'ef': ef, 'ft': ft, 'bot_name': bot_name,
                'backup_msg_id': backup_msg_id
            })
            safe_send(uid,
                      f"📂 <b>{bot_name}</b> ready to deploy!\n\n"
                      f"⚡ আপনার একাধিক সাবস্ক্রিপশন আছে।\n"
                      f"কোন plan-এ এই bot চালাতে চান সেটা বেছে নিন:\n\n"
                      f"💡 প্রতিটি plan-এর RAM আলাদাভাবে ব্যবহার হবে।",
                      reply_markup=mk)
            return

        # Single plan — deploy directly
        assigned_plan = all_plans[0] if all_plans else 'free'
        bid = _db.add_bot(uid, bot_name, fp, ef, ft, backup_msg_id, assigned_plan)
        if not bid:
            safe_send(uid, "❌ Failed to save bot. Try again.")
            return

        ci = {'exact':'🎯','high':'✅','medium':'🟡','low':'⚠️'}.get(conf,'')
        ti = '🐍 Python' if ft == 'py' else '🟨 Node.js'
        safe_send(uid,
                  f"✅ <b>Bot Deployed!</b>\n━━━━━━━━━━━━━━━━\n\n"
                  f"🤖 <code>{bot_name}</code>\n"
                  f"📄 Entry: <code>{ef}</code> {ci}\n"
                  f"🔤 {ti}\n"
                  f"💾 Backed up ✅",
                  reply_markup=bot_action_kb(bid, False, lang))


    # ─── TEXT STATES ───────────────────────────────────────────────
    @bot.message_handler(content_types=['text'])
    def handle_text(msg):
        uid  = msg.from_user.id
        txt  = msg.text.strip()
        lang = _lang(uid)

        if not state.is_admin(uid) and _check_banned(uid):
            return
        if not state.rate_ok(uid):
            return
        if txt.startswith('/'):
            return

        # FIX: admin-only actions bypass force_sub; others must pass
        st = state.get(uid)
        action = st.get('action', '') if st else ''
        _admin_actions = {
            'adm_ban','adm_unban','adm_broadcast','adm_give_bal',
            'adm_addsub','adm_remsub','adm_userinfo','adm_backup_ch',
            'adm_ch_add','adm_promo_create',
            'adm_set_commission','adm_set_bonus','adm_set_minwd',
        }
        if not state.is_admin(uid) and action not in _admin_actions:
            not_joined = _check_force_sub(uid)
            if not_joined:
                chs = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
                safe_send(uid, t('force_sub', lang, channels=chs),
                          reply_markup=channel_fsub_kb(not_joined, lang))
                return

        # FIX: No state → guide user, never silent ignore
        if not st:
            u = _db.get_user(uid)
            if not u:
                safe_send(uid, t('choose_language'), reply_markup=lang_kb())
            else:
                _show_home(uid, msg.from_user.full_name or '')
            return

        # action already set above from st

        if action == 'ad_code_input':
            # User ad code submit করেছে
            code = txt.strip()
            if not code.isdigit() or len(code) != 6:
                safe_send(uid, "❌ কোডটি 6-digit হতে হবে। আবার চেষ্টা করুন:",
                          reply_markup=back_home(lang))
                state.clear(uid)
                return
            if not _db.can_watch_ad(uid):
                safe_send(uid, "⏰ আপনি আজকের reward ইতিমধ্যে পেয়েছেন!",
                          reply_markup=back_home(lang))
                state.clear(uid)
                return
            if _verify_ad_code(uid, code):
                _db.record_ad_watch(uid)
                _db.clear_ad_token(uid)
                state.clear(uid)
                safe_send(uid,
                          "✅ <b>Code সঠিক!</b>\n\n"                          "🎉 আপনার hosting +24 ঘন্টা বাড়ানো হয়েছে!",
                          reply_markup=back_home(lang))
            else:
                u_data = _db.get_user(uid)
                fails  = u_data.get('ad_code_fails', 0) + 1 if u_data else 1
                _db.update_user(uid, ad_code_fails=fails)
                # ── IDS: brute force ad code ──────────────────────
                if _ids:
                    uname = _db.get_user(uid) or {}
                    _ids.record_failed_ad_code(uid, uname.get('username', ''))
                state.clear(uid)
                if fails >= 3:
                    _db.update_user(uid, ad_code_fails=0)
                    safe_send(uid,
                              "🚫 <b>৩ বার ভুল code!</b>\n\n"                              "আপনি সাময়িকভাবে block হয়েছেন।\n"                              "পরে আবার চেষ্টা করুন।",
                              reply_markup=back_home(lang))
                else:
                    safe_send(uid,
                              f"❌ কোডটি সঠিক নয়! ({fails}/3 attempt)\n\n"                              f"Ad দেখার পর পাওয়া 6-digit code দিন।",
                              reply_markup=back_home(lang))
            return

        if action == 'pay_trx':
            ps = state.get_pay(uid)
            if not ps:
                state.clear(uid)
                return
            plan_key = ps['plan']
            method   = ps['method']
            if plan_key not in PLAN_LIMITS or method not in PAYMENT_METHODS:
                state.clear(uid)
                safe_send(uid, "❌ Session expired. Try again.", reply_markup=back_home(lang))
                return
            p   = PLAN_LIMITS[plan_key]
            pm  = PAYMENT_METHODS[method]
            cur = pm['currency']
            amt = p['price_usdt'] if cur == 'USDT' else p['price_bdt']
            pid = _db.add_payment(uid, amt, method, txt, plan_key, p['days'], cur)
            state.clear(uid)
            safe_send(uid,
                      f"✅ <b>Payment Submitted!</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"💎 {p['name']}\n💰 {amt} {cur}\n"
                      f"{pm['icon']} {pm['name']}\n"
                      f"🔖 TRX: <code>{txt}</code>\n\n"
                      f"⏳ Admin will verify in 1-2 hours.",
                      reply_markup=back_home(lang))
            for aid in state.admin_ids:
                safe_send(aid,
                          f"💳 <b>New Payment!</b>\n"
                          f"👤 <code>{uid}</code> | {p['name']}\n"
                          f"💰 {amt} {cur} | {pm['name']}\n"
                          f"🔖 <code>{txt}</code>\n🆔 <code>{pid}</code>",
                          reply_markup=pay_approve_kb(pid))

        elif action == 'wd_amount':
            try:
                amt = float(txt)
                u   = _db.get_user(uid)
                bal = u.get('wallet', 0) if u else 0
                if amt < MIN_WITHDRAW:
                    safe_send(uid, f"❌ Minimum: {MIN_WITHDRAW} BDT")
                    return
                if amt > bal:
                    safe_send(uid, f"❌ Balance {bal} BDT < {amt} BDT")
                    return
                state.set(uid, {'action': 'wd_account',
                                'wd_data': {'amount': amt, 'method': st.get('method','')}})
                safe_send(uid, f"📲 Enter your {st.get('method','')} account number:")
            except ValueError:
                safe_send(uid, "❌ Enter a valid number")

        elif action == 'wd_account':
            wd  = st.get('wd_data', {})
            amt = wd.get('amount', 0)
            mth = wd.get('method', '')
            wid, err = _db.add_withdrawal(uid, amt, mth, txt)
            state.clear(uid)
            if err:
                safe_send(uid, f"❌ {err}")
                return
            safe_send(uid,
                      f"✅ <b>Withdrawal Requested!</b>\n\n"
                      f"💸 {amt} BDT | {mth}\n📲 <code>{txt}</code>\n\n"
                      f"⏳ Admin will process in 24 hours.",
                      reply_markup=back_home(lang))
            for aid in state.admin_ids:
                safe_send(aid,
                          f"💸 <b>Withdrawal!</b>\n"
                          f"👤 <code>{uid}</code>\n💰 {amt} BDT | {mth}\n"
                          f"📲 <code>{txt}</code>",
                          reply_markup=wd_approve_kb(wid))

        elif action == 'adm_ban':
            try:
                tuid = int(txt)
                _db.ban(tuid, 'Banned by admin')
                _db.admin_log(uid, 'ban', tuid)
                safe_send(uid, f"🚫 <code>{tuid}</code> banned.")
                safe_send(tuid, t('banned', _lang(tuid)))
            except ValueError:
                safe_send(uid, "❌ Invalid ID")
            state.clear(uid)

        elif action == 'adm_unban':
            try:
                tuid = int(txt)
                _db.unban(tuid)
                _db.admin_log(uid, 'unban', tuid)
                safe_send(uid, f"✅ <code>{tuid}</code> unbanned.")
                safe_send(tuid, "✅ You have been unbanned! Welcome back.")
            except ValueError:
                safe_send(uid, "❌ Invalid ID")
            state.clear(uid)

        elif action == 'adm_broadcast':
            state.clear(uid)
            msg_text = txt  # capture before thread
            admin_uid = uid
            def _do_broadcast():
                # FIX: lock prevents two admins running concurrent broadcasts
                if not _broadcast_lock.acquire(blocking=False):
                    safe_send(admin_uid, "⚠️ Another broadcast is already running. Please wait.")
                    return
                try:
                    users = _db.get_all_users()
                    ok = fail = 0
                    for u2 in users:
                        try:
                            safe_send(u2['uid'], f"📢 <b>{BRAND}</b>\n\n{msg_text}")
                            ok += 1
                            time.sleep(0.05)  # Telegram flood guard ~20/s
                        except Exception as be:
                            logger.debug(f"broadcast skip {u2.get('uid')}: {be}")
                            fail += 1
                    _db.admin_log(admin_uid, 'broadcast', details=f"ok={ok} fail={fail}")
                    safe_send(admin_uid, f"📢 Broadcast done! ✅ {ok} | ❌ {fail}")
                finally:
                    _broadcast_lock.release()
            all_users_count = len(_db.get_all_users())
            threading.Thread(target=_do_broadcast, daemon=True, name='broadcast').start()
            safe_send(uid, f"📢 Broadcast started to {all_users_count} users...")

        elif action == 'adm_give_bal':
            try:
                parts = txt.split()
                tuid  = int(parts[0])
                amt   = float(parts[1])
                _db.wallet_tx(tuid, amt, 'bonus', "Admin gift")
                _db.admin_log(uid, 'give_balance', tuid, f"{amt}")
                safe_send(uid, f"✅ {amt} BDT → <code>{tuid}</code>")
                safe_send(tuid, f"🎁 +{amt} BDT from admin!")
            except (ValueError, IndexError):
                safe_send(uid, "❌ Format: USER_ID AMOUNT")
            state.clear(uid)

        elif action == 'adm_addsub':
            try:
                parts = txt.split()
                tuid  = int(parts[0])
                plan  = parts[1].lower()
                days  = int(parts[2]) if len(parts) > 2 else 30
                if plan not in PLAN_LIMITS:
                    safe_send(uid, f"❌ Invalid plan.")
                    return
                _db.add_plan_stack(tuid, plan, days)
                _db.admin_log(uid, 'add_sub', tuid, f"{plan} {days}d")
                safe_send(uid, f"✅ {PLAN_LIMITS[plan]['name']} ({days}d) → <code>{tuid}</code>")
                safe_send(tuid, f"🎉 Plan activated: {PLAN_LIMITS[plan]['name']} ({days} days)")
            except (ValueError, IndexError):
                safe_send(uid, "❌ Format: USER_ID PLAN DAYS")
            state.clear(uid)

        elif action == 'adm_remsub':
            try:
                tuid = int(txt)
                _db.rem_plan(tuid)
                _db.admin_log(uid, 'rem_sub', tuid)
                safe_send(uid, f"✅ Sub removed from <code>{tuid}</code>")
            except ValueError:
                safe_send(uid, "❌ Invalid ID")
            state.clear(uid)

        elif action == 'adm_userinfo':
            try:
                tuid = int(txt)
                u2   = _db.get_user(tuid)
                if not u2:
                    safe_send(uid, f"❌ Not found: <code>{tuid}</code>")
                else:
                    plan_display = _db.get_active_plan_display(tuid)
                    total        = _db.get_total_bots(tuid)
                    total_ram    = _db.get_total_ram(tuid)
                    per_bot_ram  = _db.get_ram_per_bot(tuid)
                    safe_send(uid,
                              f"👤 <b>User Info</b>\n━━━━━━━━━━━━━━━━\n\n"
                              f"🆔 <code>{tuid}</code>\n"
                              f"👤 {u2.get('full_name','')}\n"
                              f"💎 {plan_display}\n"
                              f"🤖 Bots: {_db.bot_count(tuid)}/{total if total!=-1 else '♾️'}\n"
                              f"💾 Total RAM: {total_ram}MB | Per-bot: {per_bot_ram}MB\n"
                              f"💰 {u2.get('wallet',0)} BDT\n"
                              f"🎁 Refs: {u2.get('ref_count',0)}\n"
                              f"📅 Expires: {time_left(u2.get('sub_end'))}\n"
                              f"🚫 Banned: {'Yes' if u2.get('is_banned') else 'No'}\n"
                              f"📅 Joined: {str(u2.get('created_at',''))[:10]}")
            except ValueError:
                safe_send(uid, "❌ Invalid ID")
            state.clear(uid)

        elif action == 'adm_backup_ch':
            try:
                new_ch = int(txt)
                _db.set_backup_channel(new_ch)
                safe_send(uid, f"✅ Backup channel set to <code>{new_ch}</code>")
            except ValueError:
                safe_send(uid, "❌ Invalid channel ID")
            state.clear(uid)

        elif action == 'adm_set_commission':
            try:
                val = int(txt.strip())
                if not 1 <= val <= 100:
                    raise ValueError
                _db.set_setting('ref_commission', val)
                safe_send(uid, f"✅ Referral commission <b>{val}%</b> এ set করা হয়েছে!")
            except ValueError:
                safe_send(uid, "❌ সঠিক সংখ্যা দিন (1-100)")
            state.clear(uid)

        elif action == 'adm_set_bonus':
            try:
                val = int(txt.strip())
                if val < 0:
                    raise ValueError
                _db.set_setting('ref_bonus_days', val)
                safe_send(uid, f"✅ Referral bonus <b>{val} days</b> এ set করা হয়েছে!")
            except ValueError:
                safe_send(uid, "❌ সঠিক সংখ্যা দিন")
            state.clear(uid)

        elif action == 'adm_set_minwd':
            try:
                val = int(txt.strip())
                if val < 0:
                    raise ValueError
                _db.set_setting('min_withdraw', val)
                safe_send(uid, f"✅ Minimum withdrawal <b>{val} BDT</b> এ set করা হয়েছে!")
            except ValueError:
                safe_send(uid, "❌ সঠিক সংখ্যা দিন")
            state.clear(uid)

        elif action == 'adm_ch_add':
            un2     = txt.strip().lstrip('@')
            ch_name = un2
            try:
                ch_info = _bot.get_chat(f"@{un2}")
                ch_name = ch_info.title or un2
            except: pass
            _db.add_channel(un2, name=ch_name, added_by=uid)
            _db.admin_log(uid, 'add_channel', details=un2)
            safe_send(uid, f"✅ @{un2} added! Name: <b>{ch_name}</b>")
            state.clear(uid)

        elif action == 'adm_promo_create':
            try:
                parts = txt.split()
                code  = parts[0].upper()
                disc  = int(parts[1])
                uses  = int(parts[2]) if len(parts) > 2 else 100
                _db.add_promo(code, disc, uses, uid)
                safe_send(uid, f"✅ Promo <code>{code}</code> — {disc}% | Max: {uses}")
            except (ValueError, IndexError):
                safe_send(uid, "❌ Format: CODE DISCOUNT MAX_USES")
            state.clear(uid)

        else:
            state.clear(uid)
            _show_home(uid, msg.from_user.full_name or '')


    # ─── CALLBACKS ─────────────────────────────────────────────────
    @bot.callback_query_handler(func=lambda c: True)
    def handle_cb(call):
        uid  = call.from_user.id
        data = call.data
        lang = _lang(uid)
        uname = call.from_user.username or ''

        try:
            _bot.answer_callback_query(call.id)
        except: pass

        # ── Session Guard ─────────────────────────────────────────
        if _session_guard:
            _session_guard.touch(uid, uname)

        # ── IDS: callback flood ───────────────────────────────────
        if _ids and _ids.record_callback(uid, uname):
            safe_edit(call, "⚠️ অনেক বেশি request। একটু অপেক্ষা করুন।")
            return

        if not state.is_admin(uid) and _check_banned(uid):
            return

        # FIX: global force_sub guard — all callbacks except lang picker & verify
        _fsub_exempt = data.startswith('lang_') or data == 'fsub_verify'
        if not state.is_admin(uid) and not _fsub_exempt:
            not_joined = _check_force_sub(uid)
            if not_joined:
                chs = ''.join(f"\n\u2022 @{c.get('username','')}" for c in not_joined)
                safe_edit(call, t('force_sub', lang, channels=chs),
                          reply_markup=channel_fsub_kb(not_joined, lang))
                return

        # ── Language ──────────────────────────────────────────────
        if data.startswith('lang_'):
            new_lang = data.split('_')[1]
            _db.set_lang(uid, new_lang)
            # FIX: always get valid user object via _get_or_create
            u2 = _get_or_create(uid, call.from_user.username or '',
                                 call.from_user.full_name or '')
            not_joined = _check_force_sub(uid)
            if not_joined:
                chs = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
                safe_edit(call, t('force_sub', new_lang, channels=chs),
                          reply_markup=channel_fsub_kb(not_joined, new_lang))
                return
            # FIX: u2 always valid here — directly show home
            plan_name = _db.get_active_plan_display(uid)
            total   = _db.get_total_bots(uid)
            max_str = '♾️' if total == -1 else str(total)
            se      = u2.get('sub_end')
            expires = '♾️ Lifetime' if u2.get('is_lifetime') else time_left(se) if se else '7 days (Free)'
            safe_edit(call, t('welcome', new_lang,
                              name=call.from_user.full_name or '',
                              uid=uid, plan=plan_name,
                              bots=_db.bot_count(uid), max_bots=max_str, expires=expires),
                      reply_markup=main_menu_kb(uid, new_lang))
            return

        # ── Force Sub ─────────────────────────────────────────────
        if data == 'fsub_verify':
            not_joined = _check_force_sub(uid)
            if not_joined:
                chs = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
                safe_edit(call, t('force_sub', lang, channels=chs),
                          reply_markup=channel_fsub_kb(not_joined, lang))
                return  # FIX: join না করলে এখানেই থামো
            else:
                # FIX: channel join confirm হলে pending referral bonus দাও
                u_data = _db.get_user(uid)
                if u_data and u_data.get('ref_pending'):
                    ref_uid = int(u_data['ref_pending'])
                    _rc  = _db.get_ref_commission()
                    _rbd = _db.get_ref_bonus_days()
                    _db.add_referral(ref_uid, uid, _rc, _rbd)
                    _db.update_user(uid, ref_pending=None)
                    fn2 = call.from_user.full_name or ''
                    safe_send(ref_uid,
                              f"🎉 <b>New Referral!</b>\n\n"
                              f"👤 {fn2} joined & verified!\n"
                              f"💰 +{_rc} BDT | 📅 +{_rbd} days")
                _show_home_edit(call, uid)
            return

        # ── Home ──────────────────────────────────────────────────
        if data == 'go_home':
            not_joined = _check_force_sub(uid)
            if not_joined:
                chs = ''.join(f"\n• @{c.get('username','')}" for c in not_joined)
                safe_edit(call, t('force_sub', lang, channels=chs),
                          reply_markup=channel_fsub_kb(not_joined, lang))
                return
            _show_home_edit(call, uid)

        # ── My Bots ───────────────────────────────────────────────
        elif data == 'menu_mybots':
            bots = _db.get_bots(uid)
            if not bots:
                safe_edit(call, "🤖 <b>My Bots</b>\n\nNo bots deployed yet.",
                          reply_markup=back_home(lang))
            else:
                safe_edit(call,
                          f"🤖 <b>My Bots</b> ({len(bots)} total)\n━━━━━━━━━━━━━━━━",
                          reply_markup=bot_list_kb(bots, lang))

        elif data.startswith('bot_view:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b:
                safe_edit(call, "❌ Bot not found.")
                return
            sk       = f"{b['uid']}_{b['name']}"
            live     = is_running(sk)
            mem, cpu = bot_res(sk) if live else (0, 0)
            a_plan   = b.get('assigned_plan', 'free')
            p_info   = PLAN_LIMITS.get(a_plan, PLAN_LIMITS['free'])
            ram_lim  = _db.get_bot_ram_limit(b['uid'], b['name'])
            safe_edit(call,
                      f"🤖 <b>{b['name']}</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"📄 Entry: <code>{b.get('entry','?')}</code>\n"
                      f"🔤 {'🐍 Python' if b.get('ftype')=='py' else '🟨 Node.js'}\n"
                      f"💎 Plan: {p_info['name']}\n"
                      f"💾 RAM Limit: {ram_lim}MB\n"
                      f"📊 {'🟢 Running' if live else '🔴 Stopped'}\n"
                      f"🔄 Restarts: {b.get('restarts',0)}\n"
                      + (f"📈 {mem}MB / {ram_lim}MB | 🖥️ {cpu}%\n" if live else '')
                      + f"📅 Added: {str(b.get('created_at',''))[:10]}",
                      reply_markup=bot_action_kb(bid, live, lang))

        elif data.startswith('deploy_plan:'):
            # User selected which plan to deploy bot under
            parts = data.split(':', 2)
            if len(parts) < 3:
                return
            chosen_plan = parts[1]
            bot_nm      = parts[2]
            st2 = state.get(uid)
            if not st2 or st2.get('action') != 'pending_deploy' or st2.get('bot_name') != bot_nm:
                safe_edit(call, "❌ Session expired. Please upload the file again.")
                return
            fp2            = st2['fp']
            ef2            = st2['ef']
            ft2            = st2['ft']
            backup_msg_id2 = st2.get('backup_msg_id', 0)
            state.clear(uid)

            bid = _db.add_bot(uid, bot_nm, fp2, ef2, ft2, backup_msg_id2, chosen_plan)
            if not bid:
                safe_edit(call, "❌ Failed to save bot. Try again.")
                return

            p_info   = PLAN_LIMITS.get(chosen_plan, PLAN_LIMITS['free'])
            ti       = '🐍 Python' if ft2 == 'py' else '🟨 Node.js'
            safe_edit(call,
                      f"✅ <b>Bot Deployed!</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"🤖 <code>{bot_nm}</code>\n"
                      f"📄 Entry: <code>{ef2}</code>\n"
                      f"🔤 {ti}\n"
                      f"💎 Plan: {p_info['name']}\n"
                      f"💾 RAM: {p_info['ram']}MB\n"
                      f"💾 Backed up ✅",
                      reply_markup=bot_action_kb(bid, False, lang))

        elif data.startswith('bot_start:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or b['uid'] != uid:
                return
            if _db.is_free_expired(uid):
                mk = types.InlineKeyboardMarkup(row_width=2)
                mk.add(types.InlineKeyboardButton("💎 Upgrade", callback_data="menu_sub"),
                       types.InlineKeyboardButton("📺 Watch Ad", callback_data="menu_watchad"))
                safe_edit(call, t('free_limit', lang, name=b['name']), reply_markup=mk)
                return
            sk = f"{uid}_{b['name']}"
            if is_running(sk):
                safe_edit(call, "✅ Already running!", reply_markup=bot_action_kb(bid, True, lang))
                return
            safe_edit(call, f"🚀 Starting <b>{b['name']}</b>...")
            threading.Thread(target=run_bot, args=(bid, uid), daemon=True).start()

        elif data.startswith('bot_stop:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or (b['uid'] != uid and not state.is_admin(uid)):
                return
            sk = f"{b['uid']}_{b['name']}"
            if sk in bot_scripts:
                kill_tree(bot_scripts[sk])
                cleanup_script(sk)
            _db.update_bot(bid, status='stopped',
                           last_stop=datetime.now().isoformat())
            safe_edit(call, f"🛑 <b>{b['name']}</b> stopped.",
                      reply_markup=bot_action_kb(bid, False, lang))

        elif data.startswith('bot_restart:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or (b['uid'] != uid and not state.is_admin(uid)):
                return
            sk = f"{b['uid']}_{b['name']}"
            if sk in bot_scripts:
                kill_tree(bot_scripts[sk])
                cleanup_script(sk)
            _db.update_bot(bid, status='stopped',
                           restarts=b.get('restarts', 0) + 1)
            safe_edit(call, f"🔄 Restarting <b>{b['name']}</b>...")
            threading.Thread(target=run_bot, args=(bid, uid), daemon=True).start()

        elif data.startswith('bot_logs:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or (b['uid'] != uid and not state.is_admin(uid)):
                return
            sk  = f"{b['uid']}_{b['name']}"
            lp  = os.path.join(LOGS_DIR, f"{sk}.log")
            log = "(No logs yet)"
            if os.path.exists(lp):
                try:
                    with open(lp, 'r', encoding='utf-8', errors='ignore') as f:
                        log = f.read()[-2000:]
                except: pass
            safe_edit(call,
                      f"📋 <b>Logs: {b['name']}</b>\n━━━━━━━━━━━━━━━━\n"
                      f"<pre>{html_lib.escape(log[-1200:])}</pre>",
                      reply_markup=back2(f"bot_view:{bid}", "🔙 Back"))

        elif data.startswith('bot_res:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b:
                return
            sk        = f"{b['uid']}_{b['name']}"
            mem, cpu  = bot_res(sk)
            live      = is_running(sk)
            ram_limit = _db.get_total_ram(uid)
            tip = ''
            if mem > ram_limit * 0.9:
                from utils.helpers import recommend_plan
                _, rec_name = recommend_plan(mem)
                tip = f"\n💡 Recommend: {rec_name}"
            safe_edit(call,
                      f"📊 <b>Resources: {b['name']}</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"💾 {mem}MB / {ram_limit}MB\n🖥️ {cpu}%\n"
                      f"{'🟢 Running' if live else '🔴 Stopped'}{tip}",
                      reply_markup=back2(f"bot_view:{bid}", "🔙 Back"))

        elif data.startswith('bot_del:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or b['uid'] != uid:
                return
            safe_edit(call,
                      f"🗑️ <b>Delete Bot?</b>\n\n<code>{b['name']}</code>\n\nConfirm?",
                      reply_markup=bot_del_confirm_kb(bid, lang))

        elif data.startswith('bot_del_confirm:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or b['uid'] != uid:
                return
            sk = f"{uid}_{b['name']}"
            if sk in bot_scripts:
                kill_tree(bot_scripts[sk])
                cleanup_script(sk)
            import shutil
            fp = b.get('file_path', '')
            try:
                if os.path.isdir(fp):   shutil.rmtree(fp)
                elif os.path.isfile(fp): os.remove(fp)
            except: pass
            _db.del_bot(bid)
            safe_edit(call, f"✅ <b>{b['name']}</b> deleted.",
                      reply_markup=back_home(lang))

        elif data.startswith('bot_redetect:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b:
                return
            fp = b.get('file_path', '')
            if os.path.isdir(fp):
                ef, ft, conf = detect_entry(fp)
                if ef:
                    _db.update_bot(bid, entry=ef, ftype=ft)
                    ci = {'exact':'🎯','high':'✅','medium':'🟡','low':'⚠️'}.get(conf,'')
                    safe_edit(call,
                              f"🔍 <b>Re-detected!</b>\n\n"
                              f"📄 <code>{ef}</code> {ci}\n"
                              f"{'🐍 Python' if ft=='py' else '🟨 Node.js'}",
                              reply_markup=bot_action_kb(bid, False, lang))
                else:
                    safe_edit(call, "❌ Could not detect entry.",
                              reply_markup=back_home(lang))
            else:
                safe_edit(call, "❌ Bot folder not found.", reply_markup=back_home(lang))

        elif data.startswith('bot_dl:'):
            bid = data.split(':', 1)[1]
            b   = _db.get_bot(bid)
            if not b or b['uid'] != uid:
                return
            fp = b.get('file_path', '')
            safe_edit(call, f"📦 <b>{b['name']}</b> প্রস্তুত করছি...")
            try:
                if os.path.isdir(fp):
                    # Directory → ZIP করে পাঠাও
                    import tempfile
                    with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
                        tmp_path = tmp.name
                    with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                        for root, dirs, files in os.walk(fp):
                            dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', 'node_modules')]
                            for file in files:
                                full = os.path.join(root, file)
                                arc  = os.path.relpath(full, fp)
                                zf.write(full, arc)
                    with open(tmp_path, 'rb') as f:
                        _bot.send_document(uid, f,
                                           caption=f"📥 <b>{b['name']}</b>\n\n✅ আপনার bot file",
                                           parse_mode='HTML',
                                           visible_file_name=f"{b['name']}.zip")
                    os.remove(tmp_path)
                elif os.path.isfile(fp):
                    with open(fp, 'rb') as f:
                        _bot.send_document(uid, f,
                                           caption=f"📥 <b>{b['name']}</b>\n\n✅ আপনার bot file",
                                           parse_mode='HTML')
                else:
                    safe_send(uid, "❌ File পাওয়া যাচ্ছে না। Admin এর সাথে যোগাযোগ করুন।")
                    return
                safe_send(uid, "✅ Download সম্পন্ন!", reply_markup=back_home(lang))
            except Exception as e:
                logger.error(f"bot_dl error: {e}")
                safe_send(uid, f"❌ Download failed: {e}")

        # ── Deploy ────────────────────────────────────────────────
        elif data == 'menu_deploy':
            u = _db.get_user(uid)
            plan_name = _db.get_active_plan_display(uid)
            total   = _db.get_total_bots(uid)
            max_str = '♾️' if total == -1 else str(total)
            safe_edit(call, t('deploy_guide', lang, plan=plan_name,
                              used=_db.bot_count(uid), max=max_str),
                      reply_markup=back_home(lang))

        # ── Subscription ──────────────────────────────────────────
        elif data == 'menu_sub':
            safe_edit(call, t('sub_guide', lang), reply_markup=plan_list_kb(lang))

        elif data.startswith('plan_select:'):
            pk = data.split(':', 1)[1]
            if pk not in PLAN_LIMITS:
                return
            p           = PLAN_LIMITS[pk]
            bots        = p['bots']
            bots_str    = '♾️' if bots == -1 else str(bots)
            ar          = "✅" if p['auto_restart'] else "❌"
            per_bot_ram = p['per_bot_ram']
            total_ram   = p['ram']

            safe_edit(call,
                      f"{p['name']}\n━━━━━━━━━━━━━━━━\n\n"
                      f"🤖 Bot সংখ্যা: {bots_str} টি\n"
                      f"💾 প্রতি Bot এ: {per_bot_ram}MB RAM\n"
                      f"📦 মোট RAM ব্যবহার: {total_ram}MB\n\n"
                      f"📅 মেয়াদ: {p['days']} দিন\n"
                      f"🔄 Auto-restart: {ar}\n\n"
                      f"━━━━━━━━━━━━━━━━\n"
                      f"💡 <b>এই plan-এ:</b>\n"
                      f"• প্রতিটি bot আলাদাভাবে {per_bot_ram}MB পাবে\n"
                      f"• সর্বোচ্চ {bots_str} টি bot একসাথে চলবে\n"
                      f"• RAM ভাগ হবে না — প্রতিটা bot পুরোটা পাবে\n\n"
                      f"💰 মূল্য: <b>{p['price_bdt']} BDT</b> / {p['price_usdt']} USDT",
                      reply_markup=plan_detail_kb(pk, lang))

        elif data.startswith('plan_buy:'):
            pk = data.split(':', 1)[1]
            if pk not in PLAN_LIMITS:
                return
            p = PLAN_LIMITS[pk]
            safe_edit(call,
                      f"💳 <b>Payment Method</b>\n\n"
                      f"💎 {p['name']}\n💰 {p['price_bdt']} BDT / {p['price_usdt']} USDT",
                      reply_markup=pay_method_kb(pk, lang))

        elif data.startswith('pay_method:'):
            parts  = data.split(':')
            pk     = parts[1]
            method = parts[2]
            if pk not in PLAN_LIMITS or method not in PAYMENT_METHODS:
                return
            pm     = PAYMENT_METHODS[method]
            p      = PLAN_LIMITS[pk]
            cur    = pm['currency']
            amount = p['price_usdt'] if cur == 'USDT' else p['price_bdt']
            state.set_pay(uid, {'plan': pk, 'method': method})
            state.set(uid, {'action': 'pay_trx'})
            safe_edit(call,
                      f"💳 <b>Payment Details</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"{pm['icon']} <b>{pm['name']}</b>\n"
                      f"📱 Send to: <code>{pm['number']}</code>\n"
                      f"💰 Amount: <b>{amount} {cur}</b>\n\n"
                      f"After sending, reply with your TRX ID:")

        elif data.startswith('pay_wallet:'):
            pk = data.split(':', 1)[1]
            if pk not in PLAN_LIMITS:
                return
            u2  = _db.get_user(uid)
            p   = PLAN_LIMITS[pk]
            bal = u2.get('wallet', 0) if u2 else 0
            amt = p['price_bdt']
            if bal < amt:
                safe_edit(call,
                          f"❌ <b>Insufficient Balance!</b>\n\n"
                          f"Balance: {bal} BDT | Need: {amt} BDT",
                          reply_markup=back2("menu_sub", "🔙 Plans"))
                return
            _db.wallet_tx(uid, -amt, 'purchase', f"Plan: {pk}")
            _db.add_plan_stack(uid, pk, p['days'])
            safe_edit(call,
                      f"✅ <b>Plan Activated via Wallet!</b>\n\n"
                      f"💎 {p['name']} | 📅 {p['days']} days",
                      reply_markup=back_home(lang))

        # ── Wallet ────────────────────────────────────────────────
        elif data == 'menu_wallet':
            u2  = _db.get_user(uid)
            bal = u2.get('wallet', 0) if u2 else 0
            ref = u2.get('ref_earn', 0) if u2 else 0
            mk  = types.InlineKeyboardMarkup(row_width=2)
            mk.add(types.InlineKeyboardButton("💸 Withdraw", callback_data="menu_withdraw"),
                   types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
            safe_edit(call, t('wallet_info', lang, balance=bal, ref_earn=ref), reply_markup=mk)

        elif data == 'menu_withdraw':
            u2  = _db.get_user(uid)
            bal = u2.get('wallet', 0) if u2 else 0
            safe_edit(call,
                      f"💸 <b>Withdraw</b>\n\nBalance: {bal} BDT\nMin: {MIN_WITHDRAW} BDT\n\nSelect method:",
                      reply_markup=wd_method_kb(lang))

        elif data.startswith('wd_method:'):
            method = data.split(':', 1)[1]
            state.set(uid, {'action': 'wd_amount', 'method': method})
            safe_edit(call, f"💸 Withdraw via {method.capitalize()}\n\nEnter amount (Min: {MIN_WITHDRAW} BDT):")

        # ── Ad ────────────────────────────────────────────────────
        elif data == 'menu_watchad':
            if not _db.can_watch_ad(uid):
                safe_edit(call, "⏰ আপনি ২৪ ঘন্টায় একবারই ad দেখতে পারবেন।",
                          reply_markup=back_home(lang))
                return
            # Token generate করো এবং DB তে save করো
            token = _make_ad_token(uid)
            _db.save_ad_token(uid, token)
            ad_link = f"{AD_SERVER_URL}?t={token}"
            mk = types.InlineKeyboardMarkup()
            mk.add(types.InlineKeyboardButton("📺 Ad দেখুন", url=ad_link))
            mk.add(types.InlineKeyboardButton("✅ আমার কাছে Code আছে", callback_data="ad_enter_code"))
            mk.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
            safe_edit(call,
                      "📺 <b>Ad দেখে Reward পান!</b>\n"
                      "━━━━━━━━━━━━━━━━\n\n"
                      "1️⃣ উপরের <b>Ad দেখুন</b> বাটনে ক্লিক করুন\n"
                      "2️⃣ Ad দেখুন এবং <b>6-digit code</b> নিন\n"
                      "3️⃣ <b>আমার কাছে Code আছে</b> বাটনে ক্লিক করুন\n\n"
                      "⏰ লিংক <b>৩০ মিনিট</b> পর্যন্ত valid\n"
                      "🎁 Reward: +24 ঘন্টা hosting",
                      reply_markup=mk)

        elif data == 'ad_enter_code':
            # User কে code টাইপ করতে বলো
            state.set(uid, {'action': 'ad_code_input'})
            mk = types.InlineKeyboardMarkup()
            mk.add(types.InlineKeyboardButton("❌ বাতিল", callback_data="go_home"))
            safe_edit(call,
                      "🔢 <b>Code লিখুন</b>\n\n"
                      "Ad দেখার পর যে <b>6-digit code</b> পেয়েছেন সেটি পাঠান:",
                      reply_markup=mk)

        # ── Referral ──────────────────────────────────────────────
        elif data == 'menu_ref':
            u2  = _db.get_user(uid)
            rc  = u2.get('ref_code', gen_ref_code(uid)) if u2 else gen_ref_code(uid)
            try:
                bun = _bot.get_me().username
            except:
                bun = 'your_bot'
            link   = f"https://t.me/{bun}?start=ref_{rc}"
            board  = _db.get_leaderboard(5)
            medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣']
            bt = ''.join(f"{medals[i]} {r.get('full_name','?')} — {r.get('ref_count',0)}\n"
                         for i, r in enumerate(board))
            mk = types.InlineKeyboardMarkup()
            mk.add(types.InlineKeyboardButton("📤 Share Link", url=link))
            mk.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
            safe_edit(call,
                      f"🎁 <b>Referral System</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"🔗 <code>{link}</code>\n\n"
                      f"💰 Per ref: +{_db.get_ref_commission()} BDT | +{_db.get_ref_bonus_days()} days\n"
                      f"👥 Total: {u2.get('ref_count',0) if u2 else 0}\n"
                      f"💵 Earned: {u2.get('ref_earn',0) if u2 else 0} BDT\n\n"
                      f"🏆 <b>Top Referrers:</b>\n{bt or 'Be the first!'}",
                      reply_markup=mk)

        # ── Stats ─────────────────────────────────────────────────
        elif data == 'menu_stats':
            u2         = _db.get_user(uid)
            bots       = _db.get_bots(uid)
            running    = sum(1 for b in bots if is_running(f"{uid}_{b['name']}"))
            plan_name  = _db.get_active_plan_display(uid)
            total      = _db.get_total_bots(uid)
            total_ram  = _db.get_total_ram(uid)
            per_bot_ram = _db.get_ram_per_bot(uid)
            safe_edit(call,
                      f"📊 <b>My Stats</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"💎 {plan_name}\n"
                      f"🤖 {len(bots)} bots | 🟢 {running} running\n"
                      f"🎯 {len(bots)}/{total if total!=-1 else '♾️'} slots\n"
                      f"💾 Total RAM: {total_ram}MB | Per-bot: {per_bot_ram}MB\n"
                      f"💰 {u2.get('wallet',0) if u2 else 0} BDT\n"
                      f"🎁 {u2.get('ref_count',0) if u2 else 0} referrals\n"
                      f"📅 Since: {str(u2.get('created_at',''))[:10] if u2 else '?'}",
                      reply_markup=back_home(lang))

        # ── Running ───────────────────────────────────────────────
        elif data == 'menu_running':
            bots    = _db.get_bots(uid)
            running = [b for b in bots if is_running(f"{uid}_{b['name']}")]
            if not running:
                safe_edit(call, "🟢 <b>Running Bots</b>\n\nNone running.",
                          reply_markup=back_home(lang))
                return
            text = f"🟢 <b>Running Bots</b> ({len(running)})\n━━━━━━━━━━━━━━━━\n\n"
            for b in running:
                sk        = f"{uid}_{b['name']}"
                mem, cpu  = bot_res(sk)
                i2        = bot_scripts.get(sk, {})
                mins      = int((datetime.now() - i2.get('start_time', datetime.now())).total_seconds() // 60)
                ram_lim   = _db.get_bot_ram_limit(uid, b['name'])
                text     += f"🟢 <b>{b['name']}</b> | {mem}/{ram_lim}MB | ⏱️ {mins}m\n"
            safe_edit(call, text, reply_markup=back_home(lang))

        # ── Notifications ─────────────────────────────────────────
        elif data == 'menu_notif':
            notifs = _db.get_notifs(uid, 10)
            _db.mark_read(uid)
            text = "🔔 <b>Notifications</b>\n━━━━━━━━━━━━━━━━\n\n"
            text += ''.join(f"📌 <b>{n.get('title','')}</b>\n{n.get('message','')}\n\n"
                            for n in notifs) or "No notifications."
            safe_edit(call, text, reply_markup=back_home(lang))

        # ── Settings ──────────────────────────────────────────────
        elif data == 'menu_settings':
            safe_edit(call, "⚙️ <b>Settings</b>", reply_markup=settings_kb(uid, lang))

        elif data == 'settings_lang':
            safe_edit(call, t('choose_language'), reply_markup=lang_kb())

        # ── Help ──────────────────────────────────────────────────
        elif data == 'menu_help':
            safe_edit(call, t('help_main', lang), reply_markup=help_kb(lang))

        elif data == 'help_deploy':
            safe_edit(call, t('help_deploy', lang),
                      reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_plans':
            text = "💎 <b>Plans</b>\n━━━━━━━━━━━━━━━━\n\n"
            for k, p in PLAN_LIMITS.items():
                slots = '♾️' if p['bots'] == -1 else str(p['bots'])
                text += f"{p['name']}: {slots} bots | প্রতিটায় {p['per_bot_ram']}MB | {p['price_bdt']} BDT\n"
            text += "\n💡 RAM ভাগ হয় না — প্রতিটি bot আলাদা করে পুরো RAM পায়"
            safe_edit(call, text, reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_payment':
            text = "💳 <b>Payment</b>\n━━━━━━━━━━━━━━━━\n\n"
            for k, v in PAYMENT_METHODS.items():
                text += f"{v['icon']} {v['name']}: <code>{v['number']}</code> ({v['currency']})\n"
            safe_edit(call, text, reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_ref':
            safe_edit(call,
                      f"🎁 <b>Referral Guide</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"1. Share your link\n2. Friend joins\n"
                      f"3. You get +{_db.get_ref_commission()} BDT & +{_db.get_ref_bonus_days()} days",
                      reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_wallet':
            safe_edit(call,
                      f"💰 <b>Wallet Guide</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"Earn: referrals & ads\n"
                      f"Use: buy plans\nWithdraw min: {MIN_WITHDRAW} BDT",
                      reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_faq':
            safe_edit(call,
                      "❓ <b>FAQ</b>\n━━━━━━━━━━━━━━━━\n\n"
                      "Q: Can I stack plans?\nA: Yes!\n\n"
                      "Q: What if bot crashes?\nA: Paid plans auto-restart.\n\n"
                      "Q: requirements.txt needed?\nA: Auto-detected from imports!",
                      reply_markup=back2("menu_help", "🔙 Help"))

        elif data == 'help_ad':
            safe_edit(call, t('ad_info', lang), reply_markup=back2("menu_help", "🔙 Help"))

        # ── Admin ─────────────────────────────────────────────────
        elif data == 'menu_admin':
            if not state.is_admin(uid): return
            safe_edit(call, "👑 <b>Admin Panel</b>", reply_markup=admin_kb(lang))

        elif data == 'adm_stats':
            if not state.is_admin(uid): return
            s  = _db.stats()
            ss = sys_stats()
            rn = sum(1 for sk in bot_scripts if is_running(sk))
            safe_edit(call,
                      f"📊 <b>Stats</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"👥 {s['users']} users (+{s['today_users']} today)\n"
                      f"🤖 {s['bots']} bots | 🟢 {rn}\n"
                      f"💳 Pending pay: {s['pending_pay']}\n"
                      f"💸 Pending WD: {s['pending_wd']}\n"
                      f"💰 Revenue: {s['revenue']} BDT\n"
                      f"🚫 Banned: {s['banned']}\n\n"
                      f"🖥️ {ss['cpu']}% | 💾 {ss['mem']}% | ⏱️ {ss['up']}",
                      reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_users':
            if not state.is_admin(uid): return
            users = _db.get_all_users()
            text  = f"👥 <b>Users</b> ({len(users)})\n━━━━━━━━━━━━━━━━\n\n"
            for u2 in users[:15]:
                icon      = '🚫' if u2.get('is_banned') else '✅'
                plan_disp = _db.get_active_plan_display(u2['uid'])
                text += f"{icon} <code>{u2['uid']}</code> {u2.get('full_name','?')} | {plan_disp}\n"
            if len(users) > 15:
                text += f"...+{len(users)-15} more"
            safe_edit(call, text, reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_payments':
            if not state.is_admin(uid): return
            pays = _db.pending_payments()
            if not pays:
                safe_edit(call, "💳 No pending.", reply_markup=back2("menu_admin", "🔙 Admin"))
                return
            safe_edit(call, f"💳 {len(pays)} pending payments",
                      reply_markup=back2("menu_admin", "🔙 Admin"))
            for p2 in pays[:5]:
                pid = p2.get('pid','?')
                safe_send(uid,
                          f"💳 #{pid}\n👤 <code>{p2.get('uid')}</code>\n"
                          f"💰 {p2.get('amount')} {p2.get('currency','BDT')} | {p2.get('plan')}\n"
                          f"🔖 <code>{p2.get('trx_id')}</code>",
                          reply_markup=pay_approve_kb(pid))

        elif data.startswith('adm_pay_approve:'):
            if not state.is_admin(uid): return
            pid = data.split(':', 1)[1]
            p   = _db.approve_payment(pid, uid)
            if p:
                _db.admin_log(uid, 'approve_pay', p['uid'])
                safe_edit(call, "✅ Approved!")
                safe_send(p['uid'],
                          f"✅ <b>Payment Approved!</b>\n"
                          f"💎 {PLAN_LIMITS.get(p['plan'],{}).get('name',p['plan'])} activated!\n"
                          f"📅 {p.get('duration_days',30)} days added.")

        elif data.startswith('adm_pay_reject:'):
            if not state.is_admin(uid): return
            pid = data.split(':', 1)[1]
            p   = _db.get_payment(pid)
            _db.reject_payment(pid, uid)
            safe_edit(call, "❌ Rejected.")
            if p:
                safe_send(p['uid'], "❌ Payment rejected. Contact @arafat_codex1.")

        elif data == 'adm_withdrawals':
            if not state.is_admin(uid): return
            wds = _db.pending_withdrawals()
            if not wds:
                safe_edit(call, "💸 No pending.", reply_markup=back2("menu_admin", "🔙 Admin"))
                return
            safe_edit(call, f"💸 {len(wds)} pending",
                      reply_markup=back2("menu_admin", "🔙 Admin"))
            for w in wds[:5]:
                wid = w.get('wid','?')
                safe_send(uid,
                          f"💸 #{wid}\n👤 <code>{w.get('uid')}</code>\n"
                          f"💰 {w.get('amount')} BDT | {w.get('method')}\n"
                          f"📲 <code>{w.get('account')}</code>",
                          reply_markup=wd_approve_kb(wid))

        elif data.startswith('adm_wd_approve:'):
            if not state.is_admin(uid): return
            wid = data.split(':', 1)[1]
            w   = _db.get_withdrawal(wid)
            _db.approve_withdrawal(wid, uid)
            safe_edit(call, "✅ Withdrawal done!")
            if w:
                safe_send(w['uid'], f"✅ {w['amount']} BDT sent!")

        elif data.startswith('adm_wd_reject:'):
            if not state.is_admin(uid): return
            wid = data.split(':', 1)[1]
            _db.reject_withdrawal(wid, uid)
            safe_edit(call, "❌ Rejected & refunded.")

        elif data == 'adm_addsub':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_addsub'})
            safe_edit(call, "➕ Format: <code>USER_ID PLAN DAYS</code>")

        elif data == 'adm_remsub':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_remsub'})
            safe_edit(call, "➖ Enter User ID:")

        elif data == 'adm_ban':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_ban'})
            safe_edit(call, "🚫 Enter User ID:")

        elif data == 'adm_unban':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_unban'})
            safe_edit(call, "✅ Enter User ID:")

        elif data == 'adm_give_bal':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_give_bal'})
            safe_edit(call, "💰 Format: <code>USER_ID AMOUNT</code>")

        elif data == 'adm_broadcast':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_broadcast'})
            safe_edit(call, "📢 Send your message:")

        elif data == 'adm_userinfo':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_userinfo'})
            safe_edit(call, "🔍 Enter User ID:")

        elif data == 'adm_ref_settings':
            if not state.is_admin(uid): return
            commission  = _db.get_ref_commission()
            bonus_days  = _db.get_ref_bonus_days()
            min_wd      = _db.get_min_withdraw()
            mk = types.InlineKeyboardMarkup(row_width=1)
            mk.add(
                types.InlineKeyboardButton(f"💸 Commission: {commission}% — পরিবর্তন করুন", callback_data="adm_set_commission"),
                types.InlineKeyboardButton(f"🎁 Bonus Days: {bonus_days} — পরিবর্তন করুন", callback_data="adm_set_bonus"),
                types.InlineKeyboardButton(f"💰 Min Withdraw: {min_wd} BDT — পরিবর্তন করুন", callback_data="adm_set_minwd"),
                types.InlineKeyboardButton("🔙 Admin", callback_data="menu_admin")
            )
            safe_edit(call,
                      f"⚙️ <b>Referral Settings</b>\n"
                      f"━━━━━━━━━━━━━━━━\n\n"
                      f"💸 Per-referral commission: <b>{commission}%</b>\n"
                      f"🎁 Bonus days per referral: <b>{bonus_days} days</b>\n"
                      f"💰 Minimum withdrawal: <b>{min_wd} BDT</b>",
                      reply_markup=mk)

        elif data == 'adm_set_commission':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_set_commission'})
            safe_edit(call, f"💸 বর্তমান commission: <b>{_db.get_ref_commission()}%</b>\n\nনতুন percentage লিখুন (যেমন: 25):")

        elif data == 'adm_set_bonus':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_set_bonus'})
            safe_edit(call, f"🎁 বর্তমান bonus: <b>{_db.get_ref_bonus_days()} days</b>\n\nনতুন days লিখুন (যেমন: 5):")

        elif data == 'adm_set_minwd':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_set_minwd'})
            safe_edit(call, f"💰 বর্তমান minimum: <b>{_db.get_min_withdraw()} BDT</b>\n\nনতুন amount লিখুন (যেমন: 100):")

        elif data.startswith('adm_qapprove:'):
            # ── Admin quarantine file approve করলো ──
            if not state.is_admin(uid): return
            parts2 = data.split(':')
            qid    = int(parts2[1])
            tuid   = int(parts2[2])
            q = _db.get_quarantine(qid)
            if not q:
                safe_edit(call, "❌ Quarantine entry পাওয়া যায়নি।")
                return
            _db.approve_quarantine(qid, uid)
            safe_edit(call,
                      f"✅ <b>File Approved!</b>\n"
                      f"User: <code>{tuid}</code>\n"
                      f"File: <code>{q.get('file_name','')}</code>\n\n"
                      f"Bot চালু করা যাবে এখন।")
            try:
                _bot.send_message(tuid,
                                  "✅ <b>আপনার file Approve হয়েছে!</b>\n\n"
                                  "Admin আপনার bot file review করে approve করেছে।\n"
                                  "এখন bot চালু করতে পারবেন।",
                                  parse_mode='HTML')
            except Exception: pass

        elif data.startswith('adm_qreject:'):
            # ── Admin quarantine file reject করলো ──
            if not state.is_admin(uid): return
            parts2 = data.split(':')
            qid    = int(parts2[1])
            tuid   = int(parts2[2])
            q = _db.get_quarantine(qid)
            fname  = q.get('file_name','') if q else ''
            _db.reject_quarantine(qid, uid)
            safe_edit(call,
                      f"🗑️ <b>File Rejected & Deleted!</b>\n"
                      f"User: <code>{tuid}</code>\n"
                      f"File: <code>{fname}</code>")
            try:
                _bot.send_message(tuid,
                                  "🗑️ <b>আপনার file Reject হয়েছে।</b>\n\n"
                                  "Admin আপনার bot file-এ সমস্যা পেয়ে delete করেছে।\n"
                                  "নতুন file upload করুন।",
                                  parse_mode='HTML')
            except Exception: pass

        elif data == 'adm_quarantine':
            # ── Pending quarantine list দেখাও ──
            if not state.is_admin(uid): return
            items = _db.get_pending_quarantine()
            if not items:
                safe_edit(call, "✅ কোনো pending quarantine file নেই।",
                          reply_markup=back_home(lang))
                return
            text = f"🔒 <b>Pending Quarantine ({len(items)})</b>\n━━━━━━━━━━━━━━━━\n\n"
            mk2  = types.InlineKeyboardMarkup()
            for item in items[:10]:
                qid2  = item[0] if isinstance(item, (list, tuple)) else item.get('qid')
                tuid2 = item[1] if isinstance(item, (list, tuple)) else item.get('uid')
                fname2= item[4] if isinstance(item, (list, tuple)) else item.get('file_name','?')
                text += f"🔢 ID: <code>{qid2}</code> | User: <code>{tuid2}</code> | File: {fname2}\n"
                mk2.add(
                    types.InlineKeyboardButton(f"✅ {qid2}", callback_data=f"adm_qapprove:{qid2}:{tuid2}"),
                    types.InlineKeyboardButton(f"🗑️ {qid2}", callback_data=f"adm_qreject:{qid2}:{tuid2}")
                )
            mk2.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
            safe_edit(call, text, reply_markup=mk2)

        elif data == 'adm_clear_menu':
            # ── Bot menu (commands) clear করো ──
            if not state.is_admin(uid): return
            try:
                _bot.delete_my_commands()
                safe_edit(call,
                          "✅ <b>Bot menu সম্পূর্ণ clear হয়েছে!</b>\n\n"
                          "Telegram এ bot এর নিচের menu button গুলো চলে গেছে।\n"
                          "User রা আর ওই commands দেখতে পাবে না।",
                          reply_markup=back_home(lang))
            except Exception as e:
                safe_edit(call, f"❌ Menu clear failed: {e}", reply_markup=back_home(lang))

        elif data == 'adm_reset_menu':
            # ── Default AHC menu restore করো ──
            if not state.is_admin(uid): return
            try:
                from telebot.types import BotCommand
                cmds = [
                    BotCommand('start', '🏠 Home'),
                    BotCommand('help',  '❓ Help'),
                    BotCommand('plans', '📦 Plans'),
                ]
                _bot.set_my_commands(cmds)
                safe_edit(call,
                          "✅ <b>Bot menu reset হয়েছে!</b>\n\n"
                          "Default AHC commands restore হয়েছে।",
                          reply_markup=back_home(lang))
            except Exception as e:
                safe_edit(call, f"❌ Menu reset failed: {e}", reply_markup=back_home(lang))

        elif data == 'adm_backup_ch':
            if not state.is_admin(uid): return
            ch = _db.get_backup_channel()
            state.set(uid, {'action': 'adm_backup_ch'})
            safe_edit(call, f"📡 Current: <code>{ch}</code>\nEnter new channel ID:")

        elif data == 'adm_channels':
            if not state.is_admin(uid): return
            chs  = _db.get_all_channels()
            text = "📢 <b>Force Subscribe Channels</b>\n━━━━━━━━━━━━━━━━\n\n"
            for c in chs:
                icon  = '🟢' if c.get('is_active') else '🔴'
                text += f"{icon} @{c.get('username')} — {c.get('name','')}\n"
            mk = types.InlineKeyboardMarkup(row_width=1)
            mk.add(types.InlineKeyboardButton("➕ Add Channel", callback_data="adm_ch_add"))
            for c in chs:
                un2 = c.get('username','')
                mk.add(types.InlineKeyboardButton(
                    f"{'🟢' if c.get('is_active') else '🔴'} Toggle @{un2}",
                    callback_data=f"adm_ch_toggle:{un2}"))
            mk.add(types.InlineKeyboardButton("🔙 Admin", callback_data="menu_admin"))
            safe_edit(call, text or "No channels set.", reply_markup=mk)

        elif data == 'adm_ch_add':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_ch_add'})
            safe_edit(call, "➕ Enter channel username (no @):")

        elif data.startswith('adm_ch_toggle:'):
            if not state.is_admin(uid): return
            ch_un = data.split(':', 1)[1]
            chs   = _db.get_all_channels()
            found = next((c for c in chs if c.get('username') == ch_un), None)
            if found:
                if found.get('is_active'):
                    _db.remove_channel(ch_un)
                    safe_edit(call, f"🔴 @{ch_un} disabled.",
                              reply_markup=back2("adm_channels", "🔙 Channels"))
                else:
                    _db.add_channel(ch_un, found.get('name',''), uid)
                    safe_edit(call, f"🟢 @{ch_un} enabled.",
                              reply_markup=back2("adm_channels", "🔙 Channels"))

        elif data == 'adm_promo':
            if not state.is_admin(uid): return
            promos = _db.all_promos()
            text   = "🎟️ <b>Promo Codes</b>\n━━━━━━━━━━━━━━━━\n\n"
            for p2 in promos:
                icon  = '✅' if p2.get('is_active') else '❌'
                text += f"{icon} <code>{p2.get('code')}</code> {p2.get('discount')}% | {p2.get('used_count')}/{p2.get('max_uses')}\n"
            mk = types.InlineKeyboardMarkup()
            mk.add(types.InlineKeyboardButton("➕ Create", callback_data="adm_promo_create"))
            mk.add(types.InlineKeyboardButton("🔙 Admin", callback_data="menu_admin"))
            safe_edit(call, text or "None.", reply_markup=mk)

        elif data == 'adm_promo_create':
            if not state.is_admin(uid): return
            state.set(uid, {'action': 'adm_promo_create'})
            safe_edit(call, "🎟️ Format: <code>CODE DISCOUNT MAX_USES</code>")

        elif data == 'adm_system':
            if not state.is_admin(uid): return
            ss = sys_stats()
            rn = sum(1 for sk in bot_scripts if is_running(sk))
            safe_edit(call,
                      f"🖥️ <b>System</b>\n━━━━━━━━━━━━━━━━\n\n"
                      f"⏱️ {ss['up']}\n🖥️ {ss['cpu']}%\n"
                      f"💾 {ss['mem_used']}/{ss['mem_total']} ({ss['mem']}%)\n"
                      f"📂 {ss['disk_used']}/{ss['disk_total']}\n"
                      f"🤖 {rn} running",
                      reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_running':
            if not state.is_admin(uid): return
            running = [(sk, i) for sk, i in bot_scripts.items() if is_running(sk)]
            text    = f"🤖 <b>Running</b> ({len(running)})\n━━━━━━━━━━━━━━━━\n\n"
            for sk, i in running[:15]:
                mem, cpu = bot_res(sk)
                text    += f"🟢 {i.get('name',sk)} | <code>{i.get('uid','?')}</code> | {mem}MB\n"
            if not running:
                text += "None."
            safe_edit(call, text, reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_stopall':
            if not state.is_admin(uid): return
            stopped = 0
            for sk, i in list(bot_scripts.items()):
                kill_tree(i)
                cleanup_script(sk)
                bid2 = i.get('bot_id')
                if bid2:
                    _db.update_bot(bid2, status='stopped')
                stopped += 1
            _db.admin_log(uid, 'stop_all', details=f"{stopped}")
            safe_edit(call, f"🛑 {stopped} bots stopped.",
                      reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_errorlogs':
            if not state.is_admin(uid): return
            logs = _db.get_error_logs(10)
            text = "❌ <b>Errors</b>\n━━━━━━━━━━━━━━━━\n\n"
            for l in logs:
                text += f"[{str(l.get('created_at',''))[:16]}] {str(l.get('message',''))[:80]}\n\n"
            safe_edit(call, text or "None.", reply_markup=back2("menu_admin", "🔙 Admin"))

        # ── Security Dashboard ─────────────────────────────────────
        elif data == 'adm_security':
            if not state.is_admin(uid): return
            ss    = sys_stats()
            scan  = _db.get_scan_stats()
            slogs = _db.get_security_logs(5)
            rn    = sum(1 for sk in bot_scripts if is_running(sk))
            text  = (
                f"🛡 <b>Security Dashboard</b>\n━━━━━━━━━━━━━━━━\n\n"
                f"🖥️ CPU: {ss['cpu']}% | 💾 RAM: {ss['mem']}%\n"
                f"🟢 Running bots: {rn}\n\n"
                f"🔍 <b>Scan Stats</b>\n"
                f"  Total scans  : {scan['total']}\n"
                f"  🚫 Blocked   : {scan['blocked']}\n"
                f"  ⚠️ Warnings  : {scan['warnings']}\n\n"
                f"🚨 <b>Recent Security Events</b>\n"
            )
            for l in slogs:
                ts  = str(l.get('created_at', ''))[:16]
                src = l.get('source', '?')
                msg = str(l.get('message', ''))[:80]
                lvl_icon = '🔴' if l.get('level') in ('CRITICAL','ERROR') else '🟡'
                text += f"{lvl_icon} [{ts}] {src}\n  {msg}\n\n"
            if not slogs:
                text += "✅ No security events.\n"
            mk = types.InlineKeyboardMarkup(row_width=2)
            mk.add(
                types.InlineKeyboardButton("🔴 Attack Logs",   callback_data="adm_attack_logs"),
                types.InlineKeyboardButton("📋 Access Logs",   callback_data="adm_access_logs"),
            )
            mk.add(
                types.InlineKeyboardButton("🔍 Scan Status",   callback_data="adm_scan_status"),
                types.InlineKeyboardButton("🔙 Admin",         callback_data="menu_admin"),
            )
            safe_edit(call, text, reply_markup=mk)

        elif data == 'adm_attack_logs':
            if not state.is_admin(uid): return
            logs = _db.get_security_logs(20)
            critical = [l for l in logs if l.get('level') in ('CRITICAL', 'ERROR', 'WARNING')]
            text = "🔴 <b>Attack / Intrusion Logs</b>\n━━━━━━━━━━━━━━━━\n\n"
            for l in critical[:10]:
                ts  = str(l.get('created_at', ''))[:16]
                msg = str(l.get('message', ''))[:100]
                uid2 = l.get('user_id', 'N/A')
                text += f"⚠️ [{ts}] uid={uid2}\n<code>{html_lib.escape(msg)}</code>\n\n"
            if not critical:
                text += "✅ No attacks logged."
            safe_edit(call, text, reply_markup=back2("adm_security", "🔙 Security"))

        elif data == 'adm_access_logs':
            if not state.is_admin(uid): return
            logs = _db.get_admin_logs(15)
            text = "📋 <b>Admin Access Logs</b>\n━━━━━━━━━━━━━━━━\n\n"
            for l in logs:
                ts     = str(l.get('created_at', ''))[:16]
                action = l.get('action', '?')
                adm    = l.get('admin_id', '?')
                target = l.get('target', '')
                text  += f"[{ts}] <code>{adm}</code> → {action}"
                if target: text += f" (target: {target})"
                text  += "\n"
            if not logs:
                text += "No logs yet."
            safe_edit(call, text, reply_markup=back2("adm_security", "🔙 Security"))

        elif data == 'adm_scan_status':
            if not state.is_admin(uid): return
            scan  = _db.get_scan_stats()
            qlogs = _db.get_security_logs(10)
            scan_events = [l for l in qlogs if 'scanner' in l.get('source','')]
            text  = (
                f"🔍 <b>File Scan Status</b>\n━━━━━━━━━━━━━━━━\n\n"
                f"📊 Total scans  : {scan['total']}\n"
                f"🚫 Blocked files: {scan['blocked']}\n"
                f"⚠️ Warnings     : {scan['warnings']}\n\n"
                f"<b>Recent Scan Events:</b>\n"
            )
            for l in scan_events[:8]:
                ts  = str(l.get('created_at',''))[:16]
                msg = str(l.get('message',''))[:100]
                text += f"[{ts}] <code>{html_lib.escape(msg)}</code>\n\n"
            if not scan_events:
                text += "✅ No scan alerts."
            safe_edit(call, text, reply_markup=back2("adm_security", "🔙 Security"))

        elif data == 'adm_dl_logs':
            if not state.is_admin(uid): return
            content = _db.export_error_log()
            buf     = io.BytesIO(content.encode('utf-8'))
            buf.name = f"errors_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
            _bot.send_document(uid, buf, caption="📥 Error Log")

        elif data == 'adm_cleanup':
            if not state.is_admin(uid): return
            import glob
            deleted = 0
            for f in glob.glob(os.path.join(LOGS_DIR, '*.log')):
                try:
                    os.remove(f)
                    deleted += 1
                except: pass
            _db.admin_log(uid, 'cleanup', details=f"logs={deleted}")
            safe_edit(call, f"🗑️ {deleted} log files deleted.",
                      reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_fsub_toggle':
            if not state.is_admin(uid): return
            state.force_sub_enabled = not state.force_sub_enabled
            icon = "🟢" if state.force_sub_enabled else "🔴"
            safe_edit(call, f"{icon} Force Subscribe {'enabled' if state.force_sub_enabled else 'disabled'}",
                      reply_markup=back2("menu_admin", "🔙 Admin"))

        elif data == 'adm_lock_toggle':
            if not state.is_admin(uid): return
            state.bot_locked = not state.bot_locked
            icon = "🔒" if state.bot_locked else "🔓"
            safe_edit(call, f"{icon} Bot {'locked' if state.bot_locked else 'unlocked'}",
                      reply_markup=back2("menu_admin", "🔙 Admin"))
