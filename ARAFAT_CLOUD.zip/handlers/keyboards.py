"""
☁️ ARAFAT HOSTING CLOUD — Keyboards v2.0
"""

from telebot import types
from config import PLAN_LIMITS, PAYMENT_METHODS, DEV_USERNAME
from core.state import state
from lang import t

_db = None

def init_kb(db): global _db; _db = db


def main_menu_kb(uid, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton(t('btn_mybots', lang),   callback_data="menu_mybots"),
        types.InlineKeyboardButton(t('btn_deploy', lang),   callback_data="menu_deploy")
    )
    m.add(
        types.InlineKeyboardButton(t('btn_sub', lang),      callback_data="menu_sub"),
        types.InlineKeyboardButton(t('btn_wallet', lang),   callback_data="menu_wallet")
    )
    m.add(
        types.InlineKeyboardButton(t('btn_referral', lang), callback_data="menu_ref"),
        types.InlineKeyboardButton(t('btn_stats', lang),    callback_data="menu_stats")
    )
    m.add(
        types.InlineKeyboardButton(t('btn_running', lang),  callback_data="menu_running"),
        types.InlineKeyboardButton(t('btn_notif', lang),    callback_data="menu_notif")
    )
    m.add(
        types.InlineKeyboardButton(t('btn_settings', lang), callback_data="menu_settings"),
        types.InlineKeyboardButton(t('btn_help', lang),     callback_data="menu_help")
    )
    m.add(types.InlineKeyboardButton(t('btn_watchad', lang), callback_data="menu_watchad"))
    m.add(types.InlineKeyboardButton(t('btn_contact', lang), url=f"https://t.me/arafat_codex1"))
    if state.is_admin(uid):
        m.add(types.InlineKeyboardButton(t('btn_admin', lang), callback_data="menu_admin"))
    return m


def back_home(lang='en'):
    m = types.InlineKeyboardMarkup()
    m.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
    return m


def back2(cb="go_home", l1="🔙 Back", cb2="go_home", l2="🏠 Menu"):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton(l1, callback_data=cb),
        types.InlineKeyboardButton(l2, callback_data=cb2)
    )
    return m


def lang_kb():
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("🇬🇧 English", callback_data="lang_en"),
        types.InlineKeyboardButton("🇧🇩 বাংলা",   callback_data="lang_bn")
    )
    return m


def bot_list_kb(bots, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=1)
    for b in bots:
        bid    = b.get('bid', b.get('_id', ''))
        name   = b.get('name', 'Unknown')
        status = b.get('status', 'stopped')
        icon   = '🟢' if status == 'running' else '🔴' if status == 'crashed' else '⚫'
        m.add(types.InlineKeyboardButton(f"{icon} {name[:30]}", callback_data=f"bot_view:{bid}"))
    m.add(types.InlineKeyboardButton("🚀 Deploy New Bot", callback_data="menu_deploy"))
    m.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
    return m


def bot_action_kb(bid, live, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    if live:
        m.add(
            types.InlineKeyboardButton("🛑 Stop",      callback_data=f"bot_stop:{bid}"),
            types.InlineKeyboardButton("🔄 Restart",   callback_data=f"bot_restart:{bid}")
        )
        m.add(
            types.InlineKeyboardButton("📋 Logs",      callback_data=f"bot_logs:{bid}"),
            types.InlineKeyboardButton("📊 Resources", callback_data=f"bot_res:{bid}")
        )
    else:
        m.add(
            types.InlineKeyboardButton("▶️ Start",     callback_data=f"bot_start:{bid}"),
            types.InlineKeyboardButton("🗑️ Delete",    callback_data=f"bot_del:{bid}")
        )
        m.add(
            types.InlineKeyboardButton("📋 Logs",      callback_data=f"bot_logs:{bid}"),
            types.InlineKeyboardButton("📥 Download",  callback_data=f"bot_dl:{bid}")
        )
        m.add(types.InlineKeyboardButton("🔍 Re-detect Entry", callback_data=f"bot_redetect:{bid}"))
    m.add(types.InlineKeyboardButton("🔙 My Bots", callback_data="menu_mybots"))
    return m


def bot_del_confirm_kb(bid, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("✅ Yes, Delete", callback_data=f"bot_del_confirm:{bid}"),
        types.InlineKeyboardButton(t('btn_cancel', lang), callback_data=f"bot_view:{bid}")
    )
    return m


def plan_list_kb(lang='en'):
    m = types.InlineKeyboardMarkup(row_width=1)
    for k, p in PLAN_LIMITS.items():
        slots = '♾️' if p['bots'] == -1 else str(p['bots'])
        price = f"{p['price_bdt']} BDT" if k != 'free' else '7 days free'
        m.add(types.InlineKeyboardButton(
            f"{p['name']} — {slots} bots — {price}",
            callback_data=f"plan_select:{k}"
        ))
    m.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
    return m


def plan_detail_kb(plan_key, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(types.InlineKeyboardButton("💳 Buy This Plan", callback_data=f"plan_buy:{plan_key}"))
    m.add(
        types.InlineKeyboardButton("🔙 Plans", callback_data="menu_sub"),
        types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home")
    )
    return m


def pay_method_kb(plan_key, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    for k, v in PAYMENT_METHODS.items():
        cur = v['currency']
        m.add(types.InlineKeyboardButton(
            f"{v['icon']} {v['name']} ({cur})",
            callback_data=f"pay_method:{plan_key}:{k}"
        ))
    m.add(types.InlineKeyboardButton("💰 Pay from Wallet", callback_data=f"pay_wallet:{plan_key}"))
    m.add(
        types.InlineKeyboardButton("🔙 Plan Info", callback_data=f"plan_select:{plan_key}"),
        types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home")
    )
    return m


def pay_approve_kb(pid):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("✅ Approve", callback_data=f"adm_pay_approve:{pid}"),
        types.InlineKeyboardButton("❌ Reject",  callback_data=f"adm_pay_reject:{pid}")
    )
    return m


def wd_approve_kb(wid):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("✅ Done", callback_data=f"adm_wd_approve:{wid}"),
        types.InlineKeyboardButton("❌ Reject", callback_data=f"adm_wd_reject:{wid}")
    )
    return m


def wd_method_kb(lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    for k, v in PAYMENT_METHODS.items():
        if k not in ('bank',):
            m.add(types.InlineKeyboardButton(f"{v['icon']} {v['name']}", callback_data=f"wd_method:{k}"))
    m.add(types.InlineKeyboardButton(t('btn_back', lang), callback_data="menu_wallet"))
    return m


def admin_kb(lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("👥 Users",          callback_data="adm_users"),
        types.InlineKeyboardButton("📊 Stats",          callback_data="adm_stats")
    )
    m.add(
        types.InlineKeyboardButton("💳 Payments",       callback_data="adm_payments"),
        types.InlineKeyboardButton("💸 Withdrawals",    callback_data="adm_withdrawals")
    )
    m.add(
        types.InlineKeyboardButton("➕ Add Sub",         callback_data="adm_addsub"),
        types.InlineKeyboardButton("➖ Remove Sub",      callback_data="adm_remsub")
    )
    m.add(
        types.InlineKeyboardButton("🚫 Ban User",       callback_data="adm_ban"),
        types.InlineKeyboardButton("✅ Unban User",     callback_data="adm_unban")
    )
    m.add(
        types.InlineKeyboardButton("📢 Broadcast",      callback_data="adm_broadcast"),
        types.InlineKeyboardButton("💰 Give Balance",   callback_data="adm_give_bal")
    )
    m.add(
        types.InlineKeyboardButton("📡 Backup Channel", callback_data="adm_backup_ch"),
        types.InlineKeyboardButton("📢 Force Channels", callback_data="adm_channels")
    )
    m.add(
        types.InlineKeyboardButton("⚙️ Referral Settings", callback_data="adm_ref_settings")
    )
    m.add(
        types.InlineKeyboardButton("🗑️ Clear Bot Menu",  callback_data="adm_clear_menu"),
        types.InlineKeyboardButton("🔄 Reset Bot Menu",  callback_data="adm_reset_menu")
    )
    m.add(
        types.InlineKeyboardButton("🔒 Quarantine Files", callback_data="adm_quarantine")
    )
    m.add(
        types.InlineKeyboardButton("🎟️ Promo Codes",    callback_data="adm_promo"),
        types.InlineKeyboardButton("🔍 User Info",      callback_data="adm_userinfo")
    )
    m.add(
        types.InlineKeyboardButton("🛡 Security Dashboard", callback_data="adm_security")
    )
    m.add(
        types.InlineKeyboardButton("🖥️ System Info",    callback_data="adm_system"),
        types.InlineKeyboardButton("🤖 Running Bots",   callback_data="adm_running")
    )
    m.add(
        types.InlineKeyboardButton("🛑 Stop All Bots",  callback_data="adm_stopall"),
        types.InlineKeyboardButton("📜 Error Logs",     callback_data="adm_errorlogs")
    )
    m.add(
        types.InlineKeyboardButton("📥 Download Logs",  callback_data="adm_dl_logs"),
        types.InlineKeyboardButton("🗑️ Cleanup",        callback_data="adm_cleanup")
    )
    fsub_icon = "🟢" if state.force_sub_enabled else "🔴"
    lock_icon = "🔒" if state.bot_locked else "🔓"
    m.add(
        types.InlineKeyboardButton(f"{fsub_icon} Force Subscribe", callback_data="adm_fsub_toggle"),
        types.InlineKeyboardButton(f"{lock_icon} Bot Lock",        callback_data="adm_lock_toggle")
    )
    m.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
    return m


def settings_kb(uid, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=1)
    m.add(types.InlineKeyboardButton("🌐 Change Language", callback_data="settings_lang"))
    m.add(types.InlineKeyboardButton("🔔 Notifications",   callback_data="settings_notif"))
    m.add(types.InlineKeyboardButton(t('btn_home', lang),  callback_data="go_home"))
    return m


def help_kb(lang='en'):
    m = types.InlineKeyboardMarkup(row_width=2)
    m.add(
        types.InlineKeyboardButton("📤 Deploy Guide",    callback_data="help_deploy"),
        types.InlineKeyboardButton("🤖 Bot Management",  callback_data="help_bots")
    )
    m.add(
        types.InlineKeyboardButton("💎 Plans Guide",     callback_data="help_plans"),
        types.InlineKeyboardButton("💳 Payment Guide",   callback_data="help_payment")
    )
    m.add(
        types.InlineKeyboardButton("🎁 Referral Guide",  callback_data="help_ref"),
        types.InlineKeyboardButton("💰 Wallet Guide",    callback_data="help_wallet")
    )
    m.add(
        types.InlineKeyboardButton("📺 Ad System",       callback_data="help_ad"),
        types.InlineKeyboardButton("❓ FAQ",              callback_data="help_faq")
    )
    m.add(types.InlineKeyboardButton("📞 Contact Developer", url="https://t.me/arafat_codex1"))
    m.add(types.InlineKeyboardButton(t('btn_home', lang), callback_data="go_home"))
    return m


def channel_fsub_kb(channels, lang='en'):
    m = types.InlineKeyboardMarkup(row_width=1)
    for ch in channels:
        un = ch.get('username', '')
        nm = ch.get('name', un)
        m.add(types.InlineKeyboardButton(f"📢 {nm} — @{un}", url=f"https://t.me/{un}"))
    m.add(types.InlineKeyboardButton("✅ Verify", callback_data="fsub_verify"))
    return m
