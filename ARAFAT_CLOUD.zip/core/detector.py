"""
☁️ APON HOSTING CLOUD — Smart Detector v2.0
Auto-detects entry file, installs packages (even without requirements.txt)
"""

import os, re, sys, json, subprocess, logging
from config import MODULES_MAP

logger = logging.getLogger('AHC.detector')

PY_ENTRIES = ['main.py','app.py','bot.py','run.py','start.py','server.py','index.py','__main__.py']
JS_ENTRIES = ['index.js','app.js','bot.js','main.js','server.js','start.js','run.js']

PY_INDICATORS = ['infinity_polling','bot.polling','app.run(','if __name__',
                 'telebot.TeleBot','Bot(token','dispatcher.start_polling',
                 'client.run','application.run']
JS_INDICATORS = ['require(','app.listen','bot.launch','client.login','express()','bot.start(']


def detect_entry(d):
    """Auto-detect entry file and language."""
    if not os.path.isdir(d):
        if os.path.isfile(d):
            ext = d.rsplit('.',1)[-1].lower()
            return os.path.basename(d), ext if ext in ('py','js') else 'py', 'exact'
        return None, None, None

    top = os.listdir(d)

    # 1. Known entry names
    for e in PY_ENTRIES:
        if e in top and os.path.isfile(os.path.join(d, e)):
            return e, 'py', 'high'
    for e in JS_ENTRIES:
        if e in top and os.path.isfile(os.path.join(d, e)):
            return e, 'js', 'high'

    # 2. package.json
    pj = os.path.join(d, 'package.json')
    if os.path.exists(pj):
        try:
            with open(pj) as f:
                pkg = json.load(f)
            if 'main' in pkg and os.path.exists(os.path.join(d, pkg['main'])):
                return pkg['main'], 'js', 'high'
            ss = pkg.get('scripts', {}).get('start', '')
            for pat, ft in [(r'node\s+(\S+\.js)','js'),(r'python[3]?\s+(\S+\.py)','py')]:
                m = re.search(pat, ss)
                if m and os.path.exists(os.path.join(d, m.group(1))):
                    return m.group(1), ft, 'high'
        except: pass

    # 3. Procfile
    pf = os.path.join(d, 'Procfile')
    if os.path.exists(pf):
        try:
            with open(pf) as f: c = f.read()
            for pat, ft in [(r'(?:worker|web):\s*python[3]?\s+(\S+\.py)','py'),
                            (r'(?:worker|web):\s*node\s+(\S+\.js)','js')]:
                m = re.search(pat, c)
                if m and os.path.exists(os.path.join(d, m.group(1))):
                    return m.group(1), ft, 'high'
        except: pass

    # 4. Subdirectory search
    for root, dirs, files in os.walk(d):
        depth = os.path.relpath(root, d).count(os.sep)
        if depth > 2 or root == d: continue
        for e in PY_ENTRIES:
            if e in files:
                return os.path.relpath(os.path.join(root, e), d), 'py', 'medium'
        for e in JS_ENTRIES:
            if e in files:
                return os.path.relpath(os.path.join(root, e), d), 'js', 'medium'

    # 5. Content-based
    pyf, jsf = [], []
    for root, _, files in os.walk(d):
        if os.path.relpath(root, d).count(os.sep) > 2: continue
        for f in files:
            fp = os.path.join(root, f)
            rp = os.path.relpath(fp, d)
            if f.endswith('.py'): pyf.append((rp, fp))
            elif f.endswith('.js'): jsf.append((rp, fp))

    for rp, fp in pyf:
        try:
            with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                c = f.read(5000)
            if sum(1 for x in PY_INDICATORS if x in c) >= 2:
                return rp, 'py', 'medium'
        except: pass

    for rp, fp in jsf:
        try:
            with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                c = f.read(5000)
            if sum(1 for x in JS_INDICATORS if x in c) >= 2:
                return rp, 'js', 'medium'
        except: pass

    if pyf: return pyf[0][0], 'py', 'low'
    if jsf: return jsf[0][0], 'js', 'low'
    return None, None, None


def scan_imports(file_path):
    """Scan Python file for imports and return missing packages."""
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
    except: return []

    found = set()
    # import X / from X import Y
    for m in re.finditer(r'^(?:import|from)\s+(\w+)', content, re.MULTILINE):
        found.add(m.group(1))

    missing = []
    for mod in found:
        if mod in MODULES_MAP:
            pkg = MODULES_MAP[mod]
            try:
                __import__(mod)
            except ImportError:
                missing.append(pkg)
    return list(set(missing))


def install_requirements(d, notify_fn=None):
    """Install from requirements.txt if exists."""
    r = os.path.join(d, 'requirements.txt')
    if not os.path.exists(r): return True
    if notify_fn: notify_fn("📦 Installing requirements.txt...")
    try:
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '-r', r, '--quiet'],
            capture_output=True, text=True, timeout=300, cwd=d
        )
        if result.returncode != 0 and notify_fn:
            import html
            notify_fn(f"⚠️ Install warning:\n<code>{html.escape((result.stderr or '')[-300:])}</code>")
    except subprocess.TimeoutExpired:
        if notify_fn: notify_fn("⚠️ Install timeout. Continuing...")
    except Exception as e:
        logger.error(f"install_requirements: {e}")
    return True


def auto_install_imports(file_path, notify_fn=None):
    """Scan imports and auto-install missing packages (no requirements.txt needed)."""
    missing = scan_imports(file_path)
    if not missing: return True
    if notify_fn: notify_fn(f"📦 Auto-installing: {', '.join(missing)}...")
    for pkg in missing:
        try:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'install', pkg, '--quiet'],
                capture_output=True, text=True, timeout=120
            )
        except Exception as e:
            logger.error(f"auto_install {pkg}: {e}")
    return True


def install_npm(d, notify_fn=None):
    """Install Node.js packages."""
    if (os.path.exists(os.path.join(d, 'package.json')) and
            not os.path.exists(os.path.join(d, 'node_modules'))):
        if notify_fn: notify_fn("📦 Running npm install...")
        try:
            subprocess.run(['npm', 'install', '--production'],
                           capture_output=True, text=True, timeout=300, cwd=d)
        except Exception as e:
            logger.error(f"npm install: {e}")
    return True


def auto_pip_install(mod, notify_fn=None):
    """Install a single missing module."""
    pkg = MODULES_MAP.get(mod, mod)
    if not pkg: return False
    if notify_fn: notify_fn(f"📦 Installing: <code>{pkg}</code>...")
    try:
        r = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', pkg, '--quiet'],
            capture_output=True, text=True, timeout=120
        )
        return r.returncode == 0
    except: return False
