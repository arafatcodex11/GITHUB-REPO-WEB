"""
☁️ ARAFAT HOSTING CLOUD — State v2.1 (Fixed + Thread-safe)
"""

import threading, time
from datetime import datetime
from collections import defaultdict, deque
from config import OWNER_ID


class BotState:
    def __init__(self):
        self._lock             = threading.RLock()
        self.force_sub_enabled = True
        self.bot_locked        = False
        self.bot_start_time    = datetime.now()
        self.admin_ids         = {OWNER_ID}
        self._states           = {}
        self._pay_states       = {}
        # FIX: Separate lock for rate limiting to reduce contention
        self._rate_lock        = threading.Lock()
        self.user_msg_times    = defaultdict(deque)
        self.bot_scripts       = {}

    def is_admin(self, uid):
        return uid == OWNER_ID or uid in self.admin_ids

    def set(self, uid, data):
        with self._lock:
            self._states[uid] = data

    def get(self, uid):
        # FIX: Use lock — concurrent set/delete during read can cause KeyError
        with self._lock:
            return self._states.get(uid)

    def clear(self, uid):
        with self._lock:
            self._states.pop(uid, None)
            self._pay_states.pop(uid, None)

    def set_pay(self, uid, data):
        with self._lock:
            self._pay_states[uid] = data

    def get_pay(self, uid):
        with self._lock:  # FIX: consistent locking like get()
            return self._pay_states.get(uid)

    def rate_ok(self, uid):
        # Admins bypass rate limiting
        if uid == OWNER_ID or uid in self.admin_ids:
            return True
        now   = time.monotonic()
        with self._rate_lock:
            times = self.user_msg_times[uid]
            # Drop messages older than 60s window
            while times and now - times[0] > 60:
                times.popleft()
            # FIX: 30 msgs/min (was 20) — allows smoother new user onboarding flow
            if len(times) >= 30:
                return False
            times.append(now)
        return True

    def cleanup_rate_data(self):
        """Call periodically to free memory from inactive users."""
        now = time.monotonic()
        with self._rate_lock:
            to_del = [uid for uid, times in self.user_msg_times.items()
                      if not times or now - times[-1] > 3600]
            for uid in to_del:
                del self.user_msg_times[uid]


state       = BotState()
bot_scripts = state.bot_scripts
