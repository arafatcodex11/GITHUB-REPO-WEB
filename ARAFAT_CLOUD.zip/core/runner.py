"""
☁️ ARAFAT HOSTING CLOUD — Runner v2.1 (Fixed + Optimized)
"""

import os, sys, re, time, threading, logging, subprocess
from datetime import datetime, timedelta
from telebot import types
from config import (LOGS_DIR, PLAN_LIMITS, FREE_BOT_MAX_HOURS,
                    DAILY_REPORT_HOUR, DAILY_REPORT_MINUTE, HEALTH_CHECK_INTERVAL)
from security.file_lock import verify_lock, LockViolation
from core.state import state, bot_scripts
from core.detector import (detect_entry, install_requirements,
                            auto_install_imports, install_npm, auto_pip_install)
from utils.helpers import (user_folder, cleanup_script, kill_tree,
                           is_running, bot_res, sys_stats, recommend_plan)

logger = logging.getLogger('AHC.runner')

_bot       = None
_db        = None
_safe_send = None


def init_runner(bot_inst, db_inst, safe_fn):
    global _bot, _db, _safe_send
    _bot       = bot_inst
    _db        = db_inst
    _safe_send = safe_fn


def run_bot(bid, uid, attempt=1):
    if not _db or not _safe_send:
        return
    bd = _db.get_bot(bid)
    if not bd:
        return

    lang = _db.get_lang(uid)
    # FIX: পুরনো MongoDB documents এ field name আলাদা হতে পারে
    name = bd.get('name') or bd.get('bot_name') or f'bot_{bid}'
    fp   = bd.get('file_path', '')
    ef   = bd.get('entry') or bd.get('entry_file') or 'main.py'
    ft   = bd.get('ftype') or bd.get('file_type') or 'py'
    sk   = f"{uid}_{name}"
    wd   = fp if os.path.isdir(fp) else user_folder(uid)

    # ── Anti-Steal: File Lock Verify ──────────────────────
    try:
        verify_lock(uid, wd)
    except LockViolation as lv:
        logger.error(f"Lock violation uid={uid} bot={name}: {lv}")
        _safe_send(uid, f"🔒 <b>Security Block!</b>\n\nBot {name} এই VPS এ run করার অনুমতি নেই.\n<i>{lv}</i>")
        return
    # ─────────────────────────────────────────────────────

    try:
        de, dt, _ = detect_entry(wd)
        if de:
            ef = de; ft = dt or 'py'
            _db.update_bot(bid, entry=ef, ftype=ft)

        fsp = os.path.join(wd, ef)

        if not os.path.exists(fsp):
            found = False
            for root, _, files in os.walk(wd):
                if os.path.basename(ef) in files:
                    fsp   = os.path.join(root, os.path.basename(ef))
                    ef    = os.path.relpath(fsp, wd)
                    _db.update_bot(bid, entry=ef)
                    found = True
                    break
            if not found:
                import html
                af  = [os.path.relpath(os.path.join(r,f), wd)
                       for r,_,fs in os.walk(wd) for f in fs
                       if f.endswith(('.py','.js'))]
                msg = (f"❌ <b>Entry not found:</b> <code>{html.escape(ef)}</code>\n\n"
                       + '\n'.join(f"  • <code>{html.escape(x)}</code>" for x in af[:8]))
                mk  = types.InlineKeyboardMarkup()
                mk.add(types.InlineKeyboardButton("🔍 Re-detect", callback_data=f"bot_redetect:{bid}"))
                mk.add(types.InlineKeyboardButton("🏠 Menu", callback_data="go_home"))
                _safe_send(uid, msg, reply_markup=mk)
                return

        if attempt == 1:
            if ft == 'py':
                install_requirements(wd, lambda m: _safe_send(uid, m))
                auto_install_imports(fsp, lambda m: _safe_send(uid, m))
            else:
                install_npm(wd, lambda m: _safe_send(uid, m))

        ti = '🐍 Python' if ft == 'py' else '🟨 Node.js'
        _safe_send(uid, f"🚀 Starting <b>{name}</b>... (Attempt {attempt}/3)")

        lp = os.path.join(LOGS_DIR, f"{sk}.log")
        # FIX: Open log file, pass to Popen, then close our handle.
        # Popen inherits the fd; the process keeps it open for writing.
        # We no longer hold an open fd — prevents fd leak when many bots run.
        lf = open(lp, 'a', encoding='utf-8', errors='ignore')

        cmd = ['node', fsp] if ft == 'js' else [sys.executable, '-u', fsp]
        env = os.environ.copy()
        env['PYTHONUNBUFFERED'] = '1'
        # SECURITY: user bot কে host এর sensitive credentials দেওয়া যাবে না
        for _k in ('BOT_TOKEN', 'MONGO_URL', 'MONGO_URL_BACKUP',
                   'AD_SECRET', 'OWNER_ID', 'BACKUP_CHANNEL_ID',
                   'BKASH_NUM', 'NAGAD_NUM', 'BINANCE_ID'):
            env.pop(_k, None)

        # SECURITY: Encrypted token decrypt করে inject করো
        try:
            from security.token_encryptor import inject_decrypted_env
            env = inject_decrypted_env(wd, uid, env)
        except Exception as _te:
            logger.warning(f"Token inject error: {_te}")

        proc = subprocess.Popen(
            cmd, cwd=wd, stdout=lf, stderr=subprocess.STDOUT,
            text=True, encoding='utf-8', errors='ignore', env=env,
            preexec_fn=os.setsid if os.name != 'nt' else None
        )
        lf.close()  # FIX: close our copy — proc keeps its own fd

        bot_scripts[sk] = {
            'process': proc, 'name': name, 'bot_id': bid,
            'uid': uid, 'start_time': datetime.now(),
            'log_path': lp, 'entry': ef,
            'work_dir': wd, 'ftype': ft, 'attempt': attempt,
        }

        time.sleep(4)

        if proc.poll() is None:
            _db.update_bot(bid, status='running',
                           last_start=datetime.now().isoformat(),
                           entry=ef, ftype=ft,
                           restarts=bd.get('restarts', 0) + (1 if attempt > 1 else 0))
            mk = types.InlineKeyboardMarkup(row_width=2)
            mk.add(
                types.InlineKeyboardButton("🛑 Stop",    callback_data=f"bot_stop:{bid}"),
                types.InlineKeyboardButton("🔄 Restart", callback_data=f"bot_restart:{bid}")
            )
            mk.add(
                types.InlineKeyboardButton("📋 Logs",    callback_data=f"bot_logs:{bid}"),
                types.InlineKeyboardButton("📊 Res",     callback_data=f"bot_res:{bid}")
            )
            mk.add(types.InlineKeyboardButton("🏠 Menu", callback_data="go_home"))
            _safe_send(uid,
                       f"✅ <b>Bot Started!</b>\n━━━━━━━━━━━━━━━━\n\n"
                       f"🤖 <b>{name}</b>\n📄 <code>{ef}</code>\n{ti}\n"
                       f"🆔 PID: <code>{proc.pid}</code>\n🟢 Running",
                       reply_markup=mk)
            return

        # ── Crashed ──────────────────────────────────────────────
        # lf already closed after Popen — nothing to flush
        err = ''
        try:
            with open(lp, 'r', encoding='utf-8', errors='ignore') as f:
                err = f.read()[-2000:]
        except: pass

        # Sanitize: remove long base64/token strings from logs
        import re as _re
        err_safe = _re.sub(r'[A-Za-z0-9+/]{40,}={0,2}', '[TOKEN]', err)
        _db.log_error('bot_runner', f"Bot {name} crashed: {err_safe[:200]}", uid)

        # Auto-fix: missing Python module
        m = re.search(r"ModuleNotFoundError: No module named '([^']+)'", err)
        if m and attempt < 3:
            cleanup_script(sk)
            if auto_pip_install(m.group(1).split('.')[0], lambda msg: _safe_send(uid, msg)):
                time.sleep(1)
                # FIX: Thread — no stack growth on retry
                threading.Thread(target=run_bot, args=(bid, uid, attempt + 1), daemon=True).start()
                return

        # Auto-fix: missing Node module
        m = re.search(r"Cannot find module '([^']+)'", err)
        if m and not m.group(1).startswith('.') and attempt < 3:
            cleanup_script(sk)
            try:
                subprocess.run(['npm','install',m.group(1)],
                               cwd=wd, capture_output=True, timeout=60)
                time.sleep(1)
                # FIX: Thread — no stack growth on retry
                threading.Thread(target=run_bot, args=(bid, uid, attempt + 1), daemon=True).start()
                return
            except Exception as npm_e:
                logger.debug(f'npm install fallback: {npm_e}')

        # Auto-fix: try alternate entry
        if attempt == 1:
            for alt in ['app.py','main.py','bot.py','run.py','index.js','app.js']:
                if os.path.exists(os.path.join(wd, alt)) and alt != ef:
                    cleanup_script(sk)
                    ft2 = 'js' if alt.endswith('.js') else 'py'
                    _db.update_bot(bid, entry=alt, ftype=ft2)
                    threading.Thread(target=run_bot, args=(bid, uid, attempt + 1), daemon=True).start()
                    return

        import html as html_lib
        ed  = html_lib.escape(err[-400:]) if err.strip() else 'No output'
        mk2 = types.InlineKeyboardMarkup(row_width=2)
        mk2.add(
            types.InlineKeyboardButton("🔄 Retry",    callback_data=f"bot_start:{bid}"),
            types.InlineKeyboardButton("📋 Logs",     callback_data=f"bot_logs:{bid}")
        )
        mk2.add(
            types.InlineKeyboardButton("🔍 Re-detect", callback_data=f"bot_redetect:{bid}"),
            types.InlineKeyboardButton("🔙 My Bots",   callback_data="menu_mybots")
        )
        _safe_send(uid,
                   f"❌ <b>Bot Crashed!</b>\n━━━━━━━━━━━━━━━━\n\n"
                   f"🤖 {name}\n📄 <code>{ef}</code>\n"
                   f"Exit: {proc.returncode} | Attempt {attempt}/3\n\n"
                   f"<code>{ed}</code>",
                   reply_markup=mk2)
        _db.update_bot(bid, status='crashed', last_stop=datetime.now().isoformat())
        cleanup_script(sk)

        if any(x in err for x in ('MemoryError', 'OSError', 'No space left')):
            for aid in state.admin_ids:
                _safe_send(aid,
                           f"⚠️ Server Error!\n👤 <code>{uid}</code>\n"
                           f"🤖 {name}\n{err[:300]}")

    except Exception as e:
        logger.error(f"run_bot: {e}", exc_info=True)
        _db.log_error('run_bot', str(e), uid)
        if _safe_send:
            _safe_send(uid, f"❌ Fatal error: {str(e)[:200]}")
        cleanup_script(sk)


# ══════════════════════════════════
#  BACKGROUND THREADS
# ══════════════════════════════════

def thread_monitor():
    """Monitor bots; auto-restart paid plans."""
    while True:
        try:
            for sk in list(bot_scripts.keys()):
                i    = bot_scripts.get(sk)
                if not i: continue
                proc = i.get('process')
                if not proc or proc.poll() is None: continue
                bid  = i.get('bot_id')
                uid  = i.get('uid')
                if bid and _db:
                    _db.update_bot(bid, status='crashed',
                                   last_stop=datetime.now().isoformat())
                if uid and bid and _db:
                    u_data   = _db.get_user(uid)
                    plan_key = u_data.get('plan','free') if u_data else 'free'
                    pl       = PLAN_LIMITS.get(plan_key, {})
                    att      = i.get('attempt', 1)
                    if pl.get('auto_restart') and att < 3:
                        cleanup_script(sk)
                        time.sleep(3)
                        threading.Thread(target=run_bot, args=(bid, uid, att+1),
                                         daemon=True).start()
                        continue
                cleanup_script(sk)
        except Exception as e:
            logger.error(f"monitor: {e}")
        time.sleep(15)


def thread_health_check():
    """RAM/CPU health check every N seconds."""
    while True:
        try:
            time.sleep(HEALTH_CHECK_INTERVAL)
            if not _db or not _safe_send: continue
            for sk, i in list(bot_scripts.items()):
                if not is_running(sk): continue
                uid       = i.get('uid')
                bid       = i.get('bot_id')
                name      = i.get('name', sk)
                if not uid or not bid: continue
                mem, cpu  = bot_res(sk)
                ram_limit = _db.get_bot_ram_limit(uid, name)
                if mem >= ram_limit:
                    # 100% RAM — force stop (hard kill)
                    from lang import t
                    from security.alerter import alert_ram_critical
                    lang  = _db.get_lang(uid)
                    u2    = _db.get_user(uid)
                    uname = (u2 or {}).get('username', '')
                    # Process kill — multiple attempts
                    try:
                        kill_tree(bot_scripts[sk])
                    except Exception:
                        pass
                    # Extra safety: kill by pid if still running
                    try:
                        proc = bot_scripts.get(sk)
                        if proc and hasattr(proc, 'pid') and proc.pid:
                            import signal
                            os.kill(proc.pid, signal.SIGKILL)
                    except Exception:
                        pass
                    cleanup_script(sk)
                    if bid:
                        _db.update_bot(bid, status='stopped')
                    mk = types.InlineKeyboardMarkup(row_width=2)
                    mk.add(
                        types.InlineKeyboardButton("💎 Upgrade", callback_data="menu_sub"),
                        types.InlineKeyboardButton("📺 Watch Ad", callback_data="menu_watchad")
                    )
                    _safe_send(uid,
                               f"🚨 <b>{name} বন্ধ হয়ে গেছে!</b>\n\n"
                               f"কারণ: RAM limit পূর্ণ হয়ে গেছে ({round(mem)}MB/{ram_limit}MB)\n"
                               f"Upgrade করুন অথবা Ad দেখে extra time নিন।",
                               reply_markup=mk)
                    alert_ram_critical(uid, uname, mem/ram_limit*100, name)
                    _db.log_error('health_check',
                                  f"RAM FULL STOP: {name} {mem}MB/{ram_limit}MB", uid, 'CRITICAL')
                elif mem > ram_limit * 0.9:
                    # 90% warning
                    _, rec_name = recommend_plan(mem)
                    from lang import t
                    _safe_send(uid, t('ram_warning', _db.get_lang(uid),
                                      bot_name=name, used=round(mem),
                                      limit=ram_limit, recommended=rec_name))
                    _db.log_error('health_check',
                                  f"RAM: {name} {mem}MB/{ram_limit}MB", uid, 'WARNING')
        except Exception as e:
            logger.error(f"health_check: {e}")


_expiry_notified = set()   # (uid, 'free_expired'|'sub_expired'|'3day_warn') — reset on restart

def thread_expiry():
    """Check subscription expiry every hour. FIX: runs immediately on start too."""
    while True:
        try:
            if not _db or not _safe_send:
                time.sleep(60)
                continue
            now = datetime.now().isoformat()
            for u in _db.get_all_users():
                uid = u.get('uid') or u.get('user_id')
                if not uid:
                    continue
                lang = _db.get_lang(uid)
                from lang import t

                # Free plan expired
                if _db.is_free_expired(uid):
                    nkey = (uid, 'free_expired')
                    for b in _db.get_bots(uid):
                        sk  = f"{uid}_{b['name']}"
                        # FIX: use correct key 'bid' — fallback to '_id'
                        bid = b.get('bid') or b.get('_id') or b.get('id')
                        if sk in bot_scripts:
                            kill_tree(bot_scripts[sk])
                            cleanup_script(sk)
                        if bid:
                            _db.update_bot(bid, status='stopped')
                    # Only notify once per expiry event — not every hour
                    if nkey not in _expiry_notified:
                        _expiry_notified.add(nkey)
                        mk = types.InlineKeyboardMarkup(row_width=2)
                        mk.add(
                            types.InlineKeyboardButton("💎 Upgrade", callback_data="menu_sub"),
                            types.InlineKeyboardButton("📺 Watch Ad", callback_data="menu_watchad")
                        )
                        _safe_send(uid, t('free_limit', lang, name='Your bots'), reply_markup=mk)
                    continue

                plan = u.get('plan','free')
                # Skip if truly free (no paid stack) or lifetime
                if u.get('is_lifetime') or not _db.has_paid_plan(uid):
                    continue

                se = u.get('sub_end')
                if se and se <= now:
                    nkey = (uid, 'sub_expired')
                    _db.rem_plan(uid)
                    # Clear any prior 3-day warning so it re-fires after renewal
                    _expiry_notified.discard((uid, '3day_warn'))
                    for b in _db.get_bots(uid):
                        sk  = f"{uid}_{b['name']}"
                        bid = b.get('bid') or b.get('_id') or b.get('id')
                        if sk in bot_scripts:
                            kill_tree(bot_scripts[sk])
                            cleanup_script(sk)
                        if bid:
                            _db.update_bot(bid, status='stopped')
                    # Only notify once per expiry event — not every hour
                    if nkey not in _expiry_notified:
                        _expiry_notified.add(nkey)
                        mk = types.InlineKeyboardMarkup(row_width=2)
                        mk.add(
                            types.InlineKeyboardButton("💎 Renew",   callback_data="menu_sub"),
                            types.InlineKeyboardButton("📺 Watch Ad", callback_data="menu_watchad")
                        )
                        _safe_send(uid, t('sub_expired', lang), reply_markup=mk)
                        # Admin কে alert দাও
                        try:
                            from security.alerter import alert_sub_expired
                            uname = u.get('username', '')
                            alert_sub_expired(uid, uname)
                        except Exception: pass

                elif se:
                    try:
                        days_left = (datetime.fromisoformat(se) - datetime.now()).days
                        nkey3 = (uid, '3day_warn')
                        if days_left == 3 and nkey3 not in _expiry_notified:
                            _expiry_notified.add(nkey3)
                            mk = types.InlineKeyboardMarkup()
                            mk.add(types.InlineKeyboardButton("💎 Renew", callback_data="menu_sub"))
                            _safe_send(uid, t('sub_expiry_reminder', lang, days=3), reply_markup=mk)
                    except: pass

        except Exception as e:
            logger.error(f"expiry: {e}")
        time.sleep(3600)  # FIX: sleep at END so first run happens immediately


def thread_daily_report():
    """Send daily report to all admins."""
    while True:
        try:
            now = datetime.now()
            nxt = now.replace(hour=DAILY_REPORT_HOUR, minute=DAILY_REPORT_MINUTE,
                              second=0, microsecond=0)
            if nxt <= now:
                nxt += timedelta(days=1)
            time.sleep((nxt - datetime.now()).total_seconds())
            if not _db or not _safe_send: continue
            s  = _db.stats()
            ss = sys_stats()
            rn = sum(1 for sk in bot_scripts if is_running(sk))
            rpt = (
                f"📊 <b>DAILY REPORT</b>\n━━━━━━━━━━━━━━━━\n\n"
                f"📅 {datetime.now().strftime('%Y-%m-%d')}\n\n"
                f"👥 {s['users']} users (+{s['today_users']} today)\n"
                f"🤖 {s['bots']} bots | 🟢 {rn}\n"
                f"💳 Pending pay: {s['pending_pay']}\n"
                f"💸 Pending WD: {s['pending_wd']}\n"
                f"💰 Revenue: {s['revenue']} BDT\n"
                f"🚫 Banned: {s['banned']}\n\n"
                f"🖥️ CPU: {ss['cpu']}% | RAM: {ss['mem']}%\n"
                f"💾 {ss['disk_used']}/{ss['disk_total']}\n"
                f"⏱️ {ss['up']}\n━━━━━━━━━━━━━━━━"
            )
            for aid in state.admin_ids:
                _safe_send(aid, rpt)
        except Exception as e:
            logger.error(f"daily_report: {e}")
        time.sleep(60)
