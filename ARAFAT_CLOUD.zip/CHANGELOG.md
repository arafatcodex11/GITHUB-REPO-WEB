# ☁️ ARAFAT HOSTING CLOUD — CHANGELOG & UPDATE GUIDE

---

## 🔐 Security System — কিভাবে আপডেট করবেন

### নতুন Attack Pattern যোগ করতে হলে:

1. `security/scanner.py` খুলুন
2. `CRITICAL_PATTERNS` এ যোগ করুন (block করতে হলে):
   ```python
   (r'আপনার_pattern', 'কারণ বাংলায়/ইংলিশে'),
   ```
3. শুধু alert করতে হলে `WARNING_PATTERNS` এ যোগ করুন

### VPS Guard — নতুন process block করতে:

1. `security/vps_guard.py` খুলুন
2. `SUSPICIOUS_CMDLINE` এ যোগ করুন:
   ```python
   (r'command_pattern', 'কারণ'),
   ```

---

## 📋 CHANGELOG

### v3.1 (2026-05-12) — Ultra Security Release
- ✅ **ZIP Bomb Protection** — oversized ZIP block
- ✅ **VPS Guard** (`security/vps_guard.py`) — runtime process monitor, auto-kill
- ✅ **File Lock** (`security/file_lock.py`) — owner bind, VPS fingerprint, anti-steal
- ✅ **40+ new scan patterns** — reverse shell, crypto miner, bot hijack, credential theft
- ✅ **File fingerprint** — SHA256 hash of every uploaded bot
- ✅ **Shell script scan** — .sh/.bash file এ dangerous command detect

### v3.0 (2026-04-20)
- ✅ Quarantine system — admin approve/reject
- ✅ Bot hijack detection (set_my_name, webhook redirect)
- ✅ Hidden channel attack detection

### v2.5 (2026-03-01)
- ✅ ZIP path traversal fix
- ✅ Symlink block in ZIP

### v2.0 (2026-01-15)
- ✅ Basic malware scanner
- ✅ Admin security alerts

---

## 🚀 নতুন VPS এ Deploy করার ধাপ

```bash
# 1. Code নামান
git clone <your-repo> && cd ahc_v3.1

# 2. Dependencies install করুন
pip install -r requirements.txt

# 3. Config করুন
cp .env.example .env
nano .env   # BOT_TOKEN, OWNER_ID, MONGO_URL দিন

# 4. চালু করুন
bash start.sh
```

---

## 🔧 Security Config পরিবর্তন করতে

| কি পরিবর্তন করবেন | কোন ফাইল | কোন variable |
|---|---|---|
| Scan patterns | `security/scanner.py` | `CRITICAL_PATTERNS` |
| Process monitor | `security/vps_guard.py` | `SUSPICIOUS_CMDLINE` |
| File lock salt | `security/file_lock.py` | `FINGERPRINT_KEY` |
| CPU threshold | `security/vps_guard.py` | `CPU_ABUSE_THRESHOLD` |
| Alert cooldown | `security/alerter.py` | `ALERT_COOLDOWN_SEC` |
| Max ZIP size | `security/scanner.py` | `MAX_EXTRACTED_SIZE` |
