"""
☁️ ARAFAT HOSTING CLOUD — Database v2.0
MongoDB Primary | SQLite Fallback | Plan Stacking Support
"""

import os, sqlite3, threading, logging, secrets, json
from datetime import datetime, timedelta
from config import OWNER_ID, PLAN_LIMITS, MONGO_URL, MONGO_URL_BACKUP, DB_NAME, LOGS_DIR, BASE_DIR
from utils.helpers import gen_ref_code  # top-level to avoid repeated lazy import

logger = logging.getLogger('AHC.DB')

USE_MONGO = False
mongo_db  = None
_sqlite_initialized = False

def _try_mongo(url, label='PRIMARY'):
    global mongo_db, USE_MONGO
    if not url:
        return False
    try:
        from pymongo import MongoClient
        c = MongoClient(url, serverSelectionTimeoutMS=5000, maxPoolSize=100)
        c.admin.command('ping')
        mongo_db  = c[DB_NAME]
        USE_MONGO = True
        # ── Stale index cleanup ──────────────────────────────────────────────
        # Drop any legacy `user_id_1` index on the users collection.
        # That index was created by an older schema where the field was called
        # `user_id`; the current schema uses `uid`.  Because no document has
        # a `user_id` field, every document matches {user_id: null} — so the
        # sparse-less unique index raises DuplicateKeyError on the second insert.
        try:
            existing = mongo_db.users.index_information()
            if "user_id_1" in existing:
                mongo_db.users.drop_index("user_id_1")
                logger.info("🗑️  Dropped stale index users.user_id_1")
            # FIX: uid: null document মুছে দাও — এগুলো DuplicateKeyError এর কারণ
            null_count = mongo_db.users.count_documents({'uid': None})
            if null_count:
                mongo_db.users.delete_many({'uid': None})
                logger.info(f"🗑️  Deleted {null_count} null-uid user documents")
            # FIX: uid_1 index sparse করো — conflict এড়াতে আগে drop করো
            try:
                if "uid_1" in existing:
                    idx = existing["uid_1"]
                    # ইতিমধ্যে sparse থাকলে rebuild দরকার নেই
                    if not idx.get('sparse'):
                        mongo_db.users.drop_index("uid_1")
                        mongo_db.users.create_index("uid", unique=True, sparse=True, background=True)
                        logger.info("✅ uid index rebuilt as sparse+unique")
                    else:
                        logger.info("✅ uid index already sparse — skipping rebuild")
                else:
                    mongo_db.users.create_index("uid", unique=True, sparse=True, background=True)
                    logger.info("✅ uid sparse+unique index created")
            except Exception as idx_e:
                logger.warning(f"uid index rebuild: {idx_e}")
        except Exception as drop_e:
            logger.warning(f"Could not drop stale index user_id_1: {drop_e}")

        # ── Ensure indexes exist for fast lookups ────────────────────────────
        try:
            mongo_db.users.create_index("ref_code", background=True)
            mongo_db.users.create_index("uid", unique=True, sparse=True, background=True)
            mongo_db.bots.create_index("uid", background=True)
            mongo_db.bots.create_index("status", background=True)
            mongo_db.payments.create_index("status", background=True)
            mongo_db.withdrawals.create_index([("uid",1),("status",1)], background=True)
        except Exception as idx_e:
            logger.warning(f"MongoDB index warn: {idx_e}")
        logger.info(f"✅ MongoDB {label} connected!")
        return True
    except Exception as e:
        logger.warning(f"⚠️ MongoDB {label} failed: {e}")
        return False

# FIX: Always try Mongo, always init SQLite (needed as fallback or cache)
if not _try_mongo(MONGO_URL, 'PRIMARY'):
    _try_mongo(MONGO_URL_BACKUP, 'BACKUP')
    if not USE_MONGO:
        logger.warning("⚠️ Using SQLite as primary database")

DB_PATH = os.path.join(BASE_DIR, 'ahc_data.db')


class DB:
    """Unified database class — MongoDB or SQLite."""

    # ══════════════════════════════════
    #  SQLITE INIT
    # ══════════════════════════════════
    _local = threading.local()

    def _conn(self):
        if not hasattr(self._local, 'conn') or not self._local.conn:
            self._local.conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=10)
            self._local.conn.row_factory = sqlite3.Row
            self._local.conn.execute("PRAGMA journal_mode=WAL")
            self._local.conn.execute("PRAGMA busy_timeout=5000")
        return self._local.conn

    def _exe(self, q, p=(), fetch=False, one=False):
        try:
            conn = self._conn()
            cur  = conn.execute(q, p)
            conn.commit()
            if one:
                row = cur.fetchone()
                return dict(row) if row else None
            if fetch:
                return [dict(r) for r in (cur.fetchall() or [])]
            return cur.lastrowid
        except Exception as e:
            logger.error(f"SQLite error: {e} | {q[:60]}")
            return None

    def init_sqlite(self):
        self._exe("""CREATE TABLE IF NOT EXISTS users(
            uid INTEGER PRIMARY KEY,
            username TEXT DEFAULT '',
            full_name TEXT DEFAULT '',
            lang TEXT DEFAULT 'en',
            plan TEXT DEFAULT 'free',
            plan_stack TEXT DEFAULT '[]',
            extra_bots INTEGER DEFAULT 0,
            wallet REAL DEFAULT 0,
            total_spent REAL DEFAULT 0,
            is_banned INTEGER DEFAULT 0,
            ban_reason TEXT DEFAULT '',
            is_lifetime INTEGER DEFAULT 0,
            sub_end TEXT,
            free_start TEXT,
            ref_code TEXT DEFAULT '',
            referred_by INTEGER,
            ref_count INTEGER DEFAULT 0,
            ref_earn REAL DEFAULT 0,
            ref_level TEXT DEFAULT 'bronze',
            ad_last_watch TEXT,
            last_active TEXT DEFAULT(datetime('now')),
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS bots(
            bid INTEGER PRIMARY KEY AUTOINCREMENT,
            uid INTEGER NOT NULL,
            name TEXT NOT NULL,
            file_path TEXT DEFAULT '',
            entry TEXT DEFAULT 'main.py',
            ftype TEXT DEFAULT 'py',
            status TEXT DEFAULT 'stopped',
            restarts INTEGER DEFAULT 0,
            backup_msg_id INTEGER DEFAULT 0,
            uptime_seconds INTEGER DEFAULT 0,
            assigned_plan TEXT DEFAULT 'free',
            created_at TEXT DEFAULT(datetime('now')),
            last_start TEXT,
            last_stop TEXT
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS quarantine(
            qid INTEGER PRIMARY KEY AUTOINCREMENT,
            uid INTEGER NOT NULL,
            username TEXT DEFAULT '',
            file_path TEXT NOT NULL,
            file_name TEXT DEFAULT '',
            issues TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',
            reviewed_by INTEGER DEFAULT 0,
            created_at TEXT DEFAULT(datetime('now'))
        )""")

        self._exe("""CREATE TABLE IF NOT EXISTS payments(
            pid INTEGER PRIMARY KEY AUTOINCREMENT,
            uid INTEGER, amount REAL, currency TEXT DEFAULT 'BDT',
            method TEXT, trx_id TEXT, plan TEXT,
            duration_days INTEGER DEFAULT 30,
            status TEXT DEFAULT 'pending',
            approved_by INTEGER,
            created_at TEXT DEFAULT(datetime('now')),
            processed_at TEXT
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS withdrawals(
            wid INTEGER PRIMARY KEY AUTOINCREMENT,
            uid INTEGER, amount REAL, method TEXT,
            account TEXT, status TEXT DEFAULT 'pending',
            approved_by INTEGER,
            created_at TEXT DEFAULT(datetime('now')),
            processed_at TEXT
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS notifications(
            nid INTEGER PRIMARY KEY AUTOINCREMENT,
            uid INTEGER, title TEXT, message TEXT,
            is_read INTEGER DEFAULT 0,
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS force_channels(
            cid INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE, name TEXT,
            is_active INTEGER DEFAULT 1,
            added_by INTEGER,
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS promo_codes(
            promo_id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE, discount INTEGER DEFAULT 0,
            max_uses INTEGER DEFAULT 100, used_count INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS admin_logs(
            lid INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER, action TEXT,
            target INTEGER, details TEXT,
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        self._exe("""CREATE TABLE IF NOT EXISTS error_logs(
            eid INTEGER PRIMARY KEY AUTOINCREMENT,
            level TEXT DEFAULT 'ERROR',
            source TEXT, message TEXT,
            user_id INTEGER,
            created_at TEXT DEFAULT(datetime('now'))
        )""")
        # Indexes for fast lookups
        self._exe("CREATE INDEX IF NOT EXISTS idx_users_ref_code ON users(ref_code)")
        self._exe("CREATE INDEX IF NOT EXISTS idx_bots_uid ON bots(uid)")
        self._exe("CREATE INDEX IF NOT EXISTS idx_bots_status ON bots(status)")
        self._exe("CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status)")
        self._exe("CREATE INDEX IF NOT EXISTS idx_withdrawals_uid_status ON withdrawals(uid,status)")
        # ── Schema Migration: add columns added in newer versions ──
        self._migrate_sqlite()
        self._exe("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)")

    def _migrate_sqlite(self):
        """Safely add new columns to existing SQLite DB without breaking old installs."""
        migrations = [
            # (table, column, definition)
            ('bots',  'assigned_plan',  "TEXT DEFAULT 'free'"),
            ('users', 'ref_pending',    "TEXT DEFAULT NULL"),
            ('users', 'ad_code_fails',  "INTEGER DEFAULT 0"),
            ('users', 'ad_pending_token', "TEXT DEFAULT ''"),
        ]
        with self._conn() as con:
            cur = con.cursor()
            for table, col, defn in migrations:
                try:
                    cur.execute(f"ALTER TABLE {table} ADD COLUMN {col} {defn}")
                    con.commit()
                except Exception:
                    pass  # Column already exists — ignore



    # ══════════════════════════════════
    #  USER
    # ══════════════════════════════════
    def get_user(self, uid):
        if USE_MONGO:
            return mongo_db.users.find_one({'uid': uid}, {'_id': 0})
        return self._exe("SELECT * FROM users WHERE uid=?", (uid,), one=True)

    def create_user(self, uid, username='', full_name='', ref_by=None):
        rc = gen_ref_code(uid)
        now = datetime.now().isoformat()
        if USE_MONGO:
            try:
                mongo_db.users.update_one({'uid': uid}, {'$setOnInsert': {
                    'uid': uid, 'username': username, 'full_name': full_name,
                    'lang': 'en', 'plan': 'free', 'plan_stack': [],
                    'extra_bots': 0, 'wallet': 0, 'total_spent': 0,
                    'is_banned': 0, 'ban_reason': '', 'is_lifetime': 0,
                    'sub_end': None, 'free_start': now,
                    'ref_code': rc, 'referred_by': ref_by,
                    'ref_count': 0, 'ref_earn': 0, 'ref_level': 'bronze',
                    'ad_last_watch': None,
                    'last_active': now, 'created_at': now
                }}, upsert=True)
            except Exception as e:
                # DuplicateKeyError can still surface if a stale unique index on
                # a field other than `uid` exists in the database (e.g. user_id_1).
                # The startup cleanup should have removed it, but guard here too.
                if "DuplicateKey" in type(e).__name__:
                    logger.warning(
                        f"create_user uid={uid}: DuplicateKeyError suppressed — "
                        f"user likely already exists or a stale index is present. "
                        f"Detail: {e}"
                    )
                else:
                    raise
        else:
            self._exe(
                "INSERT OR IGNORE INTO users(uid,username,full_name,ref_code,referred_by,free_start) VALUES(?,?,?,?,?,?)",
                (uid, username, full_name, rc, ref_by, now)
            )

    def get_user_by_ref_code(self, ref_code):
        """Fast ref_code lookup — uses index on SQLite, index on MongoDB."""
        if USE_MONGO:
            return mongo_db.users.find_one({'ref_code': ref_code}, {'_id': 0})
        return self._exe("SELECT * FROM users WHERE ref_code=?", (ref_code,), one=True)

    # Allowed columns for update_user — prevents column-injection
    _USER_COLS = frozenset({
        'username','full_name','lang','plan','plan_stack','extra_bots',
        'wallet','total_spent','is_banned','ban_reason','is_lifetime',
        'sub_end','free_start','ref_code','referred_by','ref_count',
        'ref_earn','ref_level','ad_last_watch','last_active',
    })

    def update_user(self, uid, **kw):
        if not kw: return
        bad = set(kw) - self._USER_COLS
        if bad:
            logger.error(f"update_user blocked unknown columns: {bad}")
            kw = {k: v for k, v in kw.items() if k in self._USER_COLS}
        if not kw: return
        if USE_MONGO:
            mongo_db.users.update_one({'uid': uid}, {'$set': kw})
        else:
            cols = ','.join(f'{k}=?' for k in kw)
            self._exe(f"UPDATE users SET {cols} WHERE uid=?", list(kw.values()) + [uid])

    # ── Quarantine Functions ──────────────────────────────────────────────
    def quarantine_file(self, uid: int, username: str, file_path: str,
                        file_name: str, issues: str) -> int:
        """Blocked file কে quarantine এ রাখো। Admin approve/reject করবে।"""
        if USE_MONGO:
            import time
            doc = {'uid': uid, 'username': username, 'file_path': file_path,
                   'file_name': file_name, 'issues': issues,
                   'status': 'pending', 'reviewed_by': 0,
                   'created_at': str(time.time())}
            r = mongo_db.quarantine.insert_one(doc)
            return str(r.inserted_id)
        r = self._exe(
            "INSERT INTO quarantine(uid,username,file_path,file_name,issues) VALUES(?,?,?,?,?)",
            (uid, username, file_path, file_name, issues), fetch=True)
        return self._exe("SELECT last_insert_rowid()", fetch=True)[0][0]

    def get_pending_quarantine(self):
        """Admin এর approve/reject এর জন্য pending files।"""
        if USE_MONGO:
            return list(mongo_db.quarantine.find({'status': 'pending'}))
        return self._exe(
            "SELECT * FROM quarantine WHERE status='pending' ORDER BY created_at DESC",
            fetch=True) or []

    def get_quarantine(self, qid):
        """একটি quarantine entry নাও।"""
        if USE_MONGO:
            from bson import ObjectId
            return mongo_db.quarantine.find_one({'_id': ObjectId(str(qid))})
        rows = self._exe("SELECT * FROM quarantine WHERE qid=?", (qid,), fetch=True)
        if not rows: return None
        cols = ['qid','uid','username','file_path','file_name','issues',
                'status','reviewed_by','created_at']
        return dict(zip(cols, rows[0]))

    def approve_quarantine(self, qid: int, admin_id: int):
        """Admin file approve করলো — চলতে দাও।"""
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.quarantine.update_one(
                {'_id': ObjectId(str(qid))},
                {'$set': {'status': 'approved', 'reviewed_by': admin_id}})
            return
        self._exe("UPDATE quarantine SET status='approved',reviewed_by=? WHERE qid=?",
                  (admin_id, qid))

    def reject_quarantine(self, qid: int, admin_id: int):
        """Admin file reject করলো — delete করো।"""
        import shutil
        q = self.get_quarantine(qid)
        if q and q.get('file_path'):
            try:
                fp = q['file_path']
                if os.path.isdir(fp):
                    shutil.rmtree(fp, ignore_errors=True)
                elif os.path.isfile(fp):
                    os.remove(fp)
            except Exception:
                pass
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.quarantine.update_one(
                {'_id': ObjectId(str(qid))},
                {'$set': {'status': 'rejected', 'reviewed_by': admin_id}})
            return
        self._exe("UPDATE quarantine SET status='rejected',reviewed_by=? WHERE qid=?",
                  (admin_id, qid))


    def count_users(self) -> int:
        """Total user count."""
        if USE_MONGO:
            return mongo_db.users.count_documents({})
        r = self._exe("SELECT COUNT(*) FROM users", fetch=True)
        return r[0][0] if r else 0

    def count_active_bots(self) -> int:
        """Currently running bot count."""
        if USE_MONGO:
            return mongo_db.bots.count_documents({'status': 'running'})
        r = self._exe("SELECT COUNT(*) FROM bots WHERE status='running'", fetch=True)
        return r[0][0] if r else 0

    def count_today_payments(self) -> int:
        """Today's payment submissions."""
        from datetime import date
        today = date.today().isoformat()
        if USE_MONGO:
            return mongo_db.payments.count_documents({'date': {'$gte': today}})
        r = self._exe("SELECT COUNT(*) FROM payments WHERE created_at >= ?", (today,), fetch=True)
        return r[0][0] if r else 0

    def get_all_users(self):
        if USE_MONGO:
            return list(mongo_db.users.find({}, {'_id': 0, 'uid': 1, 'username': 1,
                'full_name': 1, 'plan': 1, 'is_banned': 1, 'wallet': 1,
                'sub_end': 1, 'ref_count': 1, 'created_at': 1, 'extra_bots': 1}))
        return self._exe("SELECT uid,username,full_name,plan,is_banned,wallet,sub_end,ref_count,created_at,extra_bots FROM users", fetch=True) or []

    def set_lang(self, uid, lang):
        self.update_user(uid, lang=lang)

    def get_lang(self, uid):
        u = self.get_user(uid)
        return u.get('lang', 'en') if u else 'en'

    def ban(self, uid, reason=''):
        self.update_user(uid, is_banned=1, ban_reason=reason)

    def unban(self, uid):
        self.update_user(uid, is_banned=0, ban_reason='')

    # ══════════════════════════════════
    #  PLAN STACKING
    # ══════════════════════════════════
    def get_total_bots(self, uid):
        """Total bot slots = sum of all plans' bot slots (calculated from RAM ÷ MIN_RAM_PER_BOT)."""
        u = self.get_user(uid)
        if not u:
            return 1
        if uid == OWNER_ID or u.get('is_lifetime'):
            return -1  # unlimited
        # Check unlimited plan
        base_plan = u.get('plan', 'free')
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        all_plans = [base_plan] + stack
        if 'unlimited' in all_plans:
            return -1
        # Sum bots from all plans (bots field is auto-calculated from RAM in config)
        total = sum(PLAN_LIMITS.get(p, PLAN_LIMITS['free'])['bots'] for p in all_plans)
        return max(1, total)

    def get_total_ram(self, uid):
        """Total system RAM = sum of each plan's (bots × per_bot_ram)."""
        u = self.get_user(uid)
        if not u:
            return 128
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        all_plans = [u.get('plan', 'free')] + stack
        return sum(PLAN_LIMITS.get(p, PLAN_LIMITS['free']).get('ram', 128) for p in all_plans)

    def get_ram_per_bot(self, uid):
        """Per-bot RAM = plan's per_bot_ram (NOT shared/divided).
        For stacked plans returns highest per_bot_ram among all active plans."""
        u = self.get_user(uid)
        if not u:
            return 128
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        all_plans = [u.get('plan', 'free')] + stack
        return max(
            PLAN_LIMITS.get(p, PLAN_LIMITS['free']).get('per_bot_ram', 128)
            for p in all_plans
        )

    def get_bot_ram_limit(self, uid, bot_name=None):
        """RAM limit for a specific bot based on its assigned_plan's per_bot_ram."""
        if bot_name:
            bots = self.get_bots(uid)
            bot  = next((b for b in bots if b['name'] == bot_name), None)
            if bot and bot.get('assigned_plan'):
                p = PLAN_LIMITS.get(bot['assigned_plan'], PLAN_LIMITS['free'])
                return p.get('per_bot_ram', 128)
        return self.get_ram_per_bot(uid)

    def get_active_plan_display(self, uid):
        """Return display-friendly plan name, considering plan_stack."""
        u = self.get_user(uid)
        if not u:
            return PLAN_LIMITS['free']['name']
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        base_plan = u.get('plan', 'free')
        if not stack:
            return PLAN_LIMITS.get(base_plan, PLAN_LIMITS['free'])['name']
        # Show all active plans
        all_plans = [base_plan] + stack
        names = [PLAN_LIMITS.get(p, {}).get('name', p) for p in all_plans if p != 'free']
        if not names:
            return PLAN_LIMITS['free']['name']
        return ' + '.join(names)

    def add_plan_stack(self, uid, plan, days=30):
        """Add a plan on top of existing — stacking."""
        u = self.get_user(uid)
        if not u:
            return
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []

        # Add plan to stack
        stack.append(plan)
        extra_bots = u.get('extra_bots', 0) + PLAN_LIMITS.get(plan, {}).get('bots', 0)

        # Extend subscription
        current_end = u.get('sub_end')
        if current_end:
            try:
                end = max(datetime.fromisoformat(current_end), datetime.now())
            except:
                end = datetime.now()
        else:
            end = datetime.now()
        new_end = (end + timedelta(days=days)).isoformat()

        stack_str = json.dumps(stack) if not USE_MONGO else stack
        self.update_user(uid, plan_stack=stack_str, extra_bots=extra_bots, sub_end=new_end)

    def set_plan(self, uid, plan, days=30):
        """Set primary plan."""
        p = PLAN_LIMITS.get(plan, PLAN_LIMITS['free'])
        if plan == 'unlimited':
            self.update_user(uid, plan=plan, is_lifetime=1, sub_end=None)
        else:
            end = (datetime.now() + timedelta(days=days)).isoformat()
            self.update_user(uid, plan=plan, is_lifetime=0, sub_end=end)

    def rem_plan(self, uid):
        self.update_user(uid, plan='free', is_lifetime=0, sub_end=None,
                         plan_stack='[]' if not USE_MONGO else [], extra_bots=0)

    def is_active_sub(self, uid):
        u = self.get_user(uid)
        if not u: return False
        if u.get('is_lifetime'): return True
        # Check plan_stack — if user has any paid plan stacked, treat as active
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        if stack:
            se = u.get('sub_end')
            if se:
                try: return datetime.fromisoformat(se) > datetime.now()
                except: pass
            return True  # has stack but no end date — lifetime-like
        # No stack — check base plan
        if u.get('plan', 'free') == 'free': return True
        se = u.get('sub_end')
        if se:
            try: return datetime.fromisoformat(se) > datetime.now()
            except: return False
        return False

    def has_paid_plan(self, uid):
        """True if user has any active paid plan (base or stacked)."""
        u = self.get_user(uid)
        if not u: return False
        if u.get('is_lifetime'): return True
        stack = u.get('plan_stack', [])
        if isinstance(stack, str):
            try:
                stack = json.loads(stack)
            except:
                stack = []
        base = u.get('plan', 'free')
        all_plans = ([base] if base != 'free' else []) + [p for p in stack if p != 'free']
        if not all_plans: return False
        # Check sub_end
        se = u.get('sub_end')
        if se:
            try: return datetime.fromisoformat(se) > datetime.now()
            except: return False
        return bool(all_plans)

    def is_free_expired(self, uid):
        """Check if free 7-day period expired. Returns False if user has any paid plan."""
        from config import FREE_PLAN_DAYS
        u = self.get_user(uid)
        if not u: return False
        # If user has any paid plan (base or stacked), they are NOT on free
        if self.has_paid_plan(uid): return False
        if u.get('plan', 'free') != 'free': return False
        fs = u.get('free_start')
        if not fs: return False
        try:
            return datetime.now() > datetime.fromisoformat(fs) + timedelta(days=FREE_PLAN_DAYS)
        except:
            return False

    def can_watch_ad(self, uid):
        """Check if 24h passed since last ad."""
        u = self.get_user(uid)
        if not u: return True
        last = u.get('ad_last_watch')
        if not last: return True
        try:
            return datetime.now() > datetime.fromisoformat(last) + timedelta(hours=24)
        except:
            return True

    def record_ad_watch(self, uid):
        """Record ad watch and add 24h to sub_end. Does NOT change plan."""
        now = datetime.now()
        u = self.get_user(uid)
        if not u: return
        se = u.get('sub_end')
        if se:
            try: base = max(datetime.fromisoformat(se), now)
            except: base = now
        else:
            base = now
        new_end = (base + timedelta(hours=24)).isoformat()
        self.update_user(uid, ad_last_watch=now.isoformat(), sub_end=new_end)

    def save_ad_token(self, uid, token: str):
        """Save pending ad token for verification."""
        self.update_user(uid, ad_pending_token=token, ad_code_fails=0)

    def clear_ad_token(self, uid):
        """Clear token after successful verification."""
        self.update_user(uid, ad_pending_token='')


    # ══════════════════════════════════
    #  BOTS
    # ══════════════════════════════════
    def add_bot(self, uid, name, path, entry='main.py', ftype='py', backup_msg_id=0, assigned_plan='free'):
        now = datetime.now().isoformat()
        if USE_MONGO:
            r = mongo_db.bots.insert_one({
                'uid': uid, 'name': name, 'file_path': path,
                'entry': entry, 'ftype': ftype, 'status': 'stopped',
                'restarts': 0, 'backup_msg_id': backup_msg_id,
                'uptime_seconds': 0, 'assigned_plan': assigned_plan,
                'created_at': now, 'last_start': None, 'last_stop': None
            })
            return str(r.inserted_id)
        return self._exe(
            "INSERT INTO bots(uid,name,file_path,entry,ftype,backup_msg_id,assigned_plan) VALUES(?,?,?,?,?,?,?)",
            (uid, name, path, entry, ftype, backup_msg_id, assigned_plan)
        )

    def get_bots(self, uid):
        if USE_MONGO:
            bots = list(mongo_db.bots.find({'uid': uid}).sort('created_at', -1))
            for b in bots:
                b['bid'] = str(b.pop('_id'))
            return bots
        return self._exe("SELECT * FROM bots WHERE uid=? ORDER BY created_at DESC", (uid,), fetch=True) or []

    def get_bot(self, bid):
        if USE_MONGO:
            from bson import ObjectId
            try:
                b = mongo_db.bots.find_one({'_id': ObjectId(str(bid))})
                if b: b['bid'] = str(b.pop('_id'))
                return b
            except: return None
        return self._exe("SELECT * FROM bots WHERE bid=?", (bid,), one=True)

    # Allowed columns for update_bot — prevents column-injection
    _BOT_COLS = frozenset({
        'name','file_path','entry','ftype','status','restarts',
        'backup_msg_id','uptime_seconds','last_start','last_stop',
        'assigned_plan',
    })

    def update_bot(self, bid, **kw):
        bad = set(kw) - self._BOT_COLS
        if bad:
            logger.error(f"update_bot blocked unknown columns: {bad}")
            kw = {k: v for k, v in kw.items() if k in self._BOT_COLS}
        if not kw: return
        if USE_MONGO:
            from bson import ObjectId
            try: mongo_db.bots.update_one({'_id': ObjectId(str(bid))}, {'$set': kw})
            except: pass
        else:
            cols = ','.join(f'{k}=?' for k in kw)
            self._exe(f"UPDATE bots SET {cols} WHERE bid=?", list(kw.values()) + [bid])

    def del_bot(self, bid):
        if USE_MONGO:
            from bson import ObjectId
            try: mongo_db.bots.delete_one({'_id': ObjectId(str(bid))})
            except: pass
        else:
            self._exe("DELETE FROM bots WHERE bid=?", (bid,))

    def bot_count(self, uid):
        if USE_MONGO:
            return mongo_db.bots.count_documents({'uid': uid})
        r = self._exe("SELECT COUNT(*) as c FROM bots WHERE uid=?", (uid,), one=True)
        return r['c'] if r else 0

    def get_all_running(self):
        if USE_MONGO:
            bots = list(mongo_db.bots.find({'status': 'running'}))
            for b in bots:
                b['bid'] = str(b.pop('_id'))
            return bots
        rows = self._exe("SELECT bid, uid, name, file_path, entry, ftype, status, restarts FROM bots WHERE status='running'", fetch=True) or []
        return rows

    # ══════════════════════════════════
    #  PAYMENTS
    # ══════════════════════════════════
    def add_payment(self, uid, amount, method, trx_id, plan, days=30, currency='BDT'):
        now = datetime.now().isoformat()
        if USE_MONGO:
            r = mongo_db.payments.insert_one({
                'uid': uid, 'amount': amount, 'currency': currency,
                'method': method, 'trx_id': trx_id, 'plan': plan,
                'duration_days': days, 'status': 'pending',
                'approved_by': None, 'created_at': now, 'processed_at': None
            })
            return str(r.inserted_id)
        return self._exe(
            "INSERT INTO payments(uid,amount,currency,method,trx_id,plan,duration_days) VALUES(?,?,?,?,?,?,?)",
            (uid, amount, currency, method, trx_id, plan, days)
        )

    def pending_payments(self):
        if USE_MONGO:
            pays = list(mongo_db.payments.find({'status': 'pending'}).sort('created_at', -1))
            for p in pays: p['pid'] = str(p.pop('_id'))
            return pays
        return self._exe("SELECT * FROM payments WHERE status='pending' ORDER BY created_at DESC", fetch=True) or []

    def get_payment(self, pid):
        if USE_MONGO:
            from bson import ObjectId
            try:
                p = mongo_db.payments.find_one({'_id': ObjectId(str(pid))})
                if p: p['pid'] = str(p.pop('_id'))
                return p
            except: return None
        return self._exe("SELECT * FROM payments WHERE pid=?", (pid,), one=True)

    def approve_payment(self, pid, admin_id):
        p = self.get_payment(pid)
        if not p: return None
        # Idempotency guard — prevent double-approval giving plan twice
        if p.get('status') != 'pending':
            logger.warning(f"approve_payment: pid={pid} already {p.get('status')} — skipped")
            return None
        now = datetime.now().isoformat()
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.payments.update_one({'_id': ObjectId(str(pid))},
                {'$set': {'status': 'approved', 'approved_by': admin_id, 'processed_at': now}})
        else:
            self._exe("UPDATE payments SET status='approved',approved_by=?,processed_at=? WHERE pid=?",
                      (admin_id, now, pid))
        # Stack plan
        self.add_plan_stack(p['uid'], p['plan'], p.get('duration_days', 30))
        u = self.get_user(p['uid'])
        if u:
            # Use $inc in MongoDB to avoid read-then-write race on total_spent
            if USE_MONGO:
                mongo_db.users.update_one({'uid': p['uid']},
                    {'$inc': {'total_spent': p['amount']}})
            else:
                self.update_user(p['uid'], total_spent=(u.get('total_spent', 0) + p['amount']))
        return p

    def reject_payment(self, pid, admin_id):
        now = datetime.now().isoformat()
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.payments.update_one({'_id': ObjectId(str(pid))},
                {'$set': {'status': 'rejected', 'approved_by': admin_id, 'processed_at': now}})
        else:
            self._exe("UPDATE payments SET status='rejected',approved_by=?,processed_at=? WHERE pid=?",
                      (admin_id, now, pid))

    def user_payments(self, uid):
        if USE_MONGO:
            pays = list(mongo_db.payments.find({'uid': uid}).sort('created_at', -1))
            for p in pays: p['pid'] = str(p.pop('_id'))
            return pays
        return self._exe("SELECT * FROM payments WHERE uid=? ORDER BY created_at DESC", (uid,), fetch=True) or []

    # ══════════════════════════════════
    #  WITHDRAWALS
    # ══════════════════════════════════
    def add_withdrawal(self, uid, amount, method, account):
        now = datetime.now().isoformat()
        u = self.get_user(uid)
        if not u or u.get('wallet', 0) < amount:
            return None, "Insufficient balance"
        pending = self.pending_withdrawals_by_user(uid)
        if pending:
            return None, "You already have a pending withdrawal"
        self.wallet_tx(uid, -amount, 'withdraw', f"Withdraw: {method} {account}")
        if USE_MONGO:
            r = mongo_db.withdrawals.insert_one({
                'uid': uid, 'amount': amount, 'method': method,
                'account': account, 'status': 'pending',
                'approved_by': None, 'created_at': now, 'processed_at': None
            })
            return str(r.inserted_id), None
        wid = self._exe(
            "INSERT INTO withdrawals(uid,amount,method,account) VALUES(?,?,?,?)",
            (uid, amount, method, account)
        )
        return wid, None

    def pending_withdrawals(self):
        if USE_MONGO:
            wds = list(mongo_db.withdrawals.find({'status': 'pending'}).sort('created_at', -1))
            for w in wds: w['wid'] = str(w.pop('_id'))
            return wds
        return self._exe("SELECT * FROM withdrawals WHERE status='pending' ORDER BY created_at DESC", fetch=True) or []

    def pending_withdrawals_by_user(self, uid):
        if USE_MONGO:
            return list(mongo_db.withdrawals.find({'uid': uid, 'status': 'pending'}))
        return self._exe("SELECT * FROM withdrawals WHERE uid=? AND status='pending'", (uid,), fetch=True) or []

    def get_withdrawal(self, wid):
        if USE_MONGO:
            from bson import ObjectId
            try:
                w = mongo_db.withdrawals.find_one({'_id': ObjectId(str(wid))})
                if w: w['wid'] = str(w.pop('_id'))
                return w
            except: return None
        return self._exe("SELECT * FROM withdrawals WHERE wid=?", (wid,), one=True)

    def approve_withdrawal(self, wid, admin_id):
        now = datetime.now().isoformat()
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.withdrawals.update_one({'_id': ObjectId(str(wid))},
                {'$set': {'status': 'approved', 'approved_by': admin_id, 'processed_at': now}})
        else:
            self._exe("UPDATE withdrawals SET status='approved',approved_by=?,processed_at=? WHERE wid=?",
                      (admin_id, now, wid))

    def reject_withdrawal(self, wid, admin_id):
        w = self.get_withdrawal(wid)
        if not w: return
        # Idempotency guard — only refund if still pending, not already rejected/approved
        if w.get('status') != 'pending':
            logger.warning(f"reject_withdrawal: wid={wid} already {w.get('status')} — skipped")
            return
        now = datetime.now().isoformat()
        if USE_MONGO:
            from bson import ObjectId
            mongo_db.withdrawals.update_one({'_id': ObjectId(str(wid))},
                {'$set': {'status': 'rejected', 'approved_by': admin_id, 'processed_at': now}})
        else:
            self._exe("UPDATE withdrawals SET status='rejected',approved_by=?,processed_at=? WHERE wid=?",
                      (admin_id, now, wid))
        # Refund the held amount back to wallet
        self.wallet_tx(w['uid'], w['amount'], 'refund', "Withdrawal rejected — refunded")

    # ══════════════════════════════════
    #  WALLET
    # ══════════════════════════════════
    def wallet_tx(self, uid, amount, tx_type, desc=''):
        if USE_MONGO:
            # Atomic $inc avoids read-then-write race when concurrent calls happen
            # (e.g. referral commission + ad bonus arriving simultaneously)
            mongo_db.users.update_one(
                {'uid': uid},
                {'$inc': {'wallet': amount}}
            )
            # Clamp to 0 in a second atomic op if result went negative
            mongo_db.users.update_one(
                {'uid': uid, 'wallet': {'$lt': 0}},
                {'$set': {'wallet': 0}}
            )
        else:
            u = self.get_user(uid)
            if not u: return
            new_bal = (u.get('wallet', 0) or 0) + amount
            self.update_user(uid, wallet=max(0, new_bal))

    # ══════════════════════════════════
    #  REFERRAL
    # ══════════════════════════════════
    def add_referral(self, referrer_id, referred_id, commission=20, bonus_days=3):
        u = self.get_user(referrer_id)
        if not u: return
        nc = (u.get('ref_count', 0) or 0) + 1
        lv = ('diamond' if nc >= 100 else 'platinum' if nc >= 50
              else 'gold' if nc >= 25 else 'silver' if nc >= 10 else 'bronze')
        self.update_user(referrer_id,
            ref_count=nc,
            ref_earn=(u.get('ref_earn', 0) or 0) + commission,
            ref_level=lv
        )
        self.wallet_tx(referrer_id, commission, 'referral', f"Referral from {referred_id}")
        # Bonus days — extend sub_end directly (stacking 'free' adds 0 bots and clutters plan_stack)
        ref_u = self.get_user(referrer_id)
        if ref_u:
            from datetime import timedelta
            se = ref_u.get('sub_end')
            if se:
                try:
                    base = max(datetime.fromisoformat(se), datetime.now())
                except:
                    base = datetime.now()
            else:
                base = datetime.now()
            new_end = (base + timedelta(days=bonus_days)).isoformat()
            self.update_user(referrer_id, sub_end=new_end)

    def get_leaderboard(self, limit=10):
        if USE_MONGO:
            return list(mongo_db.users.find({}, {'_id': 0, 'uid': 1, 'full_name': 1,
                'ref_count': 1, 'ref_level': 1}).sort('ref_count', -1).limit(limit))
        return self._exe(
            "SELECT uid,full_name,ref_count,ref_level FROM users ORDER BY ref_count DESC LIMIT ?",
            (limit,), fetch=True
        ) or []

    # ══════════════════════════════════
    #  NOTIFICATIONS
    # ══════════════════════════════════
    def add_notif(self, uid, title, message):
        now = datetime.now().isoformat()
        if USE_MONGO:
            mongo_db.notifications.insert_one({'uid': uid, 'title': title,
                'message': message, 'is_read': 0, 'created_at': now})
        else:
            self._exe("INSERT INTO notifications(uid,title,message) VALUES(?,?,?)", (uid, title, message))

    def get_notifs(self, uid, limit=10):
        if USE_MONGO:
            ns = list(mongo_db.notifications.find({'uid': uid}).sort('created_at', -1).limit(limit))
            for n in ns: n.pop('_id', None)
            return ns
        return self._exe("SELECT * FROM notifications WHERE uid=? ORDER BY created_at DESC LIMIT ?",
                         (uid, limit), fetch=True) or []

    def mark_read(self, uid):
        if USE_MONGO:
            mongo_db.notifications.update_many({'uid': uid}, {'$set': {'is_read': 1}})
        else:
            self._exe("UPDATE notifications SET is_read=1 WHERE uid=?", (uid,))

    def unread_count(self, uid):
        if USE_MONGO:
            return mongo_db.notifications.count_documents({'uid': uid, 'is_read': 0})
        r = self._exe("SELECT COUNT(*) as c FROM notifications WHERE uid=? AND is_read=0", (uid,), one=True)
        return r['c'] if r else 0

    # ══════════════════════════════════
    #  CHANNELS
    # ══════════════════════════════════
    def get_active_channels(self):
        if USE_MONGO:
            return list(mongo_db.force_channels.find({'is_active': 1}, {'_id': 0}))
        return self._exe("SELECT * FROM force_channels WHERE is_active=1", fetch=True) or []

    def add_channel(self, username, name='', added_by=None):
        username = username.strip().lstrip('@').lower()
        if USE_MONGO:
            mongo_db.force_channels.update_one({'username': username},
                {'$set': {'name': name or username, 'is_active': 1, 'added_by': added_by}}, upsert=True)
        else:
            ex = self._exe("SELECT cid FROM force_channels WHERE username=?", (username,), one=True)
            if ex:
                self._exe("UPDATE force_channels SET is_active=1,name=? WHERE username=?", (name or username, username))
            else:
                self._exe("INSERT INTO force_channels(username,name,added_by) VALUES(?,?,?)",
                          (username, name or username, added_by))

    def remove_channel(self, username):
        username = username.strip().lstrip('@').lower()
        if USE_MONGO:
            mongo_db.force_channels.update_one({'username': username}, {'$set': {'is_active': 0}})
        else:
            self._exe("UPDATE force_channels SET is_active=0 WHERE username=?", (username,))

    def cleanup_empty_channels(self):
        """Remove channels with empty or null username from database"""
        if USE_MONGO:
            mongo_db.force_channels.delete_many({'$or': [{'username': ''}, {'username': None}]})
        else:
            self._exe("DELETE FROM force_channels WHERE username IS NULL OR username=''")

    def get_all_channels(self):
        if USE_MONGO:
            return list(mongo_db.force_channels.find({}, {'_id': 0}))
        return self._exe("SELECT * FROM force_channels ORDER BY is_active DESC", fetch=True) or []

    def get_backup_channel(self):
        from config import BACKUP_CHANNEL_ID
        if USE_MONGO:
            rec = mongo_db.settings.find_one({'key': 'backup_channel'}, {'_id': 0})
            return rec['value'] if rec else BACKUP_CHANNEL_ID
        return BACKUP_CHANNEL_ID

    def set_backup_channel(self, channel_id):
        if USE_MONGO:
            mongo_db.settings.update_one({'key': 'backup_channel'},
                {'$set': {'value': channel_id}}, upsert=True)

    # ── Dynamic Settings (Referral, Withdrawal) ───────────────────────────
    def get_setting(self, key: str, default=None):
        """Admin-settable dynamic config."""
        if USE_MONGO:
            rec = mongo_db.settings.find_one({'key': key}, {'_id': 0})
            return rec['value'] if rec else default
        # SQLite fallback — settings table
        try:
            r = self._exe("SELECT value FROM settings WHERE key=?", (key,), one=True)
            return r['value'] if r else default
        except Exception:
            return default

    def set_setting(self, key: str, value):
        """Save admin-settable config."""
        if USE_MONGO:
            mongo_db.settings.update_one({'key': key},
                {'$set': {'value': value}}, upsert=True)
            return
        try:
            self._exe(
                "INSERT INTO settings(key,value) VALUES(?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value))
            )
        except Exception:
            pass

    def get_ref_commission(self) -> int:
        from config import REF_COMMISSION
        return int(self.get_setting('ref_commission', REF_COMMISSION))

    def get_ref_bonus_days(self) -> int:
        from config import REF_BONUS_DAYS
        return int(self.get_setting('ref_bonus_days', REF_BONUS_DAYS))

    def get_min_withdraw(self) -> int:
        from config import MIN_WITHDRAW
        return int(self.get_setting('min_withdraw', MIN_WITHDRAW))


    # ══════════════════════════════════
    #  PROMO CODES
    # ══════════════════════════════════
    def get_promo(self, code):
        if USE_MONGO:
            return mongo_db.promo_codes.find_one({'code': code.upper(), 'is_active': 1}, {'_id': 0})
        return self._exe("SELECT * FROM promo_codes WHERE code=? AND is_active=1", (code.upper(),), one=True)

    def use_promo(self, code):
        if USE_MONGO:
            mongo_db.promo_codes.update_one({'code': code.upper()}, {'$inc': {'used_count': 1}})
        else:
            self._exe("UPDATE promo_codes SET used_count=used_count+1 WHERE code=?", (code.upper(),))

    def add_promo(self, code, discount, max_uses, created_by):
        if USE_MONGO:
            try:
                mongo_db.promo_codes.insert_one({'code': code.upper(), 'discount': discount,
                    'max_uses': max_uses, 'used_count': 0, 'is_active': 1,
                    'created_at': datetime.now().isoformat()})
            except: pass
        else:
            self._exe("INSERT OR IGNORE INTO promo_codes(code,discount,max_uses) VALUES(?,?,?)",
                      (code.upper(), discount, max_uses))

    def all_promos(self):
        if USE_MONGO:
            ps = list(mongo_db.promo_codes.find({}, {'_id': 0}))
            return ps
        return self._exe("SELECT * FROM promo_codes ORDER BY created_at DESC", fetch=True) or []

    # ══════════════════════════════════
    #  ERROR LOGS
    # ══════════════════════════════════
    def log_error(self, source, message, user_id=None, level='ERROR'):
        now = datetime.now().isoformat()
        if USE_MONGO:
            mongo_db.error_logs.insert_one({'level': level, 'source': source,
                'message': message, 'user_id': user_id, 'created_at': now})
        else:
            self._exe("INSERT INTO error_logs(level,source,message,user_id) VALUES(?,?,?,?)",
                      (level, source, message, user_id))

    def get_error_logs(self, limit=100):
        if USE_MONGO:
            logs = list(mongo_db.error_logs.find({}, {'_id': 0}).sort('created_at', -1).limit(limit))
            return logs
        return self._exe("SELECT * FROM error_logs ORDER BY created_at DESC LIMIT ?",
                         (limit,), fetch=True) or []

    def export_error_log(self):
        """Export error logs as formatted text."""
        logs = self.get_error_logs(500)
        lines = [f"☁️ ARAFAT HOSTING CLOUD — Error Log Export",
                 f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                 "=" * 60]
        for l in logs:
            lines.append(
                f"[{l.get('created_at', '')[:19]}] [{l.get('level', 'ERROR')}] "
                f"{l.get('source', '?')} | User:{l.get('user_id', 'N/A')} | "
                f"{l.get('message', '')[:200]}"
            )
        return '\n'.join(lines)

    # ══════════════════════════════════
    #  ADMIN LOGS
    # ══════════════════════════════════
    def admin_log(self, admin_id, action, target=None, details=''):
        now = datetime.now().isoformat()
        if USE_MONGO:
            mongo_db.admin_logs.insert_one({'admin_id': admin_id, 'action': action,
                'target': target, 'details': details, 'created_at': now})
        else:
            self._exe("INSERT INTO admin_logs(admin_id,action,target,details) VALUES(?,?,?,?)",
                      (admin_id, action, target, details))

    def get_security_logs(self, limit=50):
        """IDS, scanner, vpsguard security events ফেরত দাও।"""
        sources = ['IDS', 'AHC.scanner', 'AHC.vpsguard',
                   'AHC.filelock', 'AHC.antirename', 'AHC.session']
        if USE_MONGO:
            return list(mongo_db.error_logs.find(
                {'source': {'$in': sources}}, {'_id': 0}
            ).sort('created_at', -1).limit(limit))
        placeholders = ','.join('?' * len(sources))
        return self._exe(
            f"SELECT * FROM error_logs WHERE source IN ({placeholders}) "
            f"ORDER BY created_at DESC LIMIT ?",
            sources + [limit], fetch=True
        ) or []

    def get_scan_stats(self):
        """Upload scan statistics ফেরত দাও।"""
        if USE_MONGO:
            total   = mongo_db.error_logs.count_documents({'source': 'AHC.scanner'})
            blocked = mongo_db.error_logs.count_documents(
                {'source': 'AHC.scanner', 'level': 'CRITICAL'})
            warned  = mongo_db.error_logs.count_documents(
                {'source': 'AHC.scanner', 'level': 'WARNING'})
            return {'total': total, 'blocked': blocked, 'warnings': warned}
        rows = self._exe(
            "SELECT level, COUNT(*) as c FROM error_logs "
            "WHERE source='AHC.scanner' GROUP BY level", fetch=True
        ) or []
        result = {'total': 0, 'blocked': 0, 'warnings': 0}
        for r in rows:
            lvl = r.get('level', '') if isinstance(r, dict) else (r[0] if r else '')
            cnt = r.get('c', 0)      if isinstance(r, dict) else (r[1] if len(r) > 1 else 0)
            result['total'] += cnt
            if lvl == 'CRITICAL': result['blocked']  = cnt
            if lvl == 'WARNING':  result['warnings'] = cnt
        return result

    def get_admin_logs(self, limit=20):
        """Admin action history ফেরত দাও।"""
        if USE_MONGO:
            return list(mongo_db.admin_logs.find(
                {}, {'_id': 0}).sort('created_at', -1).limit(limit))
        return self._exe(
            "SELECT * FROM admin_logs ORDER BY created_at DESC LIMIT ?",
            (limit,), fetch=True
        ) or []

    # ══════════════════════════════════
    #  STATS
    # ══════════════════════════════════
    def stats(self):
        today = datetime.now().strftime('%Y-%m-%d')
        if USE_MONGO:
            rev = list(mongo_db.payments.aggregate([
                {'$match': {'status': 'approved'}},
                {'$group': {'_id': None, 's': {'$sum': '$amount'}}}
            ]))
            return {
                'users':       mongo_db.users.count_documents({}),
                'today_users': mongo_db.users.count_documents({'created_at': {'$gte': today}}),
                'bots':        mongo_db.bots.count_documents({}),
                'running':     mongo_db.bots.count_documents({'status': 'running'}),
                'pending_pay': mongo_db.payments.count_documents({'status': 'pending'}),
                'pending_wd':  mongo_db.withdrawals.count_documents({'status': 'pending'}),
                'revenue':     rev[0].get('s', 0) if rev else 0,
                'banned':      mongo_db.users.count_documents({'is_banned': 1}),
                'errors':      mongo_db.error_logs.count_documents({}),
            }
        g  = lambda q: (self._exe(q, one=True) or {}).get('c', 0)
        gs = lambda q: (self._exe(q, one=True) or {}).get('s', 0)
        return {
            'users':       g("SELECT COUNT(*) as c FROM users"),
            'today_users': g(f"SELECT COUNT(*) as c FROM users WHERE date(created_at)=date('now')"),
            'bots':        g("SELECT COUNT(*) as c FROM bots"),
            'running':     g("SELECT COUNT(*) as c FROM bots WHERE status='running'"),
            'pending_pay': g("SELECT COUNT(*) as c FROM payments WHERE status='pending'"),
            'pending_wd':  g("SELECT COUNT(*) as c FROM withdrawals WHERE status='pending'"),
            'revenue':     gs("SELECT COALESCE(SUM(amount),0) as s FROM payments WHERE status='approved'"),
            'banned':      g("SELECT COUNT(*) as c FROM users WHERE is_banned=1"),
            'errors':      g("SELECT COUNT(*) as c FROM error_logs"),
        }


# ── Init ──────────────────────────────────────────────────
db = DB()
if not USE_MONGO:
    db.init_sqlite()
    logger.info("🗄️ Database: SQLite")
else:
    logger.info("🍃 Database: MongoDB")
