"""
☁️ ARAFAT HOSTING CLOUD — Language System v2.0
Supports: English (en) | বাংলা (bn)
"""

TEXTS = {

    # ══════════════════════════════════
    #  COMMON
    # ══════════════════════════════════
    'btn_back':         {'en': '🔙 Back',          'bn': '🔙 ফিরে যান'},
    'btn_home':         {'en': '🏠 Main Menu',      'bn': '🏠 মূল মেনু'},
    'btn_cancel':       {'en': '❌ Cancel',          'bn': '❌ বাতিল'},
    'btn_confirm':      {'en': '✅ Confirm',         'bn': '✅ নিশ্চিত'},
    'btn_contact':      {'en': '📞 Contact Dev',     'bn': '📞 ডেভেলপার'},

    # ══════════════════════════════════
    #  START / LANGUAGE
    # ══════════════════════════════════
    'choose_language': {
        'en': "🌐 <b>Welcome to Arafat Hosting Cloud!</b>\n\nPlease choose your language:",
        'bn': "🌐 <b>Arafat Hosting Cloud-এ স্বাগতম!</b>\n\nআপনার ভাষা বেছে নিন:",
    },
    'language_set': {
        'en': "✅ Language set to <b>English</b>!",
        'bn': "✅ ভাষা <b>বাংলা</b> সেট হয়েছে!",
    },
    'welcome': {
        'en': (
            "╔══════════════════════════╗\n"
            "║  ☁️ ARAFAT HOSTING CLOUD   ║\n"
            "╚══════════════════════════╝\n\n"
            "👋 Welcome, <b>{name}</b>!\n\n"
            "🆔 ID: <code>{uid}</code>\n"
            "💎 Plan: {plan}\n"
            "🤖 Bots: {bots}/{max_bots}\n"
            "📅 Expires: {expires}\n\n"
            "Host your Telegram bots easily! 🚀"
        ),
        'bn': (
            "╔══════════════════════════╗\n"
            "║  ☁️ ARAFAT HOSTING CLOUD   ║\n"
            "╚══════════════════════════╝\n\n"
            "👋 স্বাগতম, <b>{name}</b>!\n\n"
            "🆔 আইডি: <code>{uid}</code>\n"
            "💎 প্ল্যান: {plan}\n"
            "🤖 বট: {bots}/{max_bots}\n"
            "📅 মেয়াদ: {expires}\n\n"
            "সহজেই আপনার বট হোস্ট করুন! 🚀"
        ),
    },

    # ══════════════════════════════════
    #  MAIN MENU BUTTONS
    # ══════════════════════════════════
    'btn_mybots':     {'en': '🤖 My Bots',        'bn': '🤖 আমার বট'},
    'btn_deploy':     {'en': '🚀 Deploy Bot',      'bn': '🚀 বট যোগ করুন'},
    'btn_sub':        {'en': '💎 Subscription',    'bn': '💎 সাবস্ক্রিপশন'},
    'btn_wallet':     {'en': '💰 Wallet',          'bn': '💰 ওয়ালেট'},
    'btn_referral':   {'en': '🎁 Referral',        'bn': '🎁 রেফারেল'},
    'btn_stats':      {'en': '📊 My Stats',        'bn': '📊 আমার স্ট্যাটস'},
    'btn_running':    {'en': '🟢 Running Bots',    'bn': '🟢 চলমান বট'},
    'btn_notif':      {'en': '🔔 Notifications',   'bn': '🔔 নোটিফিকেশন'},
    'btn_settings':   {'en': '⚙️ Settings',        'bn': '⚙️ সেটিংস'},
    'btn_help':       {'en': '❓ Help',             'bn': '❓ সাহায্য'},
    'btn_admin':      {'en': '👑 Admin Panel',      'bn': '👑 এডমিন প্যানেল'},
    'btn_watchad':    {'en': '📺 Watch Ad (+24h)',  'bn': '📺 বিজ্ঞাপন দেখুন (+২৪ঘন্টা)'},

    # ══════════════════════════════════
    #  DEPLOY
    # ══════════════════════════════════
    'deploy_guide': {
        'en': (
            "🚀 <b>Deploy Your Bot</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📤 <b>Upload your bot file:</b>\n"
            "  • <code>.py</code> — Python script\n"
            "  • <code>.js</code> — Node.js script\n"
            "  • <code>.zip</code> — Full project\n\n"
            "✅ <b>Auto features:</b>\n"
            "  • Detects entry file automatically\n"
            "  • Installs packages automatically\n"
            "  • Backs up to channel automatically\n\n"
            "💎 Plan: <b>{plan}</b>\n"
            "🤖 Slots: <b>{used}/{max}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📤 Send your file now!"
        ),
        'bn': (
            "🚀 <b>বট ডিপ্লয় করুন</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📤 <b>আপনার বট ফাইল পাঠান:</b>\n"
            "  • <code>.py</code> — পাইথন স্ক্রিপ্ট\n"
            "  • <code>.js</code> — নোড.জেএস স্ক্রিপ্ট\n"
            "  • <code>.zip</code> — পূর্ণ প্রজেক্ট\n\n"
            "✅ <b>স্বয়ংক্রিয় সুবিধা:</b>\n"
            "  • এন্ট্রি ফাইল স্বয়ংক্রিয় সনাক্ত\n"
            "  • প্যাকেজ স্বয়ংক্রিয় ইনস্টল\n"
            "  • চ্যানেলে স্বয়ংক্রিয় ব্যাকআপ\n\n"
            "💎 প্ল্যান: <b>{plan}</b>\n"
            "🤖 স্লট: <b>{used}/{max}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "📤 এখন আপনার ফাইল পাঠান!"
        ),
    },

    # ══════════════════════════════════
    #  SUBSCRIPTION
    # ══════════════════════════════════
    'sub_guide': {
        'en': (
            "💎 <b>Subscription Plans</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📌 <b>How it works:</b>\n"
            "  • Each plan = N bots, each with their own RAM\n"
            "  • RAM is NOT shared — every bot gets its full amount\n"
            "  • Bigger plan = more bots + more RAM per bot\n\n"
            "📊 <b>Plan Overview:</b>\n"
            "  🆓 Free     → 1 bot  × 128MB each\n"
            "  🟢 Starter  → 2 bots × 256MB each\n"
            "  ⭐ Basic    → 3 bots × 384MB each\n"
            "  🔵 Standard → 4 bots × 512MB each\n"
            "  🟣 Advanced → 5 bots × 768MB each\n"
            "  💎 Pro      → 6 bots × 1024MB each\n"
            "  🔥 Ultra    → 7 bots × 1536MB each\n"
            "  👑 Premium  → 8 bots × 2048MB each\n"
            "  🏆 Elite    → 9 bots × 3072MB each\n"
            "  🌟 Master   → 10 bots × 4096MB each\n\n"
            "⚠️ <b>Free Plan:</b> 7 days only\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "Select a plan below 👇"
        ),
        'bn': (
            "💎 <b>সাবস্ক্রিপশন প্ল্যান</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "📌 <b>কীভাবে কাজ করে:</b>\n"
            "  • প্রতিটি plan-এ N টি bot, প্রতিটা আলাদা RAM পায়\n"
            "  • RAM ভাগ হয় না — প্রতিটি bot পুরো RAM পায়\n"
            "  • বড় plan = বেশি bot + প্রতিটায় বেশি RAM\n\n"
            "📊 <b>Plan সংক্ষেপ:</b>\n"
            "  🆓 Free     → ১ bot  × 128MB প্রতিটায়\n"
            "  🟢 Starter  → ২ bot  × 256MB প্রতিটায়\n"
            "  ⭐ Basic    → ৩ bot  × 384MB প্রতিটায়\n"
            "  🔵 Standard → ৪ bot  × 512MB প্রতিটায়\n"
            "  🟣 Advanced → ৫ bot  × 768MB প্রতিটায়\n"
            "  💎 Pro      → ৬ bot  × 1024MB প্রতিটায়\n"
            "  🔥 Ultra    → ৭ bot  × 1536MB প্রতিটায়\n"
            "  👑 Premium  → ৮ bot  × 2048MB প্রতিটায়\n"
            "  🏆 Elite    → ৯ bot  × 3072MB প্রতিটায়\n"
            "  🌟 Master   → ১০ bot × 4096MB প্রতিটায়\n\n"
            "⚠️ <b>ফ্রি প্ল্যান:</b> মাত্র ৭ দিন\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "নিচে প্ল্যান বেছে নিন 👇"
        ),
    },
    'plan_detail': {
        'en': (
            "{icon} <b>{name} Plan</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "🤖 Bots: <b>{bots}</b>\n"
            "💾 RAM: <b>{ram} MB per bot</b>\n"
            "📅 Duration: <b>{days} days</b>\n"
            "🔄 Auto-restart: <b>{restart}</b>\n"
            "💰 Price: <b>{price_bdt} BDT</b> / <b>{price_usdt} USDT</b>\n\n"
            "📌 <b>How to buy:</b>\n"
            "  1. Select payment method\n"
            "  2. Send payment\n"
            "  3. Send TRX ID here\n"
            "  4. Admin verifies & activates\n\n"
            "🔁 <b>Can buy multiple times</b> — adds more bots!\n"
            "━━━━━━━━━━━━━━━━━━━━"
        ),
        'bn': (
            "{icon} <b>{name} প্ল্যান</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "🤖 বট: <b>{bots}টি</b>\n"
            "💾 র‍্যাম: <b>প্রতি বটে {ram} MB</b>\n"
            "📅 মেয়াদ: <b>{days} দিন</b>\n"
            "🔄 অটো-রিস্টার্ট: <b>{restart}</b>\n"
            "💰 মূল্য: <b>{price_bdt} টাকা</b> / <b>{price_usdt} USDT</b>\n\n"
            "📌 <b>কীভাবে কিনবেন:</b>\n"
            "  ১. পেমেন্ট পদ্ধতি বেছে নিন\n"
            "  ২. পেমেন্ট করুন\n"
            "  ৩. TRX ID এখানে পাঠান\n"
            "  ৪. এডমিন যাচাই করে চালু করবে\n\n"
            "🔁 <b>একাধিকবার কেনা যাবে</b> — বট স্লট যোগ হবে!\n"
            "━━━━━━━━━━━━━━━━━━━━"
        ),
    },

    # ══════════════════════════════════
    #  RAM WARNING
    # ══════════════════════════════════
    'ram_warning': {
        'en': (
            "⚠️ <b>RAM Alert!</b>\n\n"
            "🤖 Bot: <b>{bot_name}</b>\n"
            "💾 Usage: <b>{used}MB / {limit}MB</b>\n\n"
            "Your bot is using too much RAM!\n"
            "💡 Recommended plan: <b>{recommended}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        ),
        'bn': (
            "⚠️ <b>র‍্যাম সতর্কতা!</b>\n\n"
            "🤖 বট: <b>{bot_name}</b>\n"
            "💾 ব্যবহার: <b>{used}MB / {limit}MB</b>\n\n"
            "আপনার বট অতিরিক্ত র‍্যাম ব্যবহার করছে!\n"
            "💡 প্রস্তাবিত প্ল্যান: <b>{recommended}</b>\n"
            "━━━━━━━━━━━━━━━━━━━━"
        ),
    },

    # ══════════════════════════════════
    #  BOT STATUS
    # ══════════════════════════════════
    'bot_started': {
        'en': (
            "✅ <b>Bot Started!</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "🤖 <b>{name}</b>\n"
            "📄 Entry: <code>{entry}</code>\n"
            "🔤 Type: {lang}\n"
            "🆔 PID: <code>{pid}</code>\n"
            "📊 Status: 🟢 Running"
        ),
        'bn': (
            "✅ <b>বট চালু হয়েছে!</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "🤖 <b>{name}</b>\n"
            "📄 এন্ট্রি: <code>{entry}</code>\n"
            "🔤 ধরন: {lang}\n"
            "🆔 PID: <code>{pid}</code>\n"
            "📊 অবস্থা: 🟢 চলছে"
        ),
    },
    'bot_stopped': {
        'en': "🛑 <b>{name}</b> has been stopped.",
        'bn': "🛑 <b>{name}</b> বন্ধ করা হয়েছে।",
    },
    'bot_crashed': {
        'en': (
            "❌ <b>Bot Crashed!</b>\n\n"
            "🤖 {name}\n"
            "📋 Error:\n<code>{error}</code>\n\n"
            "💡 If this is a server issue, admin has been notified."
        ),
        'bn': (
            "❌ <b>বট ক্র্যাশ করেছে!</b>\n\n"
            "🤖 {name}\n"
            "📋 ত্রুটি:\n<code>{error}</code>\n\n"
            "💡 সার্ভার সমস্যা হলে এডমিনকে জানানো হয়েছে।"
        ),
    },
    'sub_expired': {
        'en': (
            "⚠️ <b>Subscription Expired!</b>\n\n"
            "Your subscription has expired.\n"
            "Your bots have been stopped.\n\n"
            "Renew now to keep running 24/7!"
        ),
        'bn': (
            "⚠️ <b>সাবস্ক্রিপশন শেষ!</b>\n\n"
            "আপনার সাবস্ক্রিপশনের মেয়াদ শেষ হয়েছে।\n"
            "আপনার বটগুলো বন্ধ করা হয়েছে।\n\n"
            "২৪/৭ চালু রাখতে এখনই রিনিউ করুন!"
        ),
    },
    'sub_expiry_reminder': {
        'en': (
            "⏰ <b>Subscription Expiring Soon!</b>\n\n"
            "Your plan expires in <b>{days} days</b>.\n"
            "Renew now to avoid interruption!"
        ),
        'bn': (
            "⏰ <b>সাবস্ক্রিপশন শেষ হতে চলেছে!</b>\n\n"
            "আপনার প্ল্যান <b>{days} দিনে</b> শেষ হবে।\n"
            "বিরতি এড়াতে এখনই রিনিউ করুন!"
        ),
    },
    'free_limit': {
        'en': (
            "⏰ <b>Free Plan Limit Reached!</b>\n\n"
            "🤖 {name}\n"
            "Your free plan has expired (7 days).\n\n"
            "Upgrade to keep your bot running!"
        ),
        'bn': (
            "⏰ <b>ফ্রি প্ল্যানের সীমা শেষ!</b>\n\n"
            "🤖 {name}\n"
            "আপনার ফ্রি প্ল্যান শেষ হয়েছে (৭ দিন)।\n\n"
            "বট চালু রাখতে আপগ্রেড করুন!"
        ),
    },

    # ══════════════════════════════════
    #  WALLET / WITHDRAW
    # ══════════════════════════════════
    'wallet_info': {
        'en': (
            "💰 <b>Wallet</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "💵 Balance: <b>{balance} BDT</b>\n"
            "🎁 Referral Earned: <b>{ref_earn} BDT</b>\n"
            "💸 Min Withdraw: <b>50 BDT</b>"
        ),
        'bn': (
            "💰 <b>ওয়ালেট</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "💵 ব্যালেন্স: <b>{balance} টাকা</b>\n"
            "🎁 রেফারেল আয়: <b>{ref_earn} টাকা</b>\n"
            "💸 সর্বনিম্ন উত্তোলন: <b>৫০ টাকা</b>"
        ),
    },

    # ══════════════════════════════════
    #  BANNED
    # ══════════════════════════════════
    'banned': {
        'en': "🚫 <b>You are banned!</b>\n\nContact @arafat_codex1 to appeal.",
        'bn': "🚫 <b>আপনি ব্যান হয়েছেন!</b>\n\nআপিল করতে @arafat_codex1-এ যোগাযোগ করুন।",
    },

    # ══════════════════════════════════
    #  AD SYSTEM
    # ══════════════════════════════════
    'ad_info': {
        'en': (
            "📺 <b>Watch Ad for Free Time!</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "Watch a short ad and get <b>+24 hours</b> free!\n\n"
            "👇 Click the button below:"
        ),
        'bn': (
            "📺 <b>বিজ্ঞাপন দেখে ফ্রি সময় পান!</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "একটি ছোট বিজ্ঞাপন দেখুন এবং <b>+২৪ ঘন্টা</b> ফ্রি পান!\n\n"
            "👇 নিচের বোতামে ক্লিক করুন:"
        ),
    },
    'ad_success': {
        'en': "✅ <b>Ad watched! +24 hours added to your plan.</b>",
        'bn': "✅ <b>বিজ্ঞাপন দেখা হয়েছে! আপনার প্ল্যানে +২৪ ঘন্টা যোগ হয়েছে।</b>",
    },

    # ══════════════════════════════════
    #  FORCE SUBSCRIBE
    # ══════════════════════════════════
    'force_sub': {
        'en': (
            "📢 <b>Join Required!</b>\n\n"
            "Please join the following channel(s) to use this bot:\n\n"
            "{channels}\n"
            "After joining, press ✅ Verify."
        ),
        'bn': (
            "📢 <b>যোগ দেওয়া আবশ্যক!</b>\n\n"
            "বট ব্যবহার করতে এই চ্যানেলে যোগ দিন:\n\n"
            "{channels}\n"
            "যোগ দেওয়ার পর ✅ যাচাই করুন চাপুন।"
        ),
    },

    # ══════════════════════════════════
    #  HELP
    # ══════════════════════════════════
    'help_main': {
        'en': (
            "❓ <b>Help Center</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "Choose a topic below:"
        ),
        'bn': (
            "❓ <b>সাহায্য কেন্দ্র</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "নিচে একটি বিষয় বেছে নিন:"
        ),
    },
    'help_deploy': {
        'en': (
            "📤 <b>How to Deploy a Bot</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "1️⃣ Prepare your bot file (.py / .js / .zip)\n"
            "2️⃣ Send the file to this bot\n"
            "3️⃣ Entry file is auto-detected\n"
            "4️⃣ Packages are auto-installed\n"
            "5️⃣ Press ▶️ Start\n\n"
            "✅ Supported: Python, Node.js\n"
            "✅ ZIP: All-in-one project"
        ),
        'bn': (
            "📤 <b>বট ডিপ্লয় করবেন কীভাবে</b>\n"
            "━━━━━━━━━━━━━━━━━━━━\n\n"
            "১️⃣ বট ফাইল তৈরি করুন (.py / .js / .zip)\n"
            "২️⃣ এই বটে ফাইল পাঠান\n"
            "৩️⃣ এন্ট্রি ফাইল স্বয়ংক্রিয় সনাক্ত হবে\n"
            "৪️⃣ প্যাকেজ স্বয়ংক্রিয় ইনস্টল হবে\n"
            "৫️⃣ ▶️ স্টার্ট চাপুন\n\n"
            "✅ সমর্থিত: পাইথন, নোড.জেএস\n"
            "✅ ZIP: সম্পূর্ণ প্রজেক্ট"
        ),
    },
}


def t(key: str, lang: str = 'en', **kwargs) -> str:
    """Get translated text."""
    entry = TEXTS.get(key, {})
    if not entry:
        return key
    text = entry.get(lang) or entry.get('en') or key
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, ValueError):
            pass
    return text
