"""
╔══════════════════════════════════════════════════════════╗
║         ☁️  ARAFAT HOSTING CLOUD — Config v2.1 (Fixed)     ║
╚══════════════════════════════════════════════════════════╝

FIX: Credentials now loaded from .env file first, then env vars,
     then hardcoded defaults. Never commit real tokens!
"""

import os

# FIX: Load .env file if it exists (python-dotenv optional)
try:
    from dotenv import load_dotenv
    _env = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(_env):
        load_dotenv(_env)
except ImportError:
    pass


def _get(key, default=''):
    return os.environ.get(key) or default


# ═══════════════════════════════════
#  BOT
# ═══════════════════════════════════
TOKEN        = _get('BOT_TOKEN',    'PASTE_YOUR_BOT_TOKEN_HERE')
BOT_USERNAME = _get('BOT_USERNAME', 'your_bot_username')

# ═══════════════════════════════════
#  OWNER
# ═══════════════════════════════════
OWNER_ID      = int(_get('OWNER_ID', '7705767559'))
ADMIN_IDS     = [OWNER_ID]
DEV_USERNAME  = '@arafat_codex1'
UPDATE_CHANNEL = 'https://t.me/arafat_updates'

# ═══════════════════════════════════
#  DATABASE — Use .env, never hardcode!
# ═══════════════════════════════════
MONGO_URL        = _get('MONGO_URL',        '')
MONGO_URL_BACKUP = _get('MONGO_URL_BACKUP', '')
DB_NAME          = 'arafat_hosting_cloud'
USE_MONGO        = bool(MONGO_URL)     # Auto: use Mongo if URL set, else SQLite

# ═══════════════════════════════════
#  BACKUP CHANNEL
# ═══════════════════════════════════
BACKUP_CHANNEL_ID = int(_get('BACKUP_CHANNEL_ID', '0'))

# ═══════════════════════════════════
#  BRANDING
# ═══════════════════════════════════
BRAND     = "☁️ Arafat Hosting Cloud"
BRAND_VER = "v2.1"
BRAND_SEP = "━━━━━━━━━━━━━━━━━━━━"

# ═══════════════════════════════════
#  DIRECTORIES
# ═══════════════════════════════════
BASE_DIR   = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, 'uploads')
LOGS_DIR   = os.path.join(BASE_DIR, 'logs')

for _d in [UPLOAD_DIR, LOGS_DIR]:
    os.makedirs(_d, exist_ok=True)

# ═══════════════════════════════════
#  PLANS (Stackable)
# ═══════════════════════════════════
# ═══════════════════════════════════
#  PLAN LIMITS
#  per_bot_ram: প্রতিটা bot এই RAM পাবে (ভাগ হবে না)
#  bots: কতটা bot একসাথে চলবে (1-10)
#  ram: total system RAM = bots × per_bot_ram
# ═══════════════════════════════════
PLAN_LIMITS = {
    'free':      {'name': '🆓 Free',      'bots': 1,  'per_bot_ram': 128,  'price_bdt': 0,    'price_usdt': 0,    'days': 7,   'auto_restart': False},
    'starter':   {'name': '🟢 Starter',   'bots': 2,  'per_bot_ram': 256,  'price_bdt': 99,   'price_usdt': 1,    'days': 30,  'auto_restart': True},
    'basic':     {'name': '⭐ Basic',      'bots': 3,  'per_bot_ram': 384,  'price_bdt': 149,  'price_usdt': 1.5,  'days': 30,  'auto_restart': True},
    'standard':  {'name': '🔵 Standard',  'bots': 4,  'per_bot_ram': 512,  'price_bdt': 199,  'price_usdt': 2,    'days': 30,  'auto_restart': True},
    'advanced':  {'name': '🟣 Advanced',  'bots': 5,  'per_bot_ram': 768,  'price_bdt': 249,  'price_usdt': 2.5,  'days': 30,  'auto_restart': True},
    'pro':       {'name': '💎 Pro',        'bots': 6,  'per_bot_ram': 1024, 'price_bdt': 349,  'price_usdt': 3.5,  'days': 30,  'auto_restart': True},
    'ultra':     {'name': '🔥 Ultra',      'bots': 7,  'per_bot_ram': 1536, 'price_bdt': 449,  'price_usdt': 4.5,  'days': 30,  'auto_restart': True},
    'premium':   {'name': '👑 Premium',    'bots': 8,  'per_bot_ram': 2048, 'price_bdt': 549,  'price_usdt': 5.5,  'days': 30,  'auto_restart': True},
    'elite':     {'name': '🏆 Elite',      'bots': 9,  'per_bot_ram': 3072, 'price_bdt': 699,  'price_usdt': 7,    'days': 30,  'auto_restart': True},
    'master':    {'name': '🌟 Master',     'bots': 10, 'per_bot_ram': 4096, 'price_bdt': 849,  'price_usdt': 8.5,  'days': 30,  'auto_restart': True},
    'unlimited': {'name': '♾️ Unlimited',  'bots': -1, 'per_bot_ram': 4096, 'price_bdt': 1499, 'price_usdt': 15,   'days': 30,  'auto_restart': True},
}
# Auto-inject ram = bots × per_bot_ram
for _pk, _pv in PLAN_LIMITS.items():
    if _pv['bots'] == -1:
        _pv['ram'] = _pv['per_bot_ram']   # unlimited: just track per_bot_ram
    else:
        _pv['ram'] = _pv['bots'] * _pv['per_bot_ram']

# ═══════════════════════════════════
#  PAYMENT METHODS
# ═══════════════════════════════════
PAYMENT_METHODS = {
    'bkash':   {'name': 'bKash',        'number': _get('BKASH_NUM',   '01304057101'), 'currency': 'BDT',  'icon': '🟪'},
    'nagad':   {'name': 'Nagad',        'number': _get('NAGAD_NUM',   '❌'), 'currency': 'BDT',  'icon': '🟧'},
    'rocket':  {'name': 'Rocket',       'number': _get('ROCKET_NUM',  '❌'), 'currency': 'BDT',  'icon': '🟦'},
    'upay':    {'name': 'Upay',         'number': _get('UPAY_NUM',    '01304057101'), 'currency': 'BDT',  'icon': '🟩'},
    'binance': {'name': 'Binance Pay',  'number': _get('BINANCE_ID',  'ID: 75XXXXX'), 'currency': 'USDT','icon': '🟡'},
    'usdt':    {'name': 'USDT (TRC20)', 'number': _get('USDT_ADDR',   'Contact Admin'), 'currency': 'USDT','icon': '💵'},
}

# ═══════════════════════════════════
#  FREE PLAN
# ═══════════════════════════════════
FREE_PLAN_DAYS     = 7
FREE_BOT_MAX_HOURS = 24

# ═══════════════════════════════════
#  AD SYSTEM
# ═══════════════════════════════════
AD_WATCH_HOURS  = 24
AD_WATCH_URL    = _get('AD_WATCH_URL', 'https://apon-hosting.com/watch-ad')
AD_SECRET       = _get('AD_SECRET', 'change_this_secret_key_in_env')
AD_SERVER_URL   = _get('AD_SERVER_URL', 'https://apon-hosting.com/ad')  # VPS Flask server URL

# ═══════════════════════════════════
#  REFERRAL
# ═══════════════════════════════════
REF_BONUS_DAYS = 3
REF_COMMISSION = 20

# ═══════════════════════════════════
#  WITHDRAW
# ═══════════════════════════════════
MIN_WITHDRAW = 50

# ═══════════════════════════════════
#  PERFORMANCE
# ═══════════════════════════════════
HEALTH_CHECK_INTERVAL = 300   # seconds

# ═══════════════════════════════════
#  DAILY REPORT
# ═══════════════════════════════════
DAILY_REPORT_HOUR   = 0
DAILY_REPORT_MINUTE = 0

# ═══════════════════════════════════
#  MODULE AUTO-DETECT MAP
# ═══════════════════════════════════
MODULES_MAP = {
    'telebot': 'pytelegrambotapi', 'telegram': 'python-telegram-bot',
    'pyrogram': 'pyrogram', 'telethon': 'telethon', 'aiogram': 'aiogram',
    'PIL': 'Pillow', 'cv2': 'opencv-python', 'sklearn': 'scikit-learn',
    'bs4': 'beautifulsoup4', 'dotenv': 'python-dotenv', 'yaml': 'pyyaml',
    'aiohttp': 'aiohttp', 'numpy': 'numpy', 'pandas': 'pandas',
    'requests': 'requests', 'flask': 'flask', 'fastapi': 'fastapi',
    'motor': 'motor', 'pymongo': 'pymongo', 'httpx': 'httpx',
    'discord': 'discord.py', 'tweepy': 'tweepy', 'instagrapi': 'instagrapi',
    'selenium': 'selenium', 'scrapy': 'scrapy', 'celery': 'celery',
    'redis': 'redis', 'sqlalchemy': 'sqlalchemy', 'django': 'django',
    'starlette': 'starlette', 'uvicorn': 'uvicorn', 'pydantic': 'pydantic',
}

LANGUAGES = {'en': '🇬🇧 English', 'bn': '🇧🇩 বাংলা'}
