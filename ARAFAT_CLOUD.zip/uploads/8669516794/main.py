
#!/usr/bin/env python3
"""
Telegram Backup Bot – Self‑contained

* No external files (requirements.txt, .env, …) are required.
* The script will automatically install the *requests* package if it is missing.
* Run it from inside the folder you want to back‑up, or give an explicit --source path.
* Edit the BOT_TOKEN and CHAT_ID variables at the top before first run.

Usage
-----
  python main.py            # works if you are in the folder to back‑up
  python main.py --source /opt/render/project/src   # explicit path
"""

# --------------------------------------------------------------------------- #
#  AUTO‑INSTALL DEPENDENCY
# --------------------------------------------------------------------------- #
import importlib.util
import subprocess
import sys
import os
import pathlib
import datetime
import logging
import tempfile
import zipfile
from pathlib import Path
from typing import Iterable, Optional

# Try to import requests – install it if it is missing
if importlib.util.find_spec("requests") is None:
    print("requests not found – installing now…")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "requests"])
# Now import it
import requests  # type: ignore

# --------------------------------------------------------------------------- #
#  USER SETTINGS – EDIT THESE
# --------------------------------------------------------------------------- #
BOT_TOKEN: str = "8645772629:AAFypE9FO7CLMfuyRFw8QMU-RGSSsFqW8Hw"          # ← replace with your bot token
CHAT_ID: str = "-1003973626230"                      # ← replace with your chat/group id

# --------------------------------------------------------------------------- #
#  CONFIGURATION
# --------------------------------------------------------------------------- #
EXCLUDE_DIRS = {
    "__pycache__",
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "env",
    "build",
    "dist",
    ".idea",
    ".vscode",
    ".pytest_cache",
    ".cache",
    ".DS_Store",
    "tmp",
    "temp",
}
LOG_LEVEL = logging.INFO

# --------------------------------------------------------------------------- #
#  HELPER FUNCTIONS
# --------------------------------------------------------------------------- #
def setup_logging() -> None:
    logging.basicConfig(
        level=LOG_LEVEL,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )

def find_project_root(
    start: Path,
    markers: Iterable[str] = ("package.json", ".git", "requirements.txt"),
) -> Optional[Path]:
    """Return the nearest ancestor containing one of the *markers*."""
    p = start.resolve()
    while True:
        if any((p / m).exists() for m in markers):
            logging.debug(f"Found project root: {p}")
            return p
        if p.parent == p:  # root reached
            logging.debug("No project marker found up to filesystem root.")
            return None
        p = p.parent

def is_excluded(path: Path) -> bool:
    """Return True if *path* should be excluded from the zip."""
    return any(part in EXCLUDE_DIRS for part in path.parts)

def create_zip(source: Path, archive_name: str) -> Path:
    """Create a zip of *source*, excluding unwanted directories."""
    temp_dir = Path(tempfile.gettempdir())
    zip_path = temp_dir / archive_name
    logging.info(f"Creating zip: {zip_path}")

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source):
            root_path = Path(root)

            # prune excluded dirs in‑place
            dirs[:] = [d for d in dirs if not is_excluded(root_path / d)]

            for file in files:
                file_path = root_path / file
                if is_excluded(file_path):
                    continue
                arcname = file_path.relative_to(source)
                zf.write(file_path, arcname)
                logging.debug(f"Added {file_path} as {arcname}")

    logging.info(f"Zip ready: {zip_path}")
    return zip_path

def send_file_to_telegram(file_path: Path) -> None:
    """Send the zip file to Telegram."""
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendDocument"
    with open(file_path, "rb") as fp:
        files = {"document": (file_path.name, fp)}
        data = {
            "chat_id": CHAT_ID,
            "caption": f"Backup taken on {datetime.datetime.utcnow().isoformat()}Z",
        }
        resp = requests.post(url, files=files, data=data)

    if resp.status_code != 200:
        logging.error(f"Telegram error {resp.status_code}: {resp.text}")
        resp.raise_for_status()
    logging.info("Backup sent to Telegram successfully.")

# --------------------------------------------------------------------------- #
#  MAIN
# --------------------------------------------------------------------------- #
def main() -> None:
    setup_logging()

    # -------------------------------
    # Resolve source directory
    # -------------------------------
    if len(sys.argv) >= 2 and sys.argv[1] != "--source":
        # Assume first non‑flag argument is the path
        source_path = Path(sys.argv[1]).expanduser().resolve()
        if not source_path.is_dir():
            logging.error(f"Provided path is not a directory: {source_path}")
            sys.exit(1)
    else:
        # No explicit path – try to find project root from cwd
        cwd = Path.cwd()
        logging.info(f"Current working directory: {cwd}")
        source_path = find_project_root(cwd)
        if source_path is None:
            logging.error(
                "Could not determine the directory to back‑up.\n"
                "Either run this script inside the folder you want to back‑up\n"
                "or provide an explicit path with: python main.py /path/to/dir"
            )
            sys.exit(1)

    logging.info(f"Backing up: {source_path}")

    # -------------------------------
    # Create zip
    # -------------------------------
    timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
    archive_name = f"backup_{timestamp}.zip"
    zip_file = create_zip(source_path, archive_name)

    # -------------------------------
    # Send to Telegram
    # -------------------------------
    send_file_to_telegram(zip_file)

    # -------------------------------
    # Clean up temp file
    # -------------------------------
    try:
        zip_file.unlink()
        logging.debug(f"Deleted temporary archive {zip_file}")
    except Exception as e:
        logging.warning(f"Could not delete temp file {zip_file}: {e}")

if __name__ == "__main__":
    main()