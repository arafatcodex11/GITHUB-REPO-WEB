#!/bin/bash
# ╔══════════════════════════════════════════════════════════╗
# ║        ☁️  ARAFAT HOSTING CLOUD v2.0 — VPS Startup        ║
# ╚══════════════════════════════════════════════════════════╝

DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$DIR/logs/bot.log"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ☁️  ARAFAT HOSTING CLOUD v2.0"
echo "  📁 $DIR"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Kill old instances
pkill -f "python3.*main.py" 2>/dev/null || true
sleep 1

# Create directories
mkdir -p "$DIR/logs" "$DIR/uploads"

# Check if running inside tmux already
if [ -n "$TMUX" ]; then
    echo "🤖 Starting Telegram Bot..."
    cd "$DIR" && exec python3 -u main.py
else
    # Start in tmux background automatically
    echo "🚀 Starting in background (tmux)..."
    tmux kill-session -t ahc 2>/dev/null || true
    sleep 1
    tmux new-session -d -s ahc -c "$DIR" "python3 -u main.py 2>&1 | tee -a $LOG"
    sleep 3
    if tmux has-session -t ahc 2>/dev/null; then
        echo "✅ Bot is running in background!"
        echo "📋 View logs: tmux attach -t ahc"
        echo "📋 Or: tail -f $LOG"
    else
        echo "❌ Something went wrong. Check: tail -f $LOG"
    fi
fi
