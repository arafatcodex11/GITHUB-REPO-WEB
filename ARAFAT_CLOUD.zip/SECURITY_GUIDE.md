# ☁️ ARAFAT HOSTING CLOUD — Security Guide & Update Manual

> Version: 3.0 | Updated: 2026-05-12

---

## 🔐 Security System Overview

এই system ৪টি layer এ কাজ করে:

```
Layer 1 → Scanner      (upload এর সময়)
Layer 2 → File Lock    (bot start এর সময়)
Layer 3 → VPS Guard    (সব সময় background এ)
Layer 4 → Alert System (সমস্যা হলে admin কে notify)
```

---

## 📁 File Structure

```
security/
├── scanner.py      ← Upload scan (malicious code detect)
├── file_lock.py    ← Bot file ownership lock (চুরি হলে চলবে না)
├── vps_guard.py    ← Runtime process monitor (attack detect)
└── alerter.py      ← Admin Telegram notification
```

---

## 🛡️ কী কী protect করে

| Attack Type | কোন File | কীভাবে Block |
|---|---|---|
| Reverse Shell | scanner.py | Upload block + quarantine |
| Bot Hijacking | scanner.py | Upload block |
| Token Theft | scanner.py | Upload block |
| File Theft/Clone | file_lock.py | অন্য VPS এ start হবে না |
| Crypto Miner | vps_guard.py | Process auto-kill |
| ZIP Bomb | scanner.py | Extract এর আগে block |
| Fork Bomb | scanner.py + vps_guard.py | Detect + kill |
| rm -rf / | scanner.py | Upload block |
| Remote Command | vps_guard.py | Process kill + alert |

---

## 🔧 HOW TO UPDATE — নতুন Attack Pattern যোগ করা

### নতুন Malicious Pattern যোগ করতে চাইলে:

`security/scanner.py` খোলো।

**Critical (সাথে সাথে block করবে):**
```python
CRITICAL_PATTERNS = [
    # এখানে নতুন pattern যোগ করো:
    (r'your_regex_here',  'Description of attack'),
    ...
]
```

**Warning (alert দেবে কিন্তু block করবে না):**
```python
WARNING_PATTERNS = [
    (r'your_regex_here',  'Description'),
    ...
]
```

**Shell file (.sh/.bash) এর জন্য:**
```python
DANGEROUS_SHELL_PATTERNS = [
    (r'your_regex_here',  'Description'),
    ...
]
```

---

## 🔑 File Lock Update করতে

`security/file_lock.py` এ:

```python
# অবশ্যই এটা পরিবর্তন করো! Default রেখো না।
FINGERPRINT_KEY = b'ArafatHostingCloud-Secret-2026'
#                   ↑ এখানে নিজের secret key দাও
```

---

## 🖥️ VPS Guard — নতুন process pattern যোগ করতে

`security/vps_guard.py` এ:

```python
SUSPICIOUS_CMDLINE = [
    # নতুন attack command pattern:
    (r'your_pattern',  'Description'),
    ...
]

# False positive এড়াতে safe process এখানে যোগ করো:
SAFE_PROCESS_NAMES = {
    'python3', 'node', ...
}

# কত সেকেন্ড পরপর check (default: 30s)
CHECK_INTERVAL_SEC = 30
```

---

## 📊 Admin Commands (Telegram এ)

| Command | কাজ |
|---|---|
| Admin Panel → Security | Pending quarantine list দেখো |
| ✅ Approve | Block করা file approve করো |
| 🗑️ Reject | Block করা file delete করো |

---

## 🚨 Alert Types

Admin এর Telegram এ যেসব alert আসতে পারে:

- `🚨 Security Alert` — Malicious file upload
- `🚨 Suspicious Process` — VPS এ attack process detect
- `🔴 BLOCKED` — File quarantine করা হয়েছে
- `🟡 WARNED` — সন্দেহজনক কিন্তু block না
- `🔥 CPU Abuse` — কেউ CPU 85%+ ব্যবহার করছে
- `💾 RAM Critical` — RAM 90%+ হয়ে গেছে
- `💥 Bot Crash` — User এর bot crash করেছে

---

## 📋 CHANGELOG

### v3.0 (2026-05-12)
- ✅ 45+ নতুন malicious pattern যোগ
- ✅ ZIP Bomb protection যোগ
- ✅ VPS Guard (runtime process monitor) যোগ
- ✅ File Lock system (anti-theft) যোগ
- ✅ Directory fingerprint system
- ✅ Shell file (.sh) scan যোগ
- ✅ BLOCKED_EXTENSIONS (.exe, .bat, .dll etc.) যোগ
- ✅ User message বাংলা/ইংলিশ উভয়ে

### v2.0 (2026-04-01)
- ✅ Bot hijack pattern যোগ
- ✅ Quarantine system
- ✅ Admin approve/reject

### v1.0 (2026-01-01)
- ✅ Initial security scanner
- ✅ Admin alert system

---

## ⚠️ Important Notes

1. **`FINGERPRINT_KEY`** অবশ্যই পরিবর্তন করো — default রাখলে security কমে যাবে
2. **False positive** হলে `WARNING_PATTERNS` থেকে সেই pattern সরাও বা `SAFE_PROCESS_NAMES` এ process যোগ করো
3. **VPSGuard** `psutil` লাগে — `pip install psutil` দিয়ে install করো
4. Lock file (`.ahc_lock`) কখনো manually delete করো না — bot চলবে না
