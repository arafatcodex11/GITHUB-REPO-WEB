"""
╔══════════════════════════════════════════════════════════════╗
║       ☁️  ARAFAT HOSTING CLOUD — VPS Guard v1.0                ║
║       Runtime Process Monitor | Attack Detector              ║
╚══════════════════════════════════════════════════════════════╝

▸ চলমান bot process এ সন্দেহজনক network/shell activity detect করে
▸ Crypto miner, reverse shell process auto-kill করে
▸ Admin কে real-time alert পাঠায়
▸ System resource abuse (CPU/RAM) monitor করে

HOW TO USE:
    from security.vps_guard import VPSGuard
    guard = VPSGuard(bot_instance, owner_id, db_instance)
    guard.start()   # background এ চলবে

HOW TO UPDATE:
    SUSPICIOUS_CMDLINE  → নতুন attack signature যোগ করো
    SAFE_PROCESS_NAMES  → False positive এড়াতে এখানে যোগ করো
    CHECK_INTERVAL_SEC  → কত সেকেন্ড পরপর check করবে

CHANGELOG:
    v1.0 (2026-05-12) — Initial release: process scan, CPU abuse, net connection monitor
"""

import os, re, time, logging, threading, subprocess
from datetime import datetime
from typing import Optional

logger = logging.getLogger('AHC.vpsguard')

# ══════════════════════════════════════════════════════════════
#  সন্দেহজনক process command patterns
# ══════════════════════════════════════════════════════════════
SUSPICIOUS_CMDLINE = [
    (r'nc\s+-e\s+/bin/|ncat\s+-e',              'Netcat reverse shell'),
    (r'/dev/tcp/\d+\.\d+\.\d+',                 'Bash TCP reverse shell'),
    (r'xmrig|cpuminer|minerd',                  'Crypto miner'),
    (r'stratum\+tcp://',                         'Mining pool connection'),
    (r'bash\s+-i\s+>&',                          'Interactive bash reverse shell'),
    (r'python.*-c.*socket.*connect',             'Python reverse shell'),
    (r'curl.*\|\s*bash|wget.*\|\s*bash',         'Remote code via curl/wget'),
    (r'rm\s+-rf\s+/\s',                          'Recursive delete from root'),
    (r'chmod\s+-R\s+777\s+/',                    'Mass chmod 777'),
    (r'iptables\s+-F|ufw\s+disable',             'Firewall disable'),
    (r'useradd|adduser.*--no-create-home',       'Suspicious user creation'),
    (r'crontab.*</dev/null|crontab.*>/dev/null', 'Cron manipulation'),
    (r'dd\s+if=/dev/zero',                       'Disk fill attack'),
]

# এই process গুলো safe — false positive এড়াতে
SAFE_PROCESS_NAMES = {
    'python3', 'python', 'node', 'npm', 'pip', 'pip3',
    'bash', 'sh', 'cat', 'ls', 'ps', 'grep', 'top',
    'systemd', 'journald', 'sshd', 'nginx', 'apache2',
    'mongo', 'mongod', 'redis-server', 'postgres',
}

# CPU এর চেয়ে বেশি ব্যবহার হলে সন্দেহজনক (%)
CPU_ABUSE_THRESHOLD  = 85.0
RAM_ABUSE_THRESHOLD  = 90.0
CPU_ABUSE_DURATION   = 120    # এই সেকেন্ড ধরে বেশি হলে alert

# কত সেকেন্ড পরপর check
CHECK_INTERVAL_SEC = 30


class VPSGuard:
    """
    Background thread এ VPS monitor করে।
    সন্দেহজনক activity পেলে admin alert + auto-kill।
    """

    def __init__(self, bot_instance, owner_id: int, db_instance=None):
        self.bot      = bot_instance
        self.owner_id = owner_id
        self.db       = db_instance
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._cpu_high_since: float = 0.0
        self._killed_pids: set = set()

    # ──────────────────────────────────────────────
    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._loop, daemon=True, name='VPSGuard')
        self._thread.start()
        logger.info("VPSGuard started")

    def stop(self):
        self._running = False

    # ──────────────────────────────────────────────
    def _loop(self):
        while self._running:
            try:
                self._check_processes()
                self._check_system_resources()
            except Exception as e:
                logger.error(f"VPSGuard loop error: {e}")
            time.sleep(CHECK_INTERVAL_SEC)

    # ──────────────────────────────────────────────
    def _check_processes(self):
        """সব running process এর cmdline check করো।"""
        try:
            out = subprocess.check_output(
                ['ps', 'aux', '--no-header'],
                stderr=subprocess.DEVNULL, timeout=10
            ).decode('utf-8', errors='ignore')
        except Exception:
            return

        for line in out.splitlines():
            parts = line.split(None, 10)
            if len(parts) < 11:
                continue
            pid     = parts[1]
            cmdline = parts[10]

            # Safe processes skip
            cmd0 = cmdline.split()[0].split('/')[-1] if cmdline.split() else ''
            if cmd0 in SAFE_PROCESS_NAMES and len(cmdline) < 60:
                continue

            for pattern, desc in SUSPICIOUS_CMDLINE:
                if re.search(pattern, cmdline, re.IGNORECASE):
                    self._handle_suspicious(pid, cmdline, desc)
                    break

    # ──────────────────────────────────────────────
    def _check_system_resources(self):
        """CPU/RAM abuse detect করো।"""
        try:
            import psutil
            cpu = psutil.cpu_percent(interval=2)
            ram = psutil.virtual_memory().percent

            if cpu > CPU_ABUSE_THRESHOLD:
                if self._cpu_high_since == 0:
                    self._cpu_high_since = time.time()
                elif time.time() - self._cpu_high_since > CPU_ABUSE_DURATION:
                    self._alert(
                        f"🔥 <b>CPU Abuse Alert</b>\n"
                        f"CPU: <b>{cpu:.1f}%</b> — {CPU_ABUSE_DURATION}s ধরে উচ্চ\n"
                        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
                    )
                    self._cpu_high_since = time.time()  # re-arm 2 min later
            else:
                self._cpu_high_since = 0.0

            if ram > RAM_ABUSE_THRESHOLD:
                self._alert(
                    f"💾 <b>RAM Critical</b>\n"
                    f"RAM: <b>{ram:.1f}%</b> used\n"
                    f"⏰ {datetime.now().strftime('%H:%M:%S')}"
                )
        except ImportError:
            pass   # psutil না থাকলে skip
        except Exception as e:
            logger.warning(f"resource check error: {e}")

    # ──────────────────────────────────────────────
    def _handle_suspicious(self, pid: str, cmdline: str, reason: str):
        """Suspicious process auto-kill + admin alert।"""
        if pid in self._killed_pids:
            return  # already killed

        logger.warning(f"Suspicious process PID={pid}: {reason} | cmd={cmdline[:100]}")
        self._killed_pids.add(pid)

        # Auto-kill
        try:
            os.kill(int(pid), 9)
            killed_txt = f"✅ PID {pid} auto-killed"
        except Exception as e:
            killed_txt = f"⚠️ Kill failed: {e}"

        self._alert(
            f"🚨 <b>Suspicious Process Detected</b>\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"📌 Reason: {reason}\n"
            f"🔢 PID: <code>{pid}</code>\n"
            f"💻 CMD: <code>{cmdline[:120]}</code>\n"
            f"{killed_txt}\n"
            f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )

    # ──────────────────────────────────────────────
    def _alert(self, text: str):
        """Admin কে Telegram message পাঠাও।"""
        if not self.bot or not self.owner_id:
            return
        try:
            self.bot.send_message(self.owner_id, text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"VPSGuard alert failed: {e}")


# ══════════════════════════════════════════════════════════════
#  STANDALONE — direct চালানো যাবে test এর জন্য
# ══════════════════════════════════════════════════════════════
if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)

    class _FakeBot:
        def send_message(self, cid, text, **kw):
            print(f"\n[ALERT → {cid}]\n{text}\n")

    guard = VPSGuard(_FakeBot(), owner_id=123456789)
    print("VPSGuard test mode — scanning once...")
    guard._check_processes()
    guard._check_system_resources()
    print("Done.")
