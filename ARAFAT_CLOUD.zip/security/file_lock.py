"""
╔══════════════════════════════════════════════════════════════╗
║      ☁️  ARAFAT HOSTING CLOUD — File Lock System v1.0          ║
║      Anti-Steal | Owner Bind | VPS Fingerprint Lock          ║
╚══════════════════════════════════════════════════════════════╝

▸ প্রতিটি hosted bot file এ owner Telegram ID bind করে
▸ চুরি হলে অন্য VPS এ run করা যাবে না
▸ VPS hardware fingerprint verify করে
▸ Mismatch হলে auto-shutdown করে

HOW IT WORKS:
    1. Bot upload হলে  → create_lock(uid, bot_dir) call হয়
    2. Bot start হলে  → verify_lock(uid, bot_dir) call হয়
    3. Mismatch হলে   → LockViolation raise হয় → bot start হয় না

HOW TO UPDATE:
    LOCK_FILENAME   → lock file এর নাম পরিবর্তন করতে পারো
    FINGERPRINT_KEY → VPS fingerprint এর salt (অবশ্যই পরিবর্তন করো!)
    _get_vps_fingerprint() → নতুন hardware info যোগ করতে পারো

CHANGELOG:
    v1.0 (2026-05-12) — Initial release: owner bind, VPS fingerprint, tamper detection
"""

import os, json, hashlib, hmac, time, logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger('AHC.filelock')

# ══════════════════════════════════════════════════════════════
#  CONFIG — পরিবর্তন করতে পারো
# ══════════════════════════════════════════════════════════════
LOCK_FILENAME   = '.ahc_lock'          # bot folder এ এই নামে save হবে
FINGERPRINT_KEY = b'ArafatHostingCloud-Secret-2026'   # ← পরিবর্তন করো!
LOCK_VERSION    = 1


class LockViolation(Exception):
    """File lock mismatch হলে এই exception raise হয়।"""
    pass


# ══════════════════════════════════════════════════════════════
#  VPS FINGERPRINT
# ══════════════════════════════════════════════════════════════
def _get_vps_fingerprint() -> str:
    """
    VPS এর unique fingerprint বানাও।
    MAC address, hostname, machine-id দিয়ে তৈরি।
    অন্য VPS এ আলাদা হবে।
    """
    parts = []

    # Hostname
    try:
        import socket
        parts.append(socket.gethostname())
    except Exception:
        pass

    # Machine ID (Linux)
    for mid_path in ('/etc/machine-id', '/var/lib/dbus/machine-id'):
        try:
            with open(mid_path) as f:
                parts.append(f.read().strip())
            break
        except Exception:
            pass

    # MAC address
    try:
        import uuid
        mac = hex(uuid.getnode())
        parts.append(mac)
    except Exception:
        pass

    # CPU info (fallback)
    try:
        with open('/proc/cpuinfo') as f:
            for line in f:
                if 'model name' in line or 'Serial' in line:
                    parts.append(line.strip())
                    break
    except Exception:
        pass

    raw = '|'.join(parts) or 'unknown-vps'
    return hmac.new(FINGERPRINT_KEY, raw.encode(), hashlib.sha256).hexdigest()


# ══════════════════════════════════════════════════════════════
#  LOCK CREATE
# ══════════════════════════════════════════════════════════════
def create_lock(uid: int, bot_dir: str, bot_name: str = '') -> bool:
    """
    Bot upload সম্পন্ন হলে lock file তৈরি করো।

    Parameters:
        uid      — owner এর Telegram ID
        bot_dir  — bot এর directory path
        bot_name — bot এর নাম (optional)

    Returns True on success।
    """
    try:
        vps_fp = _get_vps_fingerprint()
        lock_data = {
            'version':     LOCK_VERSION,
            'owner_uid':   uid,
            'bot_name':    bot_name,
            'vps_fp':      vps_fp,
            'created_at':  datetime.utcnow().isoformat(),
            'locked':      True,
        }
        # Signature — data tamper করলে detect হবে
        payload  = json.dumps(lock_data, sort_keys=True).encode()
        sig      = hmac.new(FINGERPRINT_KEY, payload, hashlib.sha256).hexdigest()
        lock_data['sig'] = sig

        lock_path = os.path.join(bot_dir, LOCK_FILENAME)
        with open(lock_path, 'w') as f:
            json.dump(lock_data, f, indent=2)

        # Lock file hidden রাখো (Unix)
        try:
            os.chmod(lock_path, 0o400)   # read-only
        except Exception:
            pass

        logger.info(f"Lock created: uid={uid} bot={bot_name} dir={bot_dir}")
        return True

    except Exception as e:
        logger.error(f"create_lock error: {e}")
        return False


# ══════════════════════════════════════════════════════════════
#  LOCK VERIFY
# ══════════════════════════════════════════════════════════════
def verify_lock(uid: int, bot_dir: str) -> None:
    """
    Bot start করার আগে lock verify করো।

    Raises LockViolation যদি:
      - Lock file না থাকে (first-time upload এ create হয়)
      - Owner mismatch
      - VPS fingerprint mismatch (অন্য VPS এ run করলে)
      - Signature tamper হলে
    """
    lock_path = os.path.join(bot_dir, LOCK_FILENAME)

    # Lock file নেই — auto create (backward compatibility)
    if not os.path.exists(lock_path):
        logger.warning(f"No lock file found for uid={uid} dir={bot_dir} — creating")
        create_lock(uid, bot_dir)
        return

    try:
        with open(lock_path, 'r') as f:
            lock_data = json.load(f)
    except Exception as e:
        raise LockViolation(f"Lock file corrupted: {e}")

    # Signature verify
    sig_stored = lock_data.pop('sig', '')
    payload    = json.dumps(lock_data, sort_keys=True).encode()
    sig_calc   = hmac.new(FINGERPRINT_KEY, payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig_stored, sig_calc):
        raise LockViolation("Lock signature tampered — possible file theft!")

    # Owner verify
    if int(lock_data.get('owner_uid', -1)) != uid:
        raise LockViolation(
            f"Owner mismatch: lock={lock_data.get('owner_uid')} current={uid}"
        )

    # VPS fingerprint verify
    current_fp = _get_vps_fingerprint()
    if lock_data.get('vps_fp') and lock_data['vps_fp'] != current_fp:
        raise LockViolation(
            "VPS fingerprint mismatch — bot running on unauthorized server!"
        )

    logger.debug(f"Lock verified OK: uid={uid} dir={bot_dir}")


# ══════════════════════════════════════════════════════════════
#  LOCK INFO (Admin panel এর জন্য)
# ══════════════════════════════════════════════════════════════
def get_lock_info(bot_dir: str) -> Optional[dict]:
    """Lock file এর তথ্য পড়ো। Admin panel এ দেখানোর জন্য।"""
    lock_path = os.path.join(bot_dir, LOCK_FILENAME)
    if not os.path.exists(lock_path):
        return None
    try:
        with open(lock_path) as f:
            data = json.load(f)
        data.pop('sig', None)      # signature দেখানোর দরকার নেই
        data.pop('vps_fp', None)   # VPS fingerprint hide করো
        return data
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════
#  REMOVE LOCK (Bot delete করলে)
# ══════════════════════════════════════════════════════════════
def remove_lock(bot_dir: str) -> None:
    """Bot delete করলে lock file মুছো।"""
    lock_path = os.path.join(bot_dir, LOCK_FILENAME)
    try:
        if os.path.exists(lock_path):
            os.chmod(lock_path, 0o600)
            os.remove(lock_path)
    except Exception as e:
        logger.warning(f"remove_lock error: {e}")
