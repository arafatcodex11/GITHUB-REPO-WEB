"""
☁️ ARAFAT HOSTING CLOUD — Admin Alert System v1.0
যেকোনো সমস্যায় Admin কে instant Telegram notification পাঠায়।
"""

import logging, traceback, threading, time
from datetime import datetime

logger = logging.getLogger('AHC.alerts')

_bot      = None
_owner_id = None
_alert_cooldown: dict = {}   # uid → last alert timestamp
ALERT_COOLDOWN_SEC = 300     # একই user এর জন্য ৫ মিনিটে ১ বার

def init_alerts(bot_instance, owner_id: int):
    """Bot start হলে এই function call করো।"""
    global _bot, _owner_id
    _bot      = bot_instance
    _owner_id = owner_id


def _send(text: str):
    """Admin কে message পাঠাও — background thread এ।"""
    if not _bot or not _owner_id:
        return
    def _do():
        try:
            _bot.send_message(_owner_id, text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"alert send failed: {e}")
    threading.Thread(target=_do, daemon=True).start()


def _cleanup_cooldown():
    """২ ঘণ্টার পুরনো cooldown entries মুছো।"""
    now = time.time()
    expired = [k for k, v in list(_alert_cooldown.items()) if now - v > 7200]
    for k in expired:
        _alert_cooldown.pop(k, None)

def alert_security(uid: int, username: str, report: str):
    """Malicious file upload detect হলে।"""
    now = time.time()
    _cleanup_cooldown()
    if now - _alert_cooldown.get(uid, 0) < ALERT_COOLDOWN_SEC:
        logger.info(f"Security alert suppressed (cooldown) uid={uid}")
        return
    _alert_cooldown[uid] = now
    _send(
        f"🚨 <b>SECURITY ALERT</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"{report}\n\n"
        f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )


def alert_bot_error(uid: int, username: str, error: str, bot_name: str = ''):
    """User এর bot crash হলে।"""
    _send(
        f"💥 <b>Bot Crash</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 User: <code>{uid}</code> (@{username or 'unknown'})\n"
        f"🤖 Bot: {bot_name or 'unknown'}\n"
        f"❌ Error: <code>{error[:300]}</code>\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_ram_critical(uid: int, username: str, ram_pct: float, bot_name: str = ''):
    """RAM 90%+ হলে।"""
    _send(
        f"⚠️ <b>RAM Critical</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 User: <code>{uid}</code> (@{username or 'unknown'})\n"
        f"🤖 Bot: {bot_name or 'unknown'}\n"
        f"📊 RAM Usage: <b>{ram_pct:.1f}%</b>\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_sub_expired(uid: int, username: str):
    """Subscription শেষ হলে।"""
    _send(
        f"📅 <b>Subscription Expired</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 User: <code>{uid}</code> (@{username or 'unknown'})\n"
        f"✅ Bot auto-stopped\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_suspicious_activity(uid: int, username: str, reason: str):
    """Suspicious activity — যেমন বারবার ভুল ad code।"""
    _send(
        f"🔍 <b>Suspicious Activity</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 User: <code>{uid}</code> (@{username or 'unknown'})\n"
        f"📌 Reason: {reason}\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_new_user(uid: int, username: str, ref_by: int = None):
    """নতুন user join করলে।"""
    ref_txt = f"\n🔗 Referred by: <code>{ref_by}</code>" if ref_by else ""
    _send(
        f"👋 <b>New User</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 <code>{uid}</code> (@{username or 'unknown'}){ref_txt}\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_payment_received(uid: int, username: str, plan: str, amount: str, trx: str):
    """Payment submit হলে।"""
    _send(
        f"💰 <b>Payment Received</b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"👤 User: <code>{uid}</code> (@{username or 'unknown'})\n"
        f"📦 Plan: {plan}\n"
        f"💵 Amount: {amount}\n"
        f"🧾 TRX: <code>{trx}</code>\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def alert_file_approved(uid: int, admin_id: int):
    """Admin file approve করলে।"""
    _send(
        f"✅ <b>File Approved</b>\n"
        f"👤 User: <code>{uid}</code>\n"
        f"👮 By Admin: <code>{admin_id}</code>\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}"
    )


def send_daily_report(db):
    """প্রতিদিন রাত ১২টায় summary report।"""
    try:
        users     = db.count_users()
        active    = db.count_active_bots()
        today_pay = db.count_today_payments()
        _send(
            f"📊 <b>Daily Report</b>\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👥 Total Users: <b>{users}</b>\n"
            f"🤖 Active Bots: <b>{active}</b>\n"
            f"💰 Today Payments: <b>{today_pay}</b>\n"
            f"📅 {datetime.now().strftime('%Y-%m-%d')}"
        )
    except Exception as e:
        logger.error(f"daily_report error: {e}")


def start_daily_report_scheduler(db):
    """Background thread — প্রতিদিন midnight এ report পাঠায়।"""
    def _loop():
        while True:
            now = datetime.now()
            # রাত ১২:০০ তে report
            seconds_until_midnight = ((24 - now.hour - 1) * 3600
                                      + (60 - now.minute - 1) * 60
                                      + (60 - now.second))
            time.sleep(seconds_until_midnight)
            send_daily_report(db)

    t = threading.Thread(target=_loop, daemon=True)
    t.start()
