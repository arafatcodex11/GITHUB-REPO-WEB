"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — Token Encryptor v1.0            ║
║     User Bot Token AES Encryption System                     ║
╚══════════════════════════════════════════════════════════════╝

▸ User এর bot .env ফাইলের BOT_TOKEN encrypt করে রাখে
▸ Bot start হওয়ার আগে decrypt করে subprocess এ inject করে
▸ Raw token কখনো disk এ plain text থাকে না
▸ Database এও encrypted আকারে থাকে

HOW IT WORKS:
    1. User bot upload করে → token .env থেকে পড়া হয়
    2. encrypt_token(token, uid) → encrypted string save হয়
    3. Bot start হওয়ার আগে → decrypt_token(enc, uid) → env inject
    4. Raw token কখনো log বা DB তে যায় না

HOW TO UPDATE:
    MASTER_KEY → অবশ্যই পরিবর্তন করো! Default রেখো না।
    encrypt_token() / decrypt_token() → Fernet (AES-128-CBC) use করে

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import os, base64, hashlib, logging
from typing import Optional

logger = logging.getLogger('AHC.encryptor')

# ══════════════════════════════════════════════════════════════
#  MASTER KEY — অবশ্যই পরিবর্তন করো!
#  এটা .env এ রাখো:  ENCRYPT_MASTER_KEY=তোমার_secret_key
# ══════════════════════════════════════════════════════════════
MASTER_KEY = os.environ.get('ENCRYPT_MASTER_KEY', 'ArafatCloud-Default-Key-Change-This!')


def _get_fernet(uid: int):
    """
    User এর UID দিয়ে unique Fernet key বানাও।
    একজনের key দিয়ে অন্যজনের token decrypt হবে না।
    """
    try:
        from cryptography.fernet import Fernet
    except ImportError:
        raise RuntimeError(
            "cryptography package নেই। "
            "চালাও: pip install cryptography"
        )

    # uid + master key মিলিয়ে 32 byte key বানাও
    raw = f"{MASTER_KEY}:{uid}:ArafatCloud".encode()
    key_bytes = hashlib.sha256(raw).digest()          # 32 bytes
    fernet_key = base64.urlsafe_b64encode(key_bytes)  # Fernet চায় urlsafe base64
    return Fernet(fernet_key)


# ══════════════════════════════════════════════════════════════
#  ENCRYPT
# ══════════════════════════════════════════════════════════════
def encrypt_token(token: str, uid: int) -> str:
    """
    Bot token encrypt করো।

    Parameters:
        token  — plain text bot token (e.g. 123456:ABC...)
        uid    — owner এর Telegram ID

    Returns:
        encrypted string (safe to store in DB or file)
    """
    if not token or not token.strip():
        return token
    try:
        f = _get_fernet(uid)
        encrypted = f.encrypt(token.strip().encode())
        return encrypted.decode()
    except Exception as e:
        logger.error(f"encrypt_token error uid={uid}: {e}")
        return token   # fallback — plain text (safe failure)


# ══════════════════════════════════════════════════════════════
#  DECRYPT
# ══════════════════════════════════════════════════════════════
def decrypt_token(encrypted: str, uid: int) -> Optional[str]:
    """
    Encrypted token decrypt করো।

    Parameters:
        encrypted — encrypt_token() থেকে পাওয়া string
        uid       — owner এর Telegram ID

    Returns:
        plain text token, অথবা None (decrypt fail হলে)
    """
    if not encrypted or not encrypted.strip():
        return None
    try:
        f = _get_fernet(uid)
        decrypted = f.decrypt(encrypted.strip().encode())
        return decrypted.decode()
    except Exception as e:
        logger.warning(f"decrypt_token fail uid={uid}: {e}")
        return None


# ══════════════════════════════════════════════════════════════
#  .ENV FILE ENCRYPT (bot upload হলে)
# ══════════════════════════════════════════════════════════════
def encrypt_env_file(env_path: str, uid: int) -> bool:
    """
    User এর bot .env file এর BOT_TOKEN encrypt করো।
    File directly edit করে — token এর জায়গায় encrypted value বসায়।

    Returns True on success।
    """
    if not os.path.exists(env_path):
        return False

    try:
        with open(env_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        new_lines = []
        changed = False

        for line in lines:
            stripped = line.strip()
            # BOT_TOKEN=... এই line খোঁজো
            if stripped.startswith('BOT_TOKEN=') and not stripped.startswith('BOT_TOKEN=ENC:'):
                token = stripped.split('=', 1)[1].strip().strip('"').strip("'")
                if token:
                    enc = encrypt_token(token, uid)
                    # ENC: prefix দিয়ে mark করো — encrypt আছে বোঝা যাবে
                    new_lines.append(f'BOT_TOKEN=ENC:{enc}\n')
                    changed = True
                    logger.info(f"BOT_TOKEN encrypted for uid={uid}")
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        if changed:
            with open(env_path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            return True

        return False

    except Exception as e:
        logger.error(f"encrypt_env_file error: {e}")
        return False


# ══════════════════════════════════════════════════════════════
#  ENV INJECT (bot start হওয়ার আগে)
# ══════════════════════════════════════════════════════════════
def inject_decrypted_env(bot_dir: str, uid: int, env: dict) -> dict:
    """
    Bot start এর আগে .env file পড়ে token decrypt করে
    subprocess env dict এ inject করো।

    Parameters:
        bot_dir — bot এর directory
        uid     — owner Telegram ID
        env     — os.environ.copy() থেকে পাওয়া dict

    Returns:
        updated env dict (raw token inject করা)
    """
    env_path = os.path.join(bot_dir, '.env')
    if not os.path.exists(env_path):
        return env

    try:
        with open(env_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, _, val = line.partition('=')
                key = key.strip()
                val = val.strip().strip('"').strip("'")

                if key == 'BOT_TOKEN' and val.startswith('ENC:'):
                    # Decrypt করো এবং inject করো
                    plain = decrypt_token(val[4:], uid)   # ENC: prefix বাদ দিয়ে decrypt
                    if plain:
                        env['BOT_TOKEN'] = plain
                        logger.debug(f"BOT_TOKEN decrypted and injected uid={uid}")
                    else:
                        logger.warning(f"BOT_TOKEN decrypt failed uid={uid}")
                elif key not in env:
                    env[key] = val

    except Exception as e:
        logger.error(f"inject_decrypted_env error: {e}")

    return env


# ══════════════════════════════════════════════════════════════
#  QUICK CHECK — token encrypted আছে কিনা
# ══════════════════════════════════════════════════════════════
def is_token_encrypted(bot_dir: str) -> bool:
    """Bot এর .env এ token encrypted আছে কিনা check করো।"""
    env_path = os.path.join(bot_dir, '.env')
    if not os.path.exists(env_path):
        return False
    try:
        with open(env_path, 'r', errors='ignore') as f:
            for line in f:
                if line.strip().startswith('BOT_TOKEN=ENC:'):
                    return True
    except Exception:
        pass
    return False


# ══════════════════════════════════════════════════════════════
#  TEST — সরাসরি চালাতে পারো
# ══════════════════════════════════════════════════════════════
if __name__ == '__main__':
    test_uid   = 123456789
    test_token = '7512345678:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxx'

    print("🔐 Token Encryption Test")
    print(f"Original : {test_token}")

    enc = encrypt_token(test_token, test_uid)
    print(f"Encrypted: {enc[:60]}...")

    dec = decrypt_token(enc, test_uid)
    print(f"Decrypted: {dec}")

    ok = dec == test_token
    print(f"\n{'✅ Success!' if ok else '❌ FAIL!'}")

    # Wrong UID দিয়ে decrypt হবে না
    dec_wrong = decrypt_token(enc, 999999)
    print(f"Wrong UID decrypt: {'❌ Failed (correct!)' if dec_wrong is None else '⚠️ Decrypted (bug!)'}")
