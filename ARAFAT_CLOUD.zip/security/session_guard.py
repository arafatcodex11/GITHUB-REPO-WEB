"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — Session Guard v1.0              ║
║     Duplicate Session Detect | Hijack Alert                  ║
╚══════════════════════════════════════════════════════════════╝

▸ একই user কে একাধিক জায়গা থেকে simultaneous request detect করে
▸ Suspicious session pattern এ admin alert
▸ Telegram polling conflict detect করে

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import time, logging, threading
from collections import defaultdict
from datetime import datetime

logger = logging.getLogger('AHC.session')

SESSION_TIMEOUT_SEC   = 1800   # ৩০ মিনিট idle → session expire
CONCURRENT_LIMIT      = 3      # একই user থেকে ৩+ concurrent request → suspicious


class SessionGuard:
    def __init__(self, bot_instance, owner_id: int):
        self.bot      = bot_instance
        self.owner_id = owner_id
        self._lock    = threading.Lock()
        # uid → {'last_seen': float, 'request_count': int, 'alerted': bool}
        self._sessions: dict = defaultdict(lambda: {
            'last_seen': 0.0, 'request_count': 0, 'alerted': False
        })

    def touch(self, uid: int, username: str = '') -> bool:
        """
        প্রতিটি incoming message/callback এ call করো।
        Returns True যদি suspicious concurrent activity detect হয়।
        """
        now = time.monotonic()
        with self._lock:
            s = self._sessions[uid]
            gap = now - s['last_seen']

            if gap < 0.05:   # ৫০ms এর মধ্যে duplicate — suspicious
                s['request_count'] += 1
            else:
                s['request_count'] = 1

            s['last_seen'] = now
            suspicious = s['request_count'] >= CONCURRENT_LIMIT

            if suspicious and not s['alerted']:
                s['alerted'] = True
                self._alert(uid, username, s['request_count'])
                return True

            # Reset alert flag after 60s
            if gap > 60:
                s['alerted'] = False

        return False

    def cleanup(self):
        """Stale session মুছো — hourly call করো।"""
        now = time.monotonic()
        with self._lock:
            dead = [u for u, s in self._sessions.items()
                    if now - s['last_seen'] > SESSION_TIMEOUT_SEC]
            for u in dead:
                del self._sessions[u]

    def _alert(self, uid: int, username: str, count: int):
        logger.warning(f"Session flood uid={uid} count={count}")
        try:
            self.bot.send_message(
                self.owner_id,
                f"⚠️ <b>Session Flood Detected</b>\n"
                f"━━━━━━━━━━━━━━━━\n"
                f"👤 <code>{uid}</code> (@{username or 'unknown'})\n"
                f"🔢 {count} concurrent requests in 50ms\n"
                f"⏰ {datetime.now().strftime('%H:%M:%S')}",
                parse_mode='HTML'
            )
        except Exception as e:
            logger.error(f"SessionGuard alert failed: {e}")
