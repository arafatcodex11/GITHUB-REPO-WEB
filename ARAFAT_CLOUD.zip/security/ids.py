"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — Intrusion Detection System v1.0 ║
║     Failed Login | Brute Force | Abuse Pattern Detection     ║
╚══════════════════════════════════════════════════════════════╝

▸ Repeated failed actions detect করে (brute force)
▸ Unusual activity pattern track করে
▸ Auto-ban + Admin alert
▸ Security event log DB তে রাখে

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import time, logging, threading
from collections import defaultdict, deque
from datetime import datetime
from typing import Optional

logger = logging.getLogger('AHC.ids')

# ── Thresholds ────────────────────────────────────────────────
FAILED_AD_CODE_LIMIT   = 5     # এর বেশি wrong ad code → suspicious
RAPID_UPLOAD_LIMIT     = 10    # ১০ মিনিটে ১০+ upload → suspicious
RAPID_CALLBACK_LIMIT   = 50    # ১ মিনিটে ৫০+ callback → bot abuse
WINDOW_SECONDS         = 600   # ১০ মিনিট window
ALERT_COOLDOWN_SEC     = 300   # একই user কে ৫ মিনিটে ১বার alert


class IntrusionDetector:
    """
    Telegram bot activity monitor।
    Brute force, abuse pattern, rapid fire detect করে।
    """

    def __init__(self, bot_instance, owner_id: int, db=None):
        self.bot       = bot_instance
        self.owner_id  = owner_id
        self.db        = db
        self._lock     = threading.Lock()

        # uid → deque of timestamps
        self._failed_ad: dict    = defaultdict(deque)
        self._uploads:   dict    = defaultdict(deque)
        self._callbacks: dict    = defaultdict(deque)
        self._alert_ts:  dict    = {}   # uid → last alert time

    # ─────────────────────────────────────────────────────────
    def record_failed_ad_code(self, uid: int, username: str = '') -> bool:
        """
        Wrong ad code চেষ্টা track করো।
        Returns True যদি threshold পেরিয়ে যায়।
        """
        return self._check_threshold(
            store    = self._failed_ad,
            uid      = uid,
            limit    = FAILED_AD_CODE_LIMIT,
            window   = WINDOW_SECONDS,
            reason   = f"Brute-force ad code ({FAILED_AD_CODE_LIMIT}+ wrong attempts)",
            username = username,
        )

    def record_upload(self, uid: int, username: str = '') -> bool:
        """Upload frequency track করো."""
        return self._check_threshold(
            store    = self._uploads,
            uid      = uid,
            limit    = RAPID_UPLOAD_LIMIT,
            window   = WINDOW_SECONDS,
            reason   = f"Rapid file upload ({RAPID_UPLOAD_LIMIT}+ in 10min)",
            username = username,
        )

    def record_callback(self, uid: int, username: str = '') -> bool:
        """Callback frequency track করো।"""
        return self._check_threshold(
            store    = self._callbacks,
            uid      = uid,
            limit    = RAPID_CALLBACK_LIMIT,
            window   = 60,   # ১ মিনিট
            reason   = f"Callback flooding ({RAPID_CALLBACK_LIMIT}+ in 1min)",
            username = username,
        )

    # ─────────────────────────────────────────────────────────
    def _check_threshold(self, store, uid, limit,
                         window, reason, username='') -> bool:
        now = time.monotonic()
        with self._lock:
            q = store[uid]
            # পুরনো entries সরাও
            while q and now - q[0] > window:
                q.popleft()
            q.append(now)
            count = len(q)

        if count >= limit:
            self._trigger(uid, username, reason, count)
            return True
        return False

    def _trigger(self, uid: int, username: str, reason: str, count: int):
        """Alert পাঠাও + DB log করো।"""
        now = time.time()
        last = self._alert_ts.get(uid, 0)
        if now - last < ALERT_COOLDOWN_SEC:
            return   # cooldown
        self._alert_ts[uid] = now

        logger.warning(f"IDS trigger uid={uid} reason={reason} count={count}")

        if self.db:
            try:
                self.db.log_error(
                    'IDS', f"{reason} | count={count}", uid, 'WARNING'
                )
            except Exception:
                pass

        self._alert(
            f"🚨 <b>Intrusion Detected</b>\n"
            f"━━━━━━━━━━━━━━━━\n"
            f"👤 <code>{uid}</code> (@{username or 'unknown'})\n"
            f"📌 {reason}\n"
            f"🔢 Count: {count}\n"
            f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        )

    def _alert(self, text: str):
        if not self.bot or not self.owner_id:
            return
        try:
            self.bot.send_message(self.owner_id, text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"IDS alert failed: {e}")

    # ─────────────────────────────────────────────────────────
    def cleanup(self):
        """Hourly call — inactive user data মুছো।"""
        now = time.monotonic()
        with self._lock:
            for store in (self._failed_ad, self._uploads, self._callbacks):
                dead = [u for u, q in store.items()
                        if not q or now - q[-1] > 3600]
                for u in dead:
                    del store[u]
