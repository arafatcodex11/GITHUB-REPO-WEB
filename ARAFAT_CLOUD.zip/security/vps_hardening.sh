#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║     ☁️  ARAFAT HOSTING CLOUD — VPS Hardening Script v1.0      ║
# ║     SSH | UFW | Fail2Ban | Readonly | File Permission Lock   ║
# ╚══════════════════════════════════════════════════════════════╝
#
# USAGE:
#   chmod +x vps_hardening.sh
#   sudo bash vps_hardening.sh
#
# কী করে:
#   1. Root SSH login disable
#   2. Password auth disable (key-only)
#   3. Custom SSH port (2222)
#   4. Fail2Ban install + configure
#   5. UFW firewall — only required ports open
#   6. Main hosting files readonly lock
#   7. File permission হার্ড করা

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[✅]${NC} $1"; }
warn() { echo -e "${YELLOW}[⚠️]${NC} $1"; }
fail() { echo -e "${RED}[❌]${NC} $1"; }

if [[ $EUID -ne 0 ]]; then
    fail "Root হিসেবে চালাতে হবে: sudo bash vps_hardening.sh"
    exit 1
fi

# ── Script এর directory খুঁজে নাও ──────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
SSH_PORT="${AHC_SSH_PORT:-2222}"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   ArafatCloud VPS Hardening Starting...    ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# ══════════════════════════════════════════════════════════════
# 1. SSH HARDENING
# ══════════════════════════════════════════════════════════════
echo "▸ [1/6] SSH Hardening..."

SSHD_CONF="/etc/ssh/sshd_config"
cp "$SSHD_CONF" "${SSHD_CONF}.bak.$(date +%Y%m%d%H%M%S)"

configure_ssh() {
    local key="$1" val="$2"
    if grep -qE "^#?${key}" "$SSHD_CONF"; then
        sed -i "s|^#\?${key}.*|${key} ${val}|" "$SSHD_CONF"
    else
        echo "${key} ${val}" >> "$SSHD_CONF"
    fi
}

configure_ssh "PermitRootLogin"      "no"
configure_ssh "PasswordAuthentication" "no"
configure_ssh "PubkeyAuthentication" "yes"
configure_ssh "Port"                 "$SSH_PORT"
configure_ssh "MaxAuthTries"         "3"
configure_ssh "LoginGraceTime"       "30"
configure_ssh "X11Forwarding"        "no"
configure_ssh "AllowTcpForwarding"   "no"
configure_ssh "ClientAliveInterval"  "300"
configure_ssh "ClientAliveCountMax"  "2"

systemctl restart sshd 2>/dev/null || service ssh restart 2>/dev/null || warn "SSH restart manually করো"
ok "SSH hardened — port $SSH_PORT, root login off, password auth off"
warn "⚠️  SSH key আগে add করো তারপর password auth বন্ধ হবে! (authorized_keys)"

# ══════════════════════════════════════════════════════════════
# 2. FAIL2BAN
# ══════════════════════════════════════════════════════════════
echo ""
echo "▸ [2/6] Fail2Ban..."

apt-get install -y fail2ban -qq

cat > /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 3
ignoreip = 127.0.0.1/8

[sshd]
enabled  = true
port     = $SSH_PORT
filter   = sshd
logpath  = /var/log/auth.log
maxretry = 3
bantime  = 86400
EOF

systemctl enable fail2ban
systemctl restart fail2ban
ok "Fail2Ban configured — SSH port $SSH_PORT, 3 retries, 24h ban"

# ══════════════════════════════════════════════════════════════
# 3. UFW FIREWALL
# ══════════════════════════════════════════════════════════════
echo ""
echo "▸ [3/6] UFW Firewall..."

apt-get install -y ufw -qq

ufw --force reset
ufw default deny incoming
ufw default allow outgoing

ufw allow "$SSH_PORT"/tcp    comment 'SSH'
ufw allow 80/tcp             comment 'HTTP'
ufw allow 443/tcp            comment 'HTTPS'

# .env এ EXTRA_PORTS থাকলে open করো
if [[ -f "$PROJECT_DIR/.env" ]]; then
    EXTRA=$(grep "^EXTRA_PORTS=" "$PROJECT_DIR/.env" | cut -d= -f2 | tr ',' ' ')
    for p in $EXTRA; do
        ufw allow "$p"/tcp comment 'Custom'
        ok "Extra port open: $p"
    done
fi

ufw --force enable
ok "UFW enabled — ports: SSH($SSH_PORT), HTTP(80), HTTPS(443)"

# ══════════════════════════════════════════════════════════════
# 4. MAIN FILES READONLY LOCK
# ══════════════════════════════════════════════════════════════
echo ""
echo "▸ [4/6] Main files readonly protection..."

PROTECTED_FILES=(
    "$PROJECT_DIR/main.py"
    "$PROJECT_DIR/config.py"
    "$PROJECT_DIR/database.py"
    "$PROJECT_DIR/core/runner.py"
    "$PROJECT_DIR/core/state.py"
    "$PROJECT_DIR/core/detector.py"
    "$PROJECT_DIR/security/scanner.py"
    "$PROJECT_DIR/security/file_lock.py"
    "$PROJECT_DIR/security/token_encryptor.py"
    "$PROJECT_DIR/security/vps_guard.py"
    "$PROJECT_DIR/security/alerter.py"
    "$PROJECT_DIR/security/ids.py"
    "$PROJECT_DIR/security/anti_rename.py"
)

for f in "${PROTECTED_FILES[@]}"; do
    if [[ -f "$f" ]]; then
        chmod 444 "$f"
        # chattr +i — immutable (even root cannot delete without -i first)
        chattr +i "$f" 2>/dev/null && ok "Immutable: $(basename $f)" || warn "chattr failed for $(basename $f)"
    fi
done

ok "Main hosting files locked as read-only + immutable"
warn "Edit করতে: sudo chattr -i <file> তারপর: sudo chattr +i <file>"

# ══════════════════════════════════════════════════════════════
# 5. UPLOADS FOLDER PERMISSION
# ══════════════════════════════════════════════════════════════
echo ""
echo "▸ [5/6] File permission hardening..."

UPLOADS="$PROJECT_DIR/uploads"
LOGS="$PROJECT_DIR/logs"

mkdir -p "$UPLOADS" "$LOGS"
chmod 750 "$UPLOADS"
chmod 750 "$LOGS"
chmod 600 "$PROJECT_DIR/.env" 2>/dev/null || true
ok "uploads/ → 750, logs/ → 750, .env → 600"

# ══════════════════════════════════════════════════════════════
# 6. SYSCTL HARDENING
# ══════════════════════════════════════════════════════════════
echo ""
echo "▸ [6/6] Kernel / Network hardening..."

cat >> /etc/sysctl.conf << 'EOF'

# ArafatCloud VPS Hardening
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.conf.all.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_max_syn_backlog = 2048
kernel.dmesg_restrict = 1
EOF

sysctl -p -q 2>/dev/null
ok "Kernel network hardening applied"

# ══════════════════════════════════════════════════════════════
# DONE
# ══════════════════════════════════════════════════════════════
echo ""
echo "╔══════════════════════════════════════════╗"
echo "║         ✅ VPS Hardening Complete!       ║"
echo "╚══════════════════════════════════════════╝"
echo ""
echo "  SSH Port   : $SSH_PORT"
echo "  Root Login : Disabled"
echo "  Password   : Disabled (key-only)"
echo "  Fail2Ban   : Active"
echo "  UFW        : Active"
echo "  Readonly   : Core files locked"
echo ""
warn "⚠️  Reconnect SSH: ssh -p $SSH_PORT user@your-vps-ip"
