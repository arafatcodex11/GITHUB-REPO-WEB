"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — Ultra Security Scanner v3.0     ║
║     Anti-Steal | Anti-Delete | Anti-Backdoor | Anti-Hack     ║
╚══════════════════════════════════════════════════════════════╝

▸ Upload করা file scan করে malicious content detect করে
▸ Critical pattern পেলে file quarantine + Admin alert
▸ ZIP path traversal, symlink, ZIP bomb সব detect করে
▸ Bot hijacking, token theft, reverse shell সব block করে

HOW TO UPDATE PATTERNS:
  CRITICAL_PATTERNS  → এখানে যোগ করলে file সাথে সাথে BLOCK হবে
  WARNING_PATTERNS   → সন্দেহজনক; admin alert যাবে কিন্তু চলবে
  DANGEROUS_SHELL_PATTERNS → .sh/.bash file এর জন্য আলাদা check
  BLOCKED_EXTENSIONS → এই extension সরাসরি reject

CHANGELOG:
  v3.0 (2026-05-12) — 45+ new patterns; ZIP bomb; file fingerprint; shell scan
  v2.0 (2026-04-01) — Bot hijack patterns; quarantine system
  v1.0 (2026-01-01) — Initial release
"""

import os, re, logging, hashlib, hmac, time, zipfile
from dataclasses import dataclass, field
from typing import List

logger = logging.getLogger('AHC.security')

# ══════════════════════════════════════════════════════════════
#  CRITICAL PATTERNS — এগুলো পেলে BLOCK + QUARANTINE
# ══════════════════════════════════════════════════════════════
CRITICAL_PATTERNS = [

    # ── Reverse Shell ──────────────────────────────────────────
    (r'socket\.connect\s*\(.*\d+\.\d+\.\d+\.\d+',        'Reverse shell (socket→IP)'),
    (r'subprocess.*bash.*-i.*>&',                         'Reverse shell (bash -i)'),
    (r'os\.system\s*\(["\'].*nc\s+-e',                    'Reverse shell (netcat)'),
    (r'bash\s+-i\s+>&\s*/dev/tcp/',                       'Bash TCP reverse shell'),
    (r'/dev/tcp/\d+\.\d+\.\d+\.\d+/\d+',                 'TCP /dev/tcp path'),
    (r'python[23]?\s+-c.*socket.*connect',                'Python socket reverse shell'),
    (r'perl\s+-e.*socket.*connect',                       'Perl reverse shell'),
    (r'ruby\s+-rsocket.*TCPSocket\.new',                  'Ruby reverse shell'),

    # ── Remote Code Execution ──────────────────────────────────
    (r'eval\s*\(\s*compile\s*\(',                         'RCE: eval+compile'),
    (r'exec\s*\(\s*base64\.b64decode',                    'Obfuscated exec (base64)'),
    (r'__import__\s*\(\s*["\']os["\']\s*\)\.system',      'Hidden os.system via __import__'),
    (r'eval\s*\(\s*__import__',                           'eval+__import__ abuse'),
    (r'getattr\s*\(__builtins__',                         'Builtins hijack via getattr'),
    (r'compile\s*\(.*exec\s*\(',                          'Dynamic compile+exec'),
    (r'marshal\.loads\s*\(',                              'Marshal deserialization RCE'),
    (r'pickle\.loads\s*\(',                               'Pickle deserialization RCE'),

    # ── Bot Hijacking (real-world patterns) ────────────────────
    (r'set_my_name\s*\(',                                 'Bot name hijack'),
    (r'set_my_description\s*\(',                          'Bot description hijack'),
    (r'set_my_short_description\s*\(',                    'Bot short desc hijack'),
    (r'delete_webhook\s*\(',                              'Webhook deletion'),
    (r'set_webhook\s*\(.*url.*http',                      'Webhook redirect to external'),
    (r'fuser\s+-k\s+\d+/tcp',                             'Port kill (server attack)'),
    (r'sujanbotz|freek31|ofcmovie|hubstream\.',            'Known malicious actor'),
    (r'HIDDEN_CHANNEL\s*=',                               'Hidden channel injection'),
    (r'Like_seller|hidden.*channel.*mandatory',           'Hidden channel force-join'),
    (r'mandatory.*join.*not.*shown|not shown in channel', 'Deceptive force-join'),
    (r'API_BASE\s*=.*workers\.dev',                       'Cloudflare Workers API hijack'),
    (r'workers\.dev/api|workers\.dev/dl',                 'CF Workers data exfiltration'),

    # ── Credential / Token Theft ───────────────────────────────
    (r'requests\.(get|post)\s*\(.*BOT_TOKEN',             'Bot token exfiltration'),
    (r'os\.environ.*BOT_TOKEN.*requests',                 'Env var theft via requests'),
    (r'keylogger|keystroke|pynput.*Listener',             'Keylogger detected'),
    (r'cv2\.VideoCapture|ImageGrab\.grab',                'Screen/webcam capture'),
    (r'send.*BOT_TOKEN.*telegram\.me',                    'Token leak to Telegram'),
    (r'open\s*\(["\'].*\.env["\']\s*,\s*["\']r',          'Reading .env file'),
    (r'os\.environ\b.*MONGO_URL|os\.getenv.*MONGO',       'MongoDB credential theft'),

    # ── File System Attacks ────────────────────────────────────
    (r'shutil\.rmtree\s*\(\s*["\'/]',                     'rmtree on root/abs path'),
    (r'open\s*\(["\']\/etc\/',                            'Reading /etc/ system files'),
    (r'open\s*\(["\']\/root\/',                           'Reading /root/ directory'),
    (r'rm\s+-rf\s+/\s*[;&|]|rm\s+-rf\s+/\s*$',          'rm -rf / (full delete)'),
    (r'chmod\s+-R\s+777\s+/',                             'chmod 777 on root'),

    # ── Crypto Miner ──────────────────────────────────────────
    (r'stratum\+tcp://|stratum2\+tcp://',                 'Crypto miner (stratum protocol)'),
    (r'\bxmrig\b|\bcpuminer\b|\bminerd\b',                'Known mining software'),
    (r'monero.*wallet.*mining|mining.*pool.*xmr',         'Crypto mining code'),

    # ── VPS Killer ────────────────────────────────────────────
    (r':\(\)\s*\{\s*:\|:&\s*\};\s*:',                    'Fork bomb'),
    (r'dd\s+if=/dev/zero\s+of=/',                         'Disk fill attack (dd)'),
    (r'while\s+true.*os\.fork\(\)|while\s+1.*os\.fork',   'Fork bomb (Python)'),
]

# ══════════════════════════════════════════════════════════════
#  WARNING PATTERNS — সন্দেহজনক; block না, admin alert
# ══════════════════════════════════════════════════════════════
WARNING_PATTERNS = [
    (r'os\.system\s*\([^)]*(?:curl|wget|nc |ncat|bash|sh -|chmod|rm -rf)[^)]*\)', 'Dangerous os.system()'),
    (r'\bsubprocess\.(run|Popen|call)\b',                 'subprocess execution'),
    (r'\beval\s*\(',                                      'eval() usage'),
    (r'\bexec\s*\(',                                      'exec() usage'),
    (r'\b__import__\s*\(',                                'Dynamic __import__'),
    (r'requests\.(get|post)\s*\(.*http',                  'External HTTP request'),
    (r'socket\.socket\b',                                 'Raw socket usage'),
    (r'paramiko|ftplib|telnetlib',                        'Remote access library'),
    (r'selenium|playwright|pyautogui',                    'Browser automation'),
    (r'base64\.b64decode.*exec|exec.*base64',             'Possible obfuscated exec'),
    (r'os\.popen\s*\(',                                   'os.popen() shell exec'),
]

# ══════════════════════════════════════════════════════════════
#  SHELL FILE PATTERNS — .sh/.bash file এ block
# ══════════════════════════════════════════════════════════════
DANGEROUS_SHELL_PATTERNS = [
    (r'curl\s+.*\|\s*bash|wget\s+.*\|\s*bash',            'Remote code via curl/wget pipe'),
    (r'nc\s+-e\s+/bin/|ncat\s+-e',                        'Netcat reverse shell'),
    (r'rm\s+-rf\s+/',                                     'Recursive delete from root'),
    (r'chmod\s+777\s+/',                                  'Mass permission change'),
    (r'base64\s+-d.*\|\s*bash',                           'Obfuscated shell exec'),
    (r'/etc/passwd|/etc/shadow',                          'System credential file access'),
    (r'iptables\s+-F|ufw\s+disable',                      'Firewall disable'),
    (r'crontab\s+-r|crontab.*>/dev/null',                 'Cron job manipulation'),
]

# সরাসরি block — content check ছাড়া
BLOCKED_EXTENSIONS = {'.exe', '.bat', '.cmd', '.dll', '.msi', '.vbs', '.hta'}

# Scan করার maximum file size (5MB)
MAX_SCAN_SIZE = 5 * 1024 * 1024

# ZIP bomb protection
MAX_ZIP_FILES     = 500
MAX_EXTRACTED_MB  = 200


# ══════════════════════════════════════════════════════════════
#  RESULT OBJECT
# ══════════════════════════════════════════════════════════════
@dataclass
class ScanResult:
    safe: bool = True
    blocked: bool = False
    critical_issues: List[str] = field(default_factory=list)
    warning_issues:  List[str] = field(default_factory=list)
    scanned_files:   int = 0
    blocked_files:   List[str] = field(default_factory=list)
    file_hash:       str = ''
    scan_time:       float = 0.0

    def user_message(self, lang: str = 'en') -> str:
        if lang == 'bn':
            if self.blocked:
                return (
                    "🚫 <b>ফাইল ব্লক করা হয়েছে!</b>\n\n"
                    "আপনার ফাইলে ক্ষতিকর কোড পাওয়া গেছে।\n"
                    "Admin review করবে। Approve হলে জানানো হবে।\n\n"
                    "<b>কারণ:</b>\n"
                    + '\n'.join(f'• {i}' for i in self.critical_issues[:3])
                )
            return (
                "⚠️ <b>সতর্কতা:</b> ফাইলে সন্দেহজনক কোড আছে।\n"
                "Admin কে notify করা হয়েছে। বট চলতে থাকবে।"
            )
        else:
            if self.blocked:
                return (
                    "🚫 <b>File Blocked!</b>\n\n"
                    "Malicious code found in your file.\n"
                    "Admin will review it. You'll be notified on approval.\n\n"
                    "<b>Reason:</b>\n"
                    + '\n'.join(f'• {i}' for i in self.critical_issues[:3])
                )
            return (
                "⚠️ <b>Warning:</b> Suspicious code found in file.\n"
                "Admin has been notified. Bot will continue running."
            )

    def admin_report(self, uid: int, username: str) -> str:
        lines = [
            "🚨 <b>Security Alert</b>",
            "━━━━━━━━━━━━━━━━",
            f"👤 User: <code>{uid}</code> (@{username or 'unknown'})",
            f"📁 Files scanned: {self.scanned_files}",
            f"🔑 Hash: <code>{self.file_hash[:16]}...</code>" if self.file_hash else '',
        ]
        if self.blocked_files:
            lines.append(f"🔒 Blocked: {', '.join(self.blocked_files[:3])}")
        if self.critical_issues:
            lines.append("\n🚨 <b>Critical:</b>")
            for i in self.critical_issues[:5]:
                lines.append(f"  • {i}")
        if self.warning_issues:
            lines.append("\n⚠️ <b>Warnings:</b>")
            for i in self.warning_issues[:5]:
                lines.append(f"  • {i}")
        lines.append(
            f"\n{'🔴 BLOCKED — Admin approval required' if self.blocked else '🟡 WARNED — running with caution'}"
        )
        return '\n'.join(l for l in lines if l)


# ══════════════════════════════════════════════════════════════
#  ZIP BOMB CHECK
# ══════════════════════════════════════════════════════════════
def check_zip_bomb(zip_path: str):
    """ZIP bomb detect করো। Returns (is_safe: bool, reason: str)"""
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            members = zf.infolist()
            if len(members) > MAX_ZIP_FILES:
                return False, f"ZIP bomb: {len(members)} files (max {MAX_ZIP_FILES})"
            total = sum(m.file_size for m in members)
            if total > MAX_EXTRACTED_MB * 1024 * 1024:
                return False, f"ZIP bomb: {total // 1024 // 1024}MB extracted (max {MAX_EXTRACTED_MB}MB)"
            compressed = sum(m.compress_size for m in members if m.compress_size > 0)
            if compressed > 0 and total / compressed > 100:
                return False, f"ZIP bomb: {int(total / compressed)}:1 compression ratio"
    except Exception as e:
        return False, f"ZIP read error: {e}"
    return True, ''


# ══════════════════════════════════════════════════════════════
#  DIRECTORY FINGERPRINT
# ══════════════════════════════════════════════════════════════
def fingerprint_directory(directory: str) -> str:
    h = hashlib.sha256()
    try:
        for root, _, files in os.walk(directory):
            for fname in sorted(files):
                try:
                    with open(os.path.join(root, fname), 'rb') as f:
                        h.update(f.read(512 * 1024))
                except Exception:
                    pass
    except Exception:
        pass
    return h.hexdigest()


# ══════════════════════════════════════════════════════════════
#  SINGLE FILE SCAN
# ══════════════════════════════════════════════════════════════
def _scan_file(filepath: str, result: ScanResult) -> None:
    fname = os.path.basename(filepath)
    ext   = os.path.splitext(fname)[1].lower()

    # Blocked extension — সরাসরি reject
    if ext in BLOCKED_EXTENSIONS:
        result.blocked = True
        result.safe    = False
        result.critical_issues.append(f"Blocked file type: {fname}")
        result.blocked_files.append(fname)
        return

    # Shell script scan
    if ext in ('.sh', '.bash', '.ps1'):
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            result.scanned_files += 1
            for pattern, desc in DANGEROUS_SHELL_PATTERNS:
                if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                    result.blocked = True
                    result.safe    = False
                    result.critical_issues.append(f"{fname}: {desc}")
                    result.blocked_files.append(fname)
                    return
        except Exception:
            pass
        return

    # শুধু code/config files
    if ext not in ('.py', '.js', '.ts', '.php', '.rb', '.go',
                   '.txt', '.env', '.cfg', '.ini', '.json'):
        return

    try:
        if os.path.getsize(filepath) > MAX_SCAN_SIZE:
            result.warning_issues.append(f"Large file skipped: {fname}")
            return

        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        result.scanned_files += 1

        # Critical check — একটা পেলেই block
        for pattern, desc in CRITICAL_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                result.blocked = True
                result.safe    = False
                result.critical_issues.append(f"{fname}: {desc}")
                result.blocked_files.append(fname)
                return

        # Warning check
        for pattern, desc in WARNING_PATTERNS:
            if re.search(pattern, content, re.IGNORECASE | re.MULTILINE):
                result.safe = False
                result.warning_issues.append(f"{fname}: {desc}")

    except Exception as e:
        logger.warning(f"scan_file error {filepath}: {e}")


# ══════════════════════════════════════════════════════════════
#  MAIN PUBLIC FUNCTION
# ══════════════════════════════════════════════════════════════
def scan_directory(directory: str) -> ScanResult:
    """
    Directory বা single file scan করো।

    Returns ScanResult:
      .safe=True              → ✅ সব ঠিক আছে
      .safe=False, .blocked=False → ⚠️ Warning — admin alert
      .blocked=True           → 🚫 Critical — quarantine করো
    """
    t_start = time.time()
    result  = ScanResult()

    if not os.path.exists(directory):
        result.warning_issues.append(f"Path not found: {directory}")
        return result

    if os.path.isfile(directory):
        _scan_file(directory, result)
        try:
            result.file_hash = hashlib.sha256(
                open(directory, 'rb').read(512 * 1024)
            ).hexdigest()
        except Exception:
            pass
        result.scan_time = time.time() - t_start
        return result

    # Directory walk
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs
                   if d not in ('node_modules', '.git', '__pycache__', '.venv', 'venv')]
        for fname in files:
            _scan_file(os.path.join(root, fname), result)

    result.file_hash = fingerprint_directory(directory)
    result.scan_time = time.time() - t_start

    logger.info(
        f"Scan: {directory} | {result.scanned_files} files | "
        f"{'BLOCKED' if result.blocked else 'WARNED' if not result.safe else 'CLEAN'} "
        f"| {result.scan_time:.2f}s"
    )
    return result
