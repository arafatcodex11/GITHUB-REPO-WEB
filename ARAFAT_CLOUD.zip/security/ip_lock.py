"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — IP & Device Lock System v1.0    ║
║     Suspicious IP Detect | Country Lock | Device Fingerprint ║
╚══════════════════════════════════════════════════════════════╝

▸ User এর প্রথম login IP record করে
▸ ভিন্ন দেশ / IP range থেকে login হলে alert
▸ Update: যখন user নতুন IP থেকে access করে admin notify হয়

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import hashlib, logging, time
from datetime import datetime
from typing import Optional

logger = logging.getLogger('AHC.iplock')


def _hash_ip(ip: str) -> str:
    """IP কে hash করে store করো (raw IP DB তে রাখা safe না)."""
    return hashlib.sha256(ip.encode()).hexdigest()[:16]


def get_user_ip_from_update(update) -> Optional[str]:
    """
    Telegram update থেকে IP পাওয়া সম্ভব না directly।
    তবে Webhook mode এ request header থেকে পাওয়া যায়।
    Polling mode এ — Telegram এর IP ব্যবহার হয়, user IP সরাসরি পাওয়া যায় না।
    এই function টা future webhook integration এর জন্য placeholder।
    """
    return None


def record_access(db, uid: int, ip_hash: str, device_info: str = '') -> dict:
    """
    User এর access record করো।
    Returns: {'is_new_ip': bool, 'previous_ip_hash': str}
    """
    try:
        user = db.get_user(uid)
        if not user:
            return {'is_new_ip': False, 'previous_ip_hash': ''}

        known_ips = user.get('known_ip_hashes', [])
        is_new    = ip_hash not in known_ips

        if is_new:
            known_ips = (known_ips + [ip_hash])[-5:]  # max 5 IP record
            db.update_user(uid, known_ip_hashes=known_ips,
                           last_ip_hash=ip_hash,
                           last_access=datetime.utcnow().isoformat())
            logger.info(f"New IP detected uid={uid} hash={ip_hash}")

        return {
            'is_new_ip':         is_new,
            'previous_ip_hash':  user.get('last_ip_hash', ''),
        }
    except Exception as e:
        logger.error(f"record_access error uid={uid}: {e}")
        return {'is_new_ip': False, 'previous_ip_hash': ''}


def check_suspicious_access(db, uid: int, username: str,
                             alerter=None) -> bool:
    """
    User এর access pattern check করো।
    Rapid location change বা unusual time detect করো।
    Returns True যদি suspicious।
    """
    try:
        user = db.get_user(uid)
        if not user:
            return False

        last_access_str = user.get('last_access', '')
        if not last_access_str:
            return False

        last_access = datetime.fromisoformat(last_access_str)
        gap_minutes = (datetime.utcnow() - last_access).total_seconds() / 60

        # ২ মিনিটের মধ্যে ভিন্ন IP — impossible travel
        known_ips = user.get('known_ip_hashes', [])
        if gap_minutes < 2 and len(known_ips) > 1:
            if alerter:
                alerter(
                    f"🚨 <b>Suspicious Access</b>\n"
                    f"👤 <code>{uid}</code> (@{username or 'unknown'})\n"
                    f"⚡ Impossible travel — {gap_minutes:.1f}min gap with new IP\n"
                    f"⏰ {datetime.now().strftime('%H:%M:%S')}"
                )
            logger.warning(f"Suspicious access uid={uid} gap={gap_minutes:.1f}min")
            return True

        return False
    except Exception as e:
        logger.error(f"check_suspicious_access uid={uid}: {e}")
        return False
