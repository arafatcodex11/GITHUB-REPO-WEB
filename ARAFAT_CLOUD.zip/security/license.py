"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — License System v1.0             ║
║     Startup License Key Verify | Encrypted Startup Key       ║
╚══════════════════════════════════════════════════════════════╝

▸ Bot startup এ license key verify করে
▸ Invalid key → bot start হয় না
▸ License key VPS fingerprint + Owner ID দিয়ে tied

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import os, hashlib, hmac, json, logging
from datetime import datetime

logger = logging.getLogger('AHC.license')

LICENSE_FILE   = os.path.join(os.path.dirname(__file__), '..', '.license')
LICENSE_SECRET = b'ArafatCloud-License-Secret-2026'   # .env এ রাখো: LICENSE_SECRET


class LicenseError(Exception):
    pass


def _get_machine_id() -> str:
    """VPS machine ID পড়ো।"""
    for path in ('/etc/machine-id', '/var/lib/dbus/machine-id'):
        try:
            with open(path) as f:
                return f.read().strip()
        except Exception:
            pass
    try:
        import uuid
        return hex(uuid.getnode())
    except Exception:
        return 'unknown'


def generate_license(owner_id: int) -> str:
    """
    License key generate করো।
    Admin panel থেকে অথবা CLI তে call করো:
        python3 -c "from security.license import generate_license; print(generate_license(YOUR_OWNER_ID))"
    """
    machine_id = _get_machine_id()
    raw  = f"{owner_id}:{machine_id}:{LICENSE_SECRET.decode()}"
    key  = hashlib.sha256(raw.encode()).hexdigest()[:32].upper()
    # Format: XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX
    return '-'.join(key[i:i+4] for i in range(0, 32, 4))


def save_license(owner_id: int, license_key: str) -> bool:
    """License file তৈরি করো।"""
    try:
        data = {
            'owner_id':    owner_id,
            'license_key': license_key,
            'machine_id':  _get_machine_id(),
            'created_at':  datetime.utcnow().isoformat(),
        }
        sig = hmac.new(
            LICENSE_SECRET,
            json.dumps(data, sort_keys=True).encode(),
            hashlib.sha256
        ).hexdigest()
        data['sig'] = sig

        with open(LICENSE_FILE, 'w') as f:
            json.dump(data, f, indent=2)
        os.chmod(LICENSE_FILE, 0o400)
        logger.info(f"License saved for owner={owner_id}")
        return True
    except Exception as e:
        logger.error(f"save_license error: {e}")
        return False


def verify_license(owner_id: int) -> None:
    """
    Bot startup এ call করো।
    Raises LicenseError যদি invalid।
    """
    secret = os.environ.get('LICENSE_SECRET', '').encode() or LICENSE_SECRET

    # License file নেই — generate করতে বলো
    if not os.path.exists(LICENSE_FILE):
        key = generate_license(owner_id)
        save_license(owner_id, key)
        logger.info(f"License auto-generated: {key}")
        return   # প্রথমবার always pass

    try:
        with open(LICENSE_FILE) as f:
            data = json.load(f)
    except Exception as e:
        raise LicenseError(f"License file corrupted: {e}")

    # Signature verify
    sig_stored = data.pop('sig', '')
    sig_calc   = hmac.new(
        secret,
        json.dumps(data, sort_keys=True).encode(),
        hashlib.sha256
    ).hexdigest()

    if not hmac.compare_digest(sig_stored, sig_calc):
        raise LicenseError("License tampered!")

    # Owner match
    if int(data.get('owner_id', -1)) != owner_id:
        raise LicenseError("License owner mismatch!")

    # Machine ID match
    current_machine = _get_machine_id()
    if data.get('machine_id') and data['machine_id'] != current_machine:
        raise LicenseError("License VPS mismatch — unauthorized server!")

    # Key match
    expected_key = generate_license(owner_id)
    if data.get('license_key', '') != expected_key:
        raise LicenseError("Invalid license key!")

    logger.info(f"✅ License verified for owner={owner_id}")
