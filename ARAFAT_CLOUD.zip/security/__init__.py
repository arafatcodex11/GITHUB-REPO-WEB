"""
☁️ ARAFAT HOSTING CLOUD — Security Package
"""
from .scanner   import scan_directory, ScanResult, check_zip_bomb
from .alerter   import (alert_security, alert_bot_error, alert_ram_critical,
                         alert_suspicious_activity, alert_new_user,
                         alert_payment_received, alert_file_approved,
                         send_daily_report, start_daily_report_scheduler,
                         init_alerts)
from .vps_guard import VPSGuard
from .file_lock import create_lock, verify_lock, remove_lock, LockViolation

__all__ = [
    'scan_directory', 'ScanResult', 'check_zip_bomb',
    'alert_security', 'alert_bot_error', 'alert_ram_critical',
    'alert_suspicious_activity', 'alert_new_user',
    'alert_payment_received', 'alert_file_approved',
    'send_daily_report', 'start_daily_report_scheduler', 'init_alerts',
    'VPSGuard',
    'create_lock', 'verify_lock', 'remove_lock', 'LockViolation',
]
