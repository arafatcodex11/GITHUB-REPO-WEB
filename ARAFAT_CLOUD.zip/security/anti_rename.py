"""
╔══════════════════════════════════════════════════════════════╗
║     ☁️  ARAFAT HOSTING CLOUD — Anti-Rename Guard v1.0          ║
║     Bot Name/Username Auto-Restore | Branding Protection     ║
╚══════════════════════════════════════════════════════════════╝

▸ প্রতি N মিনিটে bot এর name/username check করে
▸ কেউ bot name বা description পরিবর্তন করলে auto-restore করে
▸ Admin কে instant alert পাঠায়

CHANGELOG:
    v1.0 (2026-05-12) — Initial release
"""

import time, logging, threading
from typing import Optional

logger = logging.getLogger('AHC.antirename')

CHECK_INTERVAL_SEC = 300   # ৫ মিনিট পরপর check


class AntiRenameGuard:
    """
    Background thread — bot এর name/description monitor করে।
    পরিবর্তন detect হলে auto-restore + admin alert।
    """

    def __init__(self, bot_instance, owner_id: int,
                 expected_name: str, expected_description: str = ''):
        self.bot                  = bot_instance
        self.owner_id             = owner_id
        self.expected_name        = expected_name
        self.expected_description = expected_description
        self._running             = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        if self._running:
            return
        self._running = True
        self._thread  = threading.Thread(
            target=self._loop, daemon=True, name='AntiRenameGuard'
        )
        self._thread.start()
        logger.info("AntiRenameGuard started")

    def stop(self):
        self._running = False

    def _loop(self):
        while self._running:
            try:
                self._check_and_restore()
            except Exception as e:
                logger.error(f"AntiRenameGuard loop error: {e}")
            time.sleep(CHECK_INTERVAL_SEC)

    def _check_and_restore(self):
        """Bot এর current info পড়ো এবং expected এর সাথে মেলাও।"""
        try:
            me = self.bot.get_me()
        except Exception as e:
            logger.warning(f"get_me failed: {e}")
            return

        current_name = me.first_name or ''
        changed      = []

        # Name changed?
        if (self.expected_name
                and current_name != self.expected_name):
            changed.append(
                f"Name: '{current_name}' → restoring '{self.expected_name}'"
            )
            try:
                self.bot.set_my_name(self.expected_name)
                logger.info(f"Bot name restored: '{self.expected_name}'")
            except Exception as e:
                logger.warning(f"set_my_name failed: {e}")

        # Description — only check if expected is set
        if self.expected_description:
            try:
                desc_obj = self.bot.get_my_description()
                current_desc = getattr(desc_obj, 'description', '') or ''
                if current_desc != self.expected_description:
                    changed.append(
                        f"Description changed — restoring"
                    )
                    try:
                        self.bot.set_my_description(self.expected_description)
                        logger.info("Bot description restored")
                    except Exception as e:
                        logger.warning(f"set_my_description failed: {e}")
            except Exception:
                pass  # API may not support get_my_description

        if changed:
            self._alert(
                f"⚠️ <b>Bot Tampering Detected!</b>\n"
                f"━━━━━━━━━━━━━━━━\n"
                + '\n'.join(f"• {c}" for c in changed)
                + f"\n✅ Auto-restored\n"
                f"⏰ {time.strftime('%Y-%m-%d %H:%M:%S')}"
            )

    def _alert(self, text: str):
        try:
            self.bot.send_message(self.owner_id, text, parse_mode='HTML')
        except Exception as e:
            logger.error(f"AntiRenameGuard alert failed: {e}")
