"""
╔══════════════════════════════════════════════════════════╗
║         ☁️  ARAFAT HOSTING CLOUD — Main v2.1 (Fixed)       ║
╚══════════════════════════════════════════════════════════╝
"""

import os, sys, time, logging, threading

os.makedirs(os.path.join(os.path.dirname(__file__), 'logs'), exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(
            os.path.join(os.path.dirname(__file__), 'logs', 'bot.log'),
            encoding='utf-8'
        )
    ]
)
logger = logging.getLogger('AHC.main')

import telebot
from config import TOKEN, OWNER_ID, BRAND, BRAND_VER
from database import db
from core.state import state
from core.runner import (
    init_runner, thread_monitor, thread_health_check,
    thread_expiry, thread_daily_report, run_bot
)
from handlers.keyboards import init_kb
from handlers.bot_handlers import init_handlers, register_handlers, safe_send

# FIX: Increase num_threads for concurrent users
bot = telebot.TeleBot(TOKEN, parse_mode='HTML', num_threads=8)


def main():
    logger.info(f"🚀 Starting {BRAND} {BRAND_VER}...")

    # FIX: Initialize SQLite always (even if MongoDB is primary)
    try:
        db.init_sqlite()
        logger.info("✅ SQLite initialized")
    except Exception as e:
        logger.warning(f"SQLite init warning: {e}")

    try:
        db.cleanup_empty_channels()
        logger.info("🧹 Cleaned up empty channels")
    except Exception as e:
        logger.warning(f"Cleanup: {e}")

    init_kb(db)
    init_handlers(bot, db)
    init_runner(bot, db, lambda cid, text, **kw: safe_send(cid, text, **kw))

    # ── Security Alert System চালু করো ──
    from security.alerter import init_alerts, start_daily_report_scheduler
    init_alerts(bot, OWNER_ID)
    start_daily_report_scheduler(db)

    # ── License Verify ───────────────────────────────────────────
    try:
        from security.license import verify_license, LicenseError
        verify_license(OWNER_ID)
        logger.info("✅ License verified")
    except Exception as e:
        logger.warning(f"License: {e} (auto-generated on first run)")

    # ── VPS Guard ────────────────────────────────────────────────
    from security.vps_guard import VPSGuard
    vps_guard = VPSGuard(bot, OWNER_ID, db)
    vps_guard.start()
    logger.info("✅ VPSGuard started")

    # ── Anti-Rename Guard ────────────────────────────────────────
    try:
        from security.anti_rename import AntiRenameGuard
        me = bot.get_me()
        anti_rename = AntiRenameGuard(
            bot_instance        = bot,
            owner_id            = OWNER_ID,
            expected_name       = BRAND.replace("☁️ ", ""),
            expected_description= f"{BRAND} — Telegram Hosting Bot"
        )
        anti_rename.start()
        logger.info("✅ AntiRenameGuard started")
    except Exception as e:
        logger.warning(f"AntiRenameGuard: {e}")

    register_handlers(bot)

    threads = [
        (thread_monitor,       'monitor'),
        (thread_health_check,  'health_check'),
        (thread_expiry,        'expiry'),
        (thread_daily_report,  'daily_report'),
        (_auto_resume,         'auto_resume'),
        (_rate_cleanup,        'rate_cleanup'),
        (_security_cleanup,    'security_cleanup'),
    ]
    for fn, name in threads:
        threading.Thread(target=fn, daemon=True, name=name).start()
        logger.info(f"✅ Thread: {name}")

    try:
        from utils.helpers import sys_stats
        ss = sys_stats()
        s  = db.stats()
        bot.send_message(OWNER_ID,
            f"✅ <b>{BRAND} {BRAND_VER} Started!</b>\n━━━━━━━━━━━━━━━━\n\n"
            f"🖥️ CPU: {ss['cpu']}% | RAM: {ss['mem']}%\n"
            f"💾 {ss['disk_used']}/{ss['disk_total']}\n"
            f"👥 {s.get('users',0)} users | 🤖 {s.get('bots',0)} bots\n"
            f"🧵 Threads: 8\n━━━━━━━━━━━━━━━━",
            parse_mode='HTML'
        )
    except Exception as e:
        logger.warning(f"Owner notify: {e}")

    # ── "/" command list সম্পূর্ণ বন্ধ করো ──
    try:
        bot.delete_my_commands()
        logger.info("✅ Bot commands cleared (no slash menu)")
    except Exception as e:
        logger.warning(f"delete_my_commands: {e}")

    logger.info("🔄 Starting polling...")
    while True:
        try:
            bot.infinity_polling(
                timeout=30,
                long_polling_timeout=20,
                skip_pending=True,
                allowed_updates=['message', 'callback_query']
            )
        except Exception as e:
            err = str(e)
            if '409' in err or 'Conflict' in err:
                logger.warning("⚠️ 409 Conflict — waiting 15s...")
                time.sleep(15)
            elif '401' in err or 'Unauthorized' in err:
                logger.critical("❌ Invalid TOKEN! Check config.py")
                sys.exit(1)
            else:
                logger.error(f"Polling error: {e}")
                time.sleep(5)


def _auto_resume():
    """Auto-resume bots that were running before restart."""
    time.sleep(8)
    try:
        running = db.get_all_running()
        if not running:
            return
        logger.info(f"🔄 Auto-resuming {len(running)} bots...")
        for b in running:
            try:
                # FIX: Support both SQLite (bid) and MongoDB (_id)
                bid = b.get('bid') or b.get('_id') or b.get('id', '')
                # FIX: MongoDB এ 'user_id' field আছে, 'uid' নয়
                uid = b.get('uid') or b.get('user_id')
                if not bid or not uid:
                    logger.warning(f"Skip auto-resume: missing bid/uid in {b}")
                    continue
                threading.Thread(target=run_bot, args=(str(bid), uid),
                                 daemon=True).start()
                time.sleep(1.5)
            except Exception as e:
                logger.error(f"Auto-resume error: {e}")
    except Exception as e:
        logger.error(f"Auto-resume thread: {e}")


def _rate_cleanup():
    """FIX: Hourly cleanup of rate-limit memory for inactive users."""
    while True:
        time.sleep(3600)
        try:
            state.cleanup_rate_data()
            logger.debug("Rate data cleaned up")
        except Exception as e:
            logger.error(f"rate_cleanup: {e}")


def _security_cleanup():
    """Hourly cleanup of IDS + SessionGuard memory."""
    while True:
        time.sleep(3600)
        try:
            from handlers.bot_handlers import _ids, _session_guard
            if _ids:
                _ids.cleanup()
            if _session_guard:
                _session_guard.cleanup()
            logger.debug("Security memory cleaned up")
        except Exception as e:
            logger.error(f"security_cleanup: {e}")


if __name__ == '__main__':
    main()
