#!/bin/bash
echo "🛑 Stopping Apon Hosting Cloud..."
pkill -f "python.*main.py" 2>/dev/null && echo "✅ Bot stopped" || echo "⚠️  Not running"
tmux kill-session -t ahc 2>/dev/null || true
echo "✅ Done"
